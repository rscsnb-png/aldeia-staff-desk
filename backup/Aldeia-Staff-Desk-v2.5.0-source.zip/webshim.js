(function(){try{const q=new URLSearchParams(location.search);if(q.get('clockin')){sessionStorage.setItem('asd_clock',q.get('clockin')+'|'+(q.get('k')||''));history.replaceState(null,'',location.pathname)}}catch(e){}})();
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();window.__installPrompt=e});
const FB_CONFIG={apiKey:"AIzaSyAtaaaOhrdN-3Nk5JATkIs34USa8DL4h9s",authDomain:"aldeia-staff-desk.firebaseapp.com",projectId:"aldeia-staff-desk",storageBucket:"aldeia-staff-desk.firebasestorage.app",messagingSenderId:"191592119419",appId:"1:191592119419:web:f8b7a024df307ad65c76de"};
const MANAGERS=['rscsnb@gmail.com'];
firebase.initializeApp(FB_CONFIG);
const fsdb=firebase.firestore(), fauth=firebase.auth();
window.fbAuth=fauth;
async function shrinkPhoto(blob){
  try{const img=await createImageBitmap(blob);let max=1000,q=.72,out='';
    for(let i=0;i<3;i++){const sc=Math.min(1,max/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.round(img.width*sc);c.height=Math.round(img.height*sc);
      c.getContext('2d').drawImage(img,0,0,c.width,c.height);out=c.toDataURL('image/jpeg',q);if(out.length<450000)break;max=Math.round(max*.75);q-=.08}
    return out}catch(e){return await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=rej;fr.readAsDataURL(blob)})}
}
const MIME={xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',json:'application/json',html:'text/html',jpg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif'};
window.claude={use:async n=>{
  if(n==='db')return fsdb;
  if(n==='downloads')return {save:async({filename,data})=>{const ext=(filename.split('.').pop()||'').toLowerCase();
    const blob=data instanceof Blob?data:new Blob([data],{type:MIME[ext]||'application/octet-stream'});const u=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=u;a.download=filename;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(u);a.remove()},1500);return {status:'saved'}}};
  if(n==='assets')return {upload:async blob=>{const url=await shrinkPhoto(blob);return {id:'p'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),url,sizeBytes:url.length,contentType:'image/jpeg'}}};
  return null}};
const $a=id=>document.getElementById(id);
function authMsg(t,bad){const m=$a('authmsg');m.textContent=t;m.className='small '+(bad?'bad':'muted')}
function showAuth(mode){$a('au-loading').hidden=true;$a('authbox').hidden=false;$a('appwrap').hidden=true;$a('authform').hidden=mode!=='login';$a('authnolink').hidden=mode!=='nolink'}
$a('authform').addEventListener('submit',async e=>{e.preventDefault();const em=$a('au-email').value.trim(),pw=$a('au-pw').value;
  if(!em||!pw){authMsg('Enter your email and password.',true);return}
  authMsg('Signing in…');try{await fauth.signInWithEmailAndPassword(em,pw)}catch(err){authMsg(err&&(err.code==='auth/invalid-credential'||err.code==='auth/wrong-password'||err.code==='auth/user-not-found')?'That email or password is not right.':'Could not sign in. Check your connection and try again.',true)}});
$a('au-forgot').addEventListener('click',async()=>{const em=$a('au-email').value.trim();if(!em){authMsg('Type your email first, then tap Forgot password.',true);return}
  try{await fauth.sendPasswordResetEmail(em);authMsg('Password reset email sent to '+em+'. Check your inbox and spam.')}catch(e){authMsg('Could not send the reset email. Check the address.',true)}});
$a('au-out').addEventListener('click',()=>fauth.signOut().then(()=>location.reload()));
let started=false;
fauth.onAuthStateChanged(async u=>{
  if(!u){try{localStorage.removeItem('asd_me');localStorage.removeItem('asd_mgr')}catch(e){}showAuth('login');return}
  const email=(u.email||'').toLowerCase();let me='',mgr=MANAGERS.includes(email);
  if(!mgr){try{const a=await fsdb.collection('access').doc(email).get();if(a.exists)me=a.data().staffId||''}catch(e){}
    if(!me){$a('nolink-email').textContent=email;showAuth('nolink');return}}
  try{localStorage.setItem('asd_me',me);mgr?localStorage.setItem('asd_mgr','1'):localStorage.removeItem('asd_mgr');localStorage.setItem('asd_tab','home')}catch(e){}
  $a('authbox').hidden=true;$a('appwrap').hidden=false;
  if(!started){started=true;window.startApp();if(mgr)syncAccess()}
});
function syncAccess(){const done={};
  fsdb.collection('staff').onSnapshot(s=>s.docs.forEach(d=>{const x=d.data(),e=(x.email||'').trim().toLowerCase();if(!e)return;
    const key=e+'|'+d.id+'|'+!!x.archived;if(done[e]===key)return;done[e]=key;
    (x.archived?fsdb.collection('access').doc(e).delete():fsdb.collection('access').doc(e).set({staffId:d.id,at:new Date().toISOString()})).catch(()=>{})}),()=>{});
}
