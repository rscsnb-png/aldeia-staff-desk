import re
src=open('aldeia-staff-desk.html').read()
js=open('app.js').read()
def R(a,b):
    global js
    assert js.count(a)==1,a[:80]; js=js.replace(a,b)
WEBVER='2.3.0'
js=re.sub(r"const VERSION='[^']*';",f"const VERSION='{WEBVER}';",js,count=1)
R("function vGate(){","function vGate(){return `<div class=\"card gate\"><h2>Account not linked</h2><p class=\"muted\" style=\"margin:0\">Your login is not linked to a staff member. Ask your manager to check your login email under Setup → Staff.</p><button class=\"btn\" data-act=\"logout\">Sign out</button></div>`}\nfunction vGateOld(){")
R("{k:'role',l:'Role (optional)',ph:'e.g. Facilitator'},{k:'pin',l:'Password / PIN',def:'1234'}","{k:'role',l:'Role (optional)',ph:'e.g. Facilitator'},{k:'email',l:'Login email',ph:'name@example.com'},{k:'pin',l:'PIN (for deleting and clearing)',def:'1234'}")
old_show="show:x=>`${esc(staffLabel(x))}<div class=\"muted small\">${[nm('branches',x.branchId),x.role].filter(Boolean).map(esc).join(' · ')||'No branch'}</div>`},"
assert js.count(old_show)==1, 'staff show'
js=js.replace(old_show,"show:x=>`${esc(staffLabel(x))}<div class=\"muted small\">${[nm('branches',x.branchId),x.role].filter(Boolean).map(esc).join(' · ')||'No branch'} · ${x.email?esc(x.email):'<span class=\"bad\">No login email yet</span>'}</div>`},")
title=re.search(r'<title>.*?</title>',src).group(0)
style=re.search(r'<style>[\s\S]*?</style>',src).group(0).replace('</style>',open('css-add10.txt').read()+'</style>')
header=re.search(r'<header class="top">[\s\S]*?</header>',src).group(0)
header=re.sub(r'<button class="iconbtn" id="themeBtn"[^>]*></button>','',header)
header=header.replace('<div class="tools">','<div class="tools"><!--tools-->')
sb=re.search(r'<button class="iconbtn" id="searchBtn"[\s\S]*?</button>',header).group(0);header=header.replace(sb,'').replace('<!--tools-->',sb)
logo=re.search(r'<img class="logo" src="[^"]+"',src).group(0)
shim=open('webshim.js').read()
html=f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
{title.replace('Aldeia Staff Desk','Aldeia Staff Desk')}
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="#3f5f5a">
<link rel="apple-touch-icon" href="icon-192.png">
<meta name="apple-mobile-web-app-capable" content="yes">
{style}
<style>
*{{box-sizing:border-box}}html{{-webkit-text-size-adjust:100%}}body{{margin:0;font-size:14px;line-height:1.45}}img{{max-width:100%}}[hidden]{{display:none!important}}
:root{{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}}
.authwrap{{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px max(16px,env(safe-area-inset-right,0px)) 24px max(16px,env(safe-area-inset-left,0px))}}
.authcard{{width:100%;max-width:380px;background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:22px;display:flex;flex-direction:column;gap:14px}}
.authcard .logo{{height:56px;align-self:center}}
.authcard form{{display:flex;flex-direction:column;gap:10px}}

.modal{{position:fixed;inset:0;z-index:40;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:16px}}
.modalcard{{background:var(--surface);border-radius:12px;padding:18px;max-width:460px;width:100%;max-height:85vh;overflow:auto;display:flex;flex-direction:column;gap:12px;border:1px solid var(--line-strong)}}
.medtag{{background:var(--bad-bg)!important;color:var(--bad)!important;border-color:var(--bad)!important;font-weight:700;cursor:pointer}}
.attabs{{background:var(--bad-bg)}}
.li{{flex-wrap:wrap}}.li .lt{{flex:1 1 180px;min-width:0}}.li .acts{{margin-left:auto}}
.newhd{{display:flex;align-items:center;gap:8px;padding:4px 2px}}
.linkbtn{{background:none;border:0;color:var(--accent);text-decoration:underline;padding:0;font-size:13px;align-self:flex-start;cursor:pointer}}
</style>
</head>
<body>
<div id="authbox" class="authwrap">
  <div class="authcard">
    {logo} alt="Aldeia NeuroBehaviour Institute">
    <h2 style="margin:0;text-align:center">Staff Desk</h2>
    <form id="authform" hidden>
      <label class="fld"><span>Email</span><input type="email" id="au-email" autocomplete="username" required></label>
      <label class="fld"><span>Password</span><input type="password" id="au-pw" autocomplete="current-password" required></label>
      <button class="btn primary" type="submit">Sign in</button>
      <button class="linkbtn" type="button" id="au-forgot">Forgot password?</button>
      <span id="authmsg" class="small muted"></span>
    </form>
    <div id="authnolink" hidden>
      <p style="margin:0 0 10px">You're signed in as <b id="nolink-email"></b>, but this email isn't linked to a staff member yet.</p>
      <p class="muted small" style="margin:0 0 12px">Ask your manager to add this email under Setup → Staff → Login email, then sign in again.</p>
      <button class="btn" type="button" id="au-out">Sign out</button>
    </div>
    <span id="au-loading" class="muted small" style="text-align:center">Loading…</span>
  </div>
</div>
<div id="appwrap" hidden>
{header}
<main class="wrap" id="panel"><div class="card empty">Loading shared data…</div></main>
<div id="toast" hidden></div>
<nav id="bnav" class="bnav" aria-label="Main" hidden></nav>
</div>
<script src="https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.14.1/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore-compat.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
window.startApp=function(){{
{js}
acts.logout=()=>{{firebase.auth().signOut().then(()=>location.reload())}};
}};
</script>
<script>
{shim}
</script>
</body>
</html>
'''
html=re.sub(r'id="ver">v[^<]*<',f'id="ver">v{WEBVER}<',html)
# loading text only while auth unknown
open('/home/claude/web/index.html','w').write(html)
print(len(html))
