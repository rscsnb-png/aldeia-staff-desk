import re,os,sys
LIVE=len(sys.argv)>1 and sys.argv[1]=='live'
src=open('mkweb.py').read()
src=src.replace("WEBVER='2.3.0'","WEBVER='2.5.0'" if LIVE else "WEBVER='2.5.0-pilot'")
src=src.replace("open('/home/claude/web/index.html','w').write(html)","""if not LIVE: html=html.replace('<link rel="manifest" href="manifest.webmanifest">\\n','').replace('<link rel="apple-touch-icon" href="icon-192.png">\\n','')
html=html.replace("const fsdb=firebase.firestore(), fauth=firebase.auth();","const PFX='"+('' if LIVE else 'pilot_')+"';const fsdb=firebase.firestore(), fauth=firebase.auth();")
html=html.replace("if(n==='db')return fsdb;","if(n==='db'){const q=p=>navigator.onLine?p:(p.catch(()=>{}),Promise.resolve());const wd=r=>({get:()=>r.get(),set:d=>q(r.set(d)),delete:()=>q(r.delete()),onSnapshot:(...a)=>r.onSnapshot(...a)});return {collection:c=>{const col=fsdb.collection(PFX+c);return {onSnapshot:(...a)=>col.onSnapshot(...a),doc:id=>wd(col.doc(id))}},doc:p=>wd(fsdb.doc(PFX+p))}}")
html=html.replace("const fsdb=firebase.firestore(), fauth=firebase.auth();","const fsdb=firebase.firestore(), fauth=firebase.auth();try{fsdb.enablePersistence({synchronizeTabs:true}).catch(()=>{})}catch(e){}")
if not LIVE: html=html.replace('<title>','<title>PILOT · ',1)
html=html.replace('<button class="chipbtn" id="whoBtn"','<button class="iconbtn bellbtn" id="bellBtn" data-act="tab" data-t="notices" aria-label="Notices" hidden><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg><span class="bellc" id="bellC" hidden></span></button> <button class="chipbtn" id="whoBtn"',1)
if not LIVE: html=html.replace('<h2 style="margin:0;text-align:center">Staff Desk</h2>','<h2 style="margin:0;text-align:center">Staff Desk · Test pilot</h2><p class="small muted" style="margin:0;text-align:center">Same login as the real Staff Desk. Uses separate test data.</p>')
html=html.replace('window.startApp=function(){','window.__PILOT=true;window.__PILOTNOTE=true;'+('' if LIVE else 'window.__ISTEST=true;')+'\\nwindow.startApp=function(){',1)
html=html.replace('</style>\\n</head>','.pilotbar{background:#fff3c4;color:#5a4300;border:1px solid #e6cf7a;border-radius:10px;padding:8px 12px;font-size:13px;margin-bottom:10px}.halerts .pilotbar{margin:0}.hal-info{background:var(--accent-soft);color:var(--fg);cursor:pointer;display:block}.hal-info b{color:var(--accent)}\\n</style>\\n</head>',1)
html=html.replace('</style>\\n</head>',open('css-pilot2.txt').read()+'</style>\\n</head>',1)
html=html.replace('</style>\\n</head>',open('css-pilot3.txt').read()+'</style>\\n</head>',1)
os.makedirs('/home/claude/web/pilot',exist_ok=True)
for a in ['icon-192.png']:pass
if not LIVE:
    a="if(!mgr){try{const a=await fsdb.collection('access').doc(email).get();if(a.exists)me=a.data().staffId||''}catch(e){}"
    assert html.count(a)==1
    html=html.replace(a,"if(!mgr){for(const c of [PFX+'access','access']){if(me)break;try{const a=await fsdb.collection(c).doc(email).get();if(a.exists)me=a.data().staffId||''}catch(e){}}")
    a="fsdb.collection('staff').onSnapshot(s=>"
    assert html.count(a)==1
    html=html.replace(a,"fsdb.collection(PFX+'staff').onSnapshot(s=>")
    a="(x.archived?fsdb.collection('access').doc(e).delete():fsdb.collection('access').doc(e).set("
    assert html.count(a)==1
    html=html.replace(a,"(x.archived?fsdb.collection(PFX+'access').doc(e).delete():fsdb.collection(PFX+'access').doc(e).set(")

open('/home/claude/web/index.html' if LIVE else '/home/claude/web/pilot/index.html','w').write(html)""")
exec(src)
