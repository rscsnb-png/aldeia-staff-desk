const PILOT=!!window.__PILOT;
const PILOTNOTE=PILOT&&!!window.__PILOTNOTE;
const ISTEST=!!window.__ISTEST;
const VERSION='1.9.0';
const COLLS=['branches','staff','children','grades','curriculum','topics','periods','breaks','resp','online','attendance','terms','clock','announce','requests','contacts','groups','papprove','mood','leavereq','incidents','maint','ibhide','tests','leave','holidays','entries','plans','signoffs','plocks','feedback','replies','log','stutests'];
const S={settings:{}}; COLLS.forEach(c=>S[c]=[]);
let entryMap={}, soMap={}, db=null, dl=null, assets=null, photoOk=false, loaded=false, dbState='loading';
const lsGet=k=>{try{return localStorage.getItem('asd_'+k)}catch(e){return null}};
const lsSet=(k,v)=>{try{v==null?localStorage.removeItem('asd_'+k):localStorage.setItem('asd_'+k,v)}catch(e){}};

/* ---------- dates ---------- */
const pad=n=>String(n).padStart(2,'0');
const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const parse=s=>{const [y,m,d]=s.split('-').map(Number);return new Date(y,m-1,d)};
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x};
function mondayOf(d){const x=new Date(d.getFullYear(),d.getMonth(),d.getDate());const w=x.getDay();x.setDate(x.getDate()+(w===0?1:w===6?2:1-w));return x}
const todayIso=()=>iso(new Date());
const weekDates=ws=>[0,1,2,3,4].map(i=>iso(addDays(ws,i)));
const DAYS=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const fmt=s=>{if(!s)return'';const d=parse(s);return DAYS[d.getDay()]+' '+d.getDate()+' '+MON[d.getMonth()]};
const fmtAt=s=>{if(!s)return'';const d=new Date(s);return d.getDate()+' '+MON[d.getMonth()]+' '+pad(d.getHours())+':'+pad(d.getMinutes())};
const daysBetween=(a,b)=>Math.round((parse(b)-parse(a))/864e5);
function isoWeek(d){const x=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));const dy=x.getUTCDay()||7;x.setUTCDate(x.getUTCDate()+4-dy);const y0=new Date(Date.UTC(x.getUTCFullYear(),0,1));return Math.ceil(((x-y0)/864e5+1)/7)}

const ui={tab:lsGet('tab')||'home',ws:mondayOf(new Date()),day:'all',f:{branch:'',staff:'',child:'',grade:'',cur:'',topic:'',period:''},
  me:lsGet('me')||'',isMgr:lsGet('mgr')==='1',editing:{},acct:false,dismissed:false,confirmDel:null,open:new Set(),clear:new Set(),
  respStaff:'',openC:new Set(),kid:'',covSince:iso(addDays(new Date(),-56)),covGrade:'',covChild:'',importData:null,fltOpen:false,openDays:new Set(),testOpen:false,brkOpen:false,respBranch:'',focusDay:'',clash:null,clearOpen:false,copyOpen:false,q:'',showArch:false,nudgeHide:false,addOpen:false,evEdit:null,reassign:null,fbTo:'',fbSel:new Set(),ibStaff:'',ibDate:'',pgChild:'',clashOpen:false,ydayClosed:false};
if(ui.me) ui.f.staff=ui.me;
const PERMS=[['resp','Responsibilities: add, edit, re-assign duties'],['setup','Setup: children, grades, curriculum, periods, breaks, leave, holidays, tests'],['inbox','Inbox: receive notes, requests, approvals and photos'],['overview','Overview: all staff, sign-off and unlock'],['timetable','Timetable: move and re-assign for everyone'],['messages','Messages: send messages to staff'],['children','Children: see all records'],['viewas','View as a staff member']];
const PERM_OF_TAB={resp:'resp',setup:'setup',inbox:'inbox',over:'overview',time:'timetable',fb:'messages',kids:'children'};
const myPerms=()=>ui.isMgr?PERMS.map(p=>p[0]):((S.staff.find(x=>x.id===ui.me)||{}).perms||[]);
const hasPerm=p=>!!p&&(ui.isMgr||myPerms().includes(p));
Object.defineProperty(ui,'mgr',{get(){return ui.isMgr||(!!ui.me&&!ui.isMgr&&myPerms().includes(PERM_OF_TAB[ui.tab]))},set(v){ui.isMgr=!!v},enumerable:true});

/* ---------- helpers ---------- */
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const byId=(c,id)=>id?S[c].find(x=>x.id===id):null;
const staffLabel=x=>x?((x.first||'')+' '+(x.last||'')).trim():'';
const periodLabel=x=>x?(x.name||'Period')+(x.start?` (${x.start}${x.end?'–'+x.end:''})`:''):'';
const labelFor=c=>c==='staff'?staffLabel:c==='periods'?periodLabel:c==='topics'?(x=>x?(x.name||'')+(x.subjectId?' · '+((S.curriculum.find(k=>k.id===x.subjectId)||{}).name||''):''):''):(x=>x?x.name||x.title||'':'');
const tName=id=>(byId('topics',id)||{}).name||'';
const nm=(c,id)=>c==='staff'&&id==='*'?'All staff':c==='staff'&&id==='manager'?'Manager':labelFor(c)(byId(c,id));
const periodsSorted=()=>[...S.periods].sort((a,b)=>(a.start||'').localeCompare(b.start||''));
const gKey=n=>{n=String(n||'');const m=n.match(/\d+/);if(m)return +m[0];const r=n.match(/\b(R{1,3})\b/i);return r?-r[1].length:999};
const sortByName=c=>[...S[c]].filter(x=>!x.archived).sort((a,b)=>c==='grades'?(gKey(a.name)-gKey(b.name)||(a.name||'').localeCompare(b.name||'')):labelFor(c)(a).localeCompare(labelFor(c)(b),undefined,{numeric:true}));
const newId=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const pct=(d,t)=>t?Math.round(d/t*100):0;
function opt(c,sel,ph,extra){const list=c==='periods'?periodsSorted():sortByName(c);const L=labelFor(c);
  return `<option value="">${esc(ph)}</option>`+(extra||[]).map(([v,l])=>`<option value="${v}"${v===sel?' selected':''}>${esc(l)}</option>`).join('')+list.map(x=>`<option value="${x.id}"${x.id===sel?' selected':''}>${esc(L(x))}</option>`).join('')}
function topicOpts(sid,sel,ph,add){const list=S.topics.filter(t=>!sid||t.subjectId===sid).sort((a,b)=>(a.name||'').localeCompare(b.name||''));
  return `<option value="">${esc(ph)}</option>`+list.map(t=>`<option value="${t.id}"${t.id===sel?' selected':''}>${esc(t.name)}${!sid&&t.subjectId?' · '+esc(nm('curriculum',t.subjectId)):''}</option>`).join('')+(add?'<option value="__new">+ Add new subject…</option>':'')}
const subjOpts=sel=>opt('curriculum',sel,'—')+'<option value="__new">+ Add new curriculum…</option>';
function toast(m,ms){const t=document.getElementById('toast');t.textContent=m;t.hidden=false;clearTimeout(toast._t);toast._t=setTimeout(()=>t.hidden=true,ms||2800)}
const val=id=>{const el=document.getElementById(id);return el?el.value.trim():''};
const ico={moon:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M13 9.5A5.5 5.5 0 0 1 6.5 3a5.5 5.5 0 1 0 6.5 6.5z"/></svg>',
  sun:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="8" cy="8" r="3"/><path d="M8 1v2M8 13v2M1 8h2M13 8h2M3 3l1.4 1.4M11.6 11.6 13 13M3 13l1.4-1.4M11.6 4.4 13 3"/></svg>'};

/* ---------- time ---------- */
const TIMES=[];for(let m=420;m<=1020;m+=15)TIMES.push(pad(Math.floor(m/60))+':'+pad(m%60));
const timeOpts=(sel,ph,after)=>`<option value="">${ph}</option>`+TIMES.filter(t=>!after||t>after).map(t=>`<option${t===sel?' selected':''}>${t}</option>`).join('');
const SLOTS={am:{name:'Morning',start:'07:00',end:'12:00'},pm:{name:'Afternoon',start:'12:00',end:'17:00'}};
const sessOf=o=>o.session||o.periodId||'';
const oStart=o=>o.start||(byId('periods',o.periodId)||{}).start||'99';
const oEnd=o=>o.end||(byId('periods',o.periodId)||{}).end||'';
function timeLabel(o){const k=sessOf(o),n=SLOTS[k]?SLOTS[k].name:((byId('periods',k)||{}).name||''),st=oStart(o),e=oEnd(o);
  return [n,st!=='99'?st+(e?'–'+e:''):''].filter(Boolean).join(' ')}
function matchTime(o){const f=ui.f.period;if(!f)return true;const st=oStart(o);
  if(f==='am')return sessOf(o)==='am'||(st!=='99'&&st<'12:00');if(f==='pm')return sessOf(o)==='pm'||(st!=='99'&&st>='12:00');return sessOf(o)===f}
function timeBlock(p,o){const se=o?sessOf(o):'';
  return `<div class="grid3"><label class="fld"><span>Session</span><select id="${p}-sess" data-sess="${p}"><option value="">Any time</option><option value="am"${se==='am'?' selected':''}>Morning (07:00–12:00)</option><option value="pm"${se==='pm'?' selected':''}>Afternoon (12:00–17:00)</option>${periodsSorted().map(x=>`<option value="${x.id}"${x.id===se?' selected':''}>${esc(periodLabel(x))}</option>`).join('')}</select></label>
  <label class="fld"><span>From</span><select id="${p}-start">${timeOpts(o&&oStart(o)!=='99'?oStart(o):'','—')}</select></label>
  <label class="fld"><span>To</span><select id="${p}-end">${timeOpts(o?oEnd(o):'','—')}</select></label></div>`}
function readTime(p){const se=val(p+'-sess');return {session:se,periodId:SLOTS[se]?'':se,start:val(p+'-start'),end:val(p+'-end')}}
function subjTopic(p,o){const s=o?o.curriculumId||'':'',t=o?o.topicId||'':'';
  return `<div class="grid2"><label class="fld"><span>Curriculum</span><select id="${p}-cur" data-subj="${p}">${subjOpts(s)}</select></label>
  <label class="fld"><span>Subject</span><select id="${p}-topic" data-topic="${p}">${topicOpts(s,t,'—',true)}</select></label></div>
  <div class="addnew" id="xn-${p}-wrap" hidden><input type="text" id="xn-${p}" placeholder="New name"><button class="btn sm primary" type="button" data-act="addnew" data-p="${p}">Add</button><button class="btn sm" type="button" data-act="addcancel" data-p="${p}">Cancel</button></div>`}
const readSubj=p=>({curriculumId:val(p+'-cur').replace('__new',''),topicId:val(p+'-topic').replace('__new','')});
function pickBox(target,texts){const u=[...new Set(texts.filter(Boolean).map(t=>t.trim()))].sort((a,b)=>a.localeCompare(b));
  return `<label class="fld"><span>Choose from what's already there</span><select data-pick="${target}"><option value="">${u.length?'Choose existing…':'Nothing saved yet'}</option>${u.map(t=>`<option value="${esc(t)}">${esc(t.length>70?t.slice(0,70)+'…':t)}</option>`).join('')}</select></label>`}

/* ---------- logic ---------- */
const liveStaff=()=>S.staff.filter(x=>!x.archived);
const staffFor=r=>r.staffId==='*'?liveStaff().map(s=>s.id):[r.staffId];
const ekey=(r,date,sid)=>r.staffId==='*'?r.id+'_'+date+'_'+sid:r.id+'_'+date;
function applies(r,date){
  if((r.skip||[]).includes(date)) return false;
  if(r.archivedAt&&date>=r.archivedAt) return false;
  if(r.recur==='once') return r.date===date;
  if(!(r.days||[]).includes(parse(date).getDay())) return false;
  return !(r.from && date<r.from);
}
const leaveOf=(sid,d)=>S.leave.find(l=>l.staffId===sid&&l.from<=d&&d<=(l.to||l.from));
function offReason(sid,date){
  const h=S.holidays.find(h=>h.date===date); if(h) return 'Holiday: '+(h.name||'');
  return S.leave.some(l=>l.staffId===sid&&l.from<=date&&date<=(l.to||l.from))?'On leave':'';
}
const signed=(sid,date)=>!!soMap[sid+'_'+date];
function status(r,date,sid,ign){
  const e=entryMap[ekey(r,date,sid)];
  if(e&&e.done) return 'done';
  if(!ign&&offReason(sid,date)) return 'off';
  const t=todayIso(); return date<t?'missed':date===t?'due':'upcoming';
}
const ST_LABEL={done:'Done',missed:'Missed',due:'Due today',upcoming:'Upcoming',off:'Off'};
const childGrade=id=>(byId('children',id)||{}).gradeId||'';
function matchCommon(o,sid){
  const f=ui.f, st=byId('staff',sid);
  if(f.staff && sid!==f.staff && sid!=='*') return false;
  if(f.branch && sid!=='*' && (!st||st.branchId!==f.branch)) return false;
  if(f.child && o.childId!==f.child && !(o.childIds||[]).includes(f.child) && !o.wholeClass) return false;
  if(f.grade && o.gradeId!==f.grade && childGrade(o.childId)!==f.grade) return false;
  if(f.cur && o.curriculumId!==f.cur && !(f.child&&!o.curriculumId)) return false;
  if(f.topic && o.topicId!==f.topic) return false;
  return matchTime(o);
}
function itemsFor(dates){
  const out=[];
  dates.forEach(d=>S.resp.forEach(r=>{if(!applies(r,d))return;staffFor(r).forEach(sid=>{if((r.skip||[]).includes(d+'|'+sid))return;const lv=leaveOf(sid,d);if(lv&&lv.coverId&&!S.holidays.some(h=>h.date===d)){if(matchCommon(r,lv.coverId))out.push({r,date:d,sid,cover:lv.coverId,st:status(r,d,sid,true)});return}if(matchCommon(r,sid)) out.push({r,date:d,sid,st:status(r,d,sid)})})}));
  out.sort((a,b)=>a.date.localeCompare(b.date)||oStart(a.r).localeCompare(oStart(b.r))||nm('staff',a.sid).localeCompare(nm('staff',b.sid)));
  return out;
}
const coverOf=p=>{const lv=leaveOf(p.staffId,p.date);return lv&&lv.coverId||''};
const plansFor=dates=>S.plans.filter(p=>dates.includes(p.date)&&(matchCommon(p,p.staffId)||(coverOf(p)&&matchCommon(p,coverOf(p))))).sort((a,b)=>a.date.localeCompare(b.date)||oStart(a).localeCompare(oStart(b)));
function testsFor(sid){
  const st=byId('staff',sid); if(!st) return [];
  const t=todayIso();
  return S.tests.filter(x=>{if(PILOTNOTE&&x.done)return false;const who=x.staffId?x.staffId===sid:(!x.branchId||x.branchId===st.branchId);
    return who&&x.date&&x.date>=t&&daysBetween(t,x.date)<=(Number(x.lead)||3)}).sort((a,b)=>a.date.localeCompare(b.date));
}
function testsOnDate(date){
  const f=ui.f, fs=byId('staff',f.staff)||{};
  return S.tests.filter(x=>x.date===date&&(!f.branch||!x.branchId||x.branchId===f.branch)&&(!f.grade||!x.gradeId||x.gradeId===f.grade)&&(!f.cur||!x.curId||x.curId===f.cur)
    &&(!f.staff||(x.staffId?x.staffId===f.staff:(!x.branchId||fs.branchId===x.branchId))));
}
function tagsFor(o,sid,noTime){
  const t=noTime?[]:[timeLabel(o)];
  if(o.childIds&&o.childIds.length>1) t.push(whoLabel(o)); else if(o.childId) t.push('Child: '+nm('children',o.childId));
  if(o.gradeId&&!PILOT) t.push(nm('grades',o.gradeId));
  if(o.curriculumId&&!PILOT) t.push(nm('curriculum',o.curriculumId));
  if(o.topicId) t.push(tName(o.topicId));
  return t.filter(Boolean).map(x=>`<span class="tag">${esc(x)}</span>`).join('');
}

/* ---------- writes ---------- */
async function put(c,id,data){if(!db){toast('Sign in to Claude to save changes.');return false}
  try{await db.collection(c).doc(id).set(data);return true}catch(e){toast(e&&e.code==='not_granted'?'You only have view access. Ask the owner for edit access.':'Could not save. Check your connection and try again.');return false}}
async function remove(c,id){if(!db)return;try{await db.collection(c).doc(id).delete()}catch(e){toast('Could not delete. Try again.')}}
function logAct(what){if(!db)return;db.collection('log').doc(newId()).set({at:new Date().toISOString(),who:ui.mgr&&!ui.me?'Manager':(nm('staff',ui.me)+(ui.mgr?' (admin)':'')),what}).catch(()=>{})}
async function setEntry(id,rid,date,sid,patch){
  const cur=entryMap[id]||{}, data={...cur,...patch,rid,date,sid};
  if('done' in patch){data.by=ui.me||'manager';data.at=new Date().toISOString()}
  delete data.id; entryMap[id]={...data,id}; render(); await put('entries',id,data);
  if('done' in patch) syncPlans(rid,date,sid,!!patch.done);
}
function syncPlans(rid,date,sid,done){const r=byId('resp',rid);if(!r)return;const key=(r.text||'').trim().toLowerCase();if(!key)return;
  S.plans.filter(p=>p.date===date&&(p.staffId===sid||p.staffId==='*')&&!!p.done!==done&&(p.text||'').trim().toLowerCase().startsWith(key))
   .forEach(p=>{const {id,...rest}=p;p.done=done;put('plans',id,{...rest,done,doneFromTask:true});checkPlanDone(p.staffId,p.date)})}

/* ---------- render core ---------- */
const panel=document.getElementById('panel');
function tabsFor(){if(ui.isMgr)return [['home','Today'],...(PILOT?[['notices','Notices']]:[]),['check','Checklist'],['reg','Register'],['plan','Planning'],['resp','Responsibilities'],['time','Timetable'],...(PILOTNOTE?[['stud','Students']]:[]),['over','Overview'],['kids','Children'],['bday','Birthdays'],...(PILOT?[['news','Announcements'],['req','Requests & repairs'],['leave','Leave'],['inc','Incidents']]:[]),['fb','Messages'],['inbox','Inbox'],['setup','Setup']];
  const P=myPerms(),t=[['home','Today'],...(PILOT?[['notices','Notices']]:[]),['check','Checklist'],['reg','Register'],['plan','Planning']];if(P.includes('resp'))t.push(['resp','Responsibilities']);
  t.push(['time','Timetable'],...(PILOTNOTE?[['stud','Students']]:[]),['over',P.includes('overview')?'Overview':'My progress'],['kids','Children'],['bday','Birthdays'],...(PILOT?[['news','Announcements'],['req','Requests & repairs'],['leave','Leave'],['inc','Incidents']]:[]),['fb','Messages']);
  if(P.includes('inbox'))t.push(['inbox','Inbox']);if(P.includes('setup'))t.push(['setup','Setup']);return t}
const signedIn=()=>!!(ui.me||ui.mgr);
const NAVICO={stud:'<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5"/><path d="M22 9v6"/>',resp:'<path d="M9 4h6v3H9z"/><path d="M7 5H5v16h14V5h-2"/><path d="M8 13l2.5 2.5L16 10"/>',time:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M8 14h3M13 14h3M8 17h3"/>',home:'<path d="M3 11 12 4l9 7v9H3z"/>',plan:'<path d="M4 20h16M6 16l9-9 3 3-9 9H6z"/>',reg:'<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5M16 11l2 2 4-4"/>',fb:'<path d="M4 5h16v11H8l-4 4z"/>',inbox:'<path d="M3 13h5l2 3h4l2-3h5M5 5h14l2 8v6H3v-6z"/>',more:'<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>'};
function navItems(){if(PILOT){const rs=(ui.isMgr||hasPerm('resp'))?['resp','Responsibilities']:['reg','Register'];return PILOTNOTE?[['home','Today'],...(rs[0]==='reg'?[['plan','Plan'],rs]:[rs,['plan','Plan']]),['time','Timetable'],['stud','Students'],(ui.isMgr||hasPerm('inbox'))?['inbox','Inbox']:['fb','Messages'],['more','More']]:[['home','Today'],['plan','Plan'],rs,['time','Timetable'],(ui.isMgr||hasPerm('inbox'))?['inbox','Inbox']:['fb','Messages'],['more','More']]}return [['home','Today'],['plan','Plan'],['reg','Register'],(ui.isMgr||hasPerm('inbox'))?['inbox','Inbox']:['fb','Messages'],['more','More']]}
function renderChrome(){
  const bn=document.getElementById('bnav'),tabs=document.getElementById('tabs');if(tabs){tabs.hidden=true}
  const me=byId('staff',ui.me);
  document.getElementById('whoBtn').textContent=me?(me.first||staffLabel(me)):(ui.mgr?'Manager':'Sign in');
  const tb=document.getElementById('themeBtn');if(tb)tb.innerHTML=effTheme()==='dark'?ico.sun:ico.moon;
  if(!bn)return;
  if(!signedIn()){bn.hidden=true;bn.innerHTML='';return}
  applyTheme();
  if(PILOT){const bc=document.getElementById('bellC'),bb=document.getElementById('bellBtn');if(bb){bb.hidden=false;bb.classList.toggle('on',ui.tab==='notices')}if(bc){const n=noticeCount();bc.hidden=!n;bc.textContent=n>9?'9+':n}}
  bn.hidden=false;const nav=navItems();bn.style.gridTemplateColumns=`repeat(${nav.length},minmax(0,1fr))`;const inNav=nav.map(x=>x[0]),n=unread(),ni=unreadInbox();
  const moreOn=PILOTNOTE?!inNav.filter(k=>k!=='more').includes(ui.tab):!inNav.slice(0,4).includes(ui.tab);
  bn.innerHTML=nav.map(([k,l])=>{const on=k==='more'?moreOn||ui.moreOpen:ui.tab===k&&!ui.moreOpen,b=k==='fb'?n:k==='inbox'?ni:k==='more'&&(ni||n)&&!inNav.includes('fb')?n:0;
    return `<button class="bn${on?' on':''}${PILOTNOTE&&k==='plan'?' bnplan':''}" data-act="${k==='more'?'moretog':'tab'}" data-t="${k}" aria-label="${l}"${on?' aria-current="page"':''}><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${on?2.1:1.8}" aria-hidden="true">${NAVICO[k]}</svg><span>${l}</span>${b?`<span class="bnb">${b}</span>`:''}</button>`}).join('');
  renderMore();
}
function renderMore(){let m=document.getElementById('moresheet');if(!ui.moreOpen||!signedIn()){if(m)m.remove();return}
  if(!m){m=document.createElement('div');m.id='moresheet';m.className='sheetwrap';document.body.appendChild(m)}
  const inNav=navItems().map(x=>x[0]),items=tabsFor().filter(([k])=>!inNav.includes(k)),n=unread();
  m.innerHTML=`<div class="sheet" role="dialog" aria-label="More"><div class="row spread"><b>More</b><button class="btn sm" data-act="moretog">Close</button></div>
    <div class="sheetgrid">${items.map(([k,l])=>`<button class="sheetbtn${ui.tab===k?' on':''}" data-act="tab" data-t="${k}">${esc(l)}${k==='fb'&&n?` <span class="badge">${n}</span>`:''}</button>`).join('')}</div>
    <div class="row spread small" style="border-top:1px solid var(--line);padding-top:10px"><span class="muted">Aldeia Staff Desk v${VERSION}</span><div class="actions"><button class="btn sm" data-act="theme">${effTheme()==='dark'?'Light mode':'Dark mode'}</button>${window.__installPrompt?'<button class="btn sm primary" data-act="install">Install app</button>':''}<button class="btn sm" data-act="logout">Sign out</button></div></div></div>`}
function syncTabs(ensure){const t=document.getElementById('tabs'),l=document.getElementById('tl'),r=document.getElementById('tr');if(!t||!l)return;
  if(t.hidden){l.hidden=r.hidden=true;return}
  if(ensure){const on=t.querySelector('.on');if(on){const a=on.offsetLeft-t.offsetLeft,b=a+on.offsetWidth;if(a<t.scrollLeft)t.scrollLeft=Math.max(0,a-30);else if(b>t.scrollLeft+t.clientWidth)t.scrollLeft=b-t.clientWidth+30}}
  l.hidden=t.scrollLeft<=2;r.hidden=t.scrollLeft+t.clientWidth>=t.scrollWidth-2}
function dayHead(k,label,right,bad){const o=ui.openDays.has(k);
  return `<button class="dayhead" data-act="dtog" data-k="${k}" aria-expanded="${o}"><span class="dhl"><span class="pm">${o?'−':'+'}</span><span class="dh"${bad?' style="color:var(--bad)"':''}>${esc(label)}</span></span><span class="muted small">${right}</span></button>`}
function allBtn(p,ds){const all=ds.every(d=>ui.openDays.has(p+d));return `<button class="btn sm" data-act="dall" data-p="${p}" data-o="${all?0:1}">${all?'− Close all days':'+ Open all days'}</button>`}
let pending=false;
const isEditing=()=>{const a=document.activeElement;return a&&panel.contains(a)&&/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)&&!['checkbox','radio','file'].includes(a.type)};
function scheduleRender(){if(isEditing()){pending=true;return}render()}
document.addEventListener('focusout',()=>{if(pending)setTimeout(()=>{if(!isEditing()){pending=false;render()}},60)});
const VIEWS={notices:vNotices,news:vNews,req:PILOT?vReqCombo:vReq,leave:vLeave,inc:vInc,maint:vMaint,home:vHome,reg:vReg,bday:vBday,inbox:PILOT?vInboxP:vInbox,search:vSearch,time:vTime,check:vCheck,plan:PILOT?vPlanP:vPlan,over:vOver,kids:vKids,cover:vCover,fb:vFb,resp:vResp,setup:vSetup,stud:vStud};
function render(){
  pending=false;
  try{
    const saved={};
    panel.querySelectorAll('[id^="sf-"],[id^="rf-"],[id^="pf-"],[id^="fb-"],[id^="tf-"]').forEach(el=>{saved[el.id]=(el.type==='checkbox'||el.type==='radio')?el.checked:el.value});
    if(loaded&&ui.me&&S.staff.length&&(!byId('staff',ui.me)||byId('staff',ui.me).archived)){ui.me='';lsSet('me',null)}
    if(!ui.mgr) ui.f.staff=ui.me;
    if(ui.tab!=='search'&&!tabsFor().some(t=>t[0]===ui.tab)) ui.tab='home';
    let h='';
    if(dbState==='none') h+=`<div class="banner info"><b>Sign in to Claude to use the shared tracker.</b><span>Ticks, comments and planning are saved in one shared place once you're signed in.</span></div>`;
    else if(dbState==='error') h+=`<div class="banner"><b>Couldn't reach the shared data.</b><span>Check your connection, then reopen this page.</span></div>`;
    if(ISTEST&&signedIn()&&ui.tab!=='home') h+=`<div class="pilotbar"><b>Test pilot</b> · test data only. Your real Staff Desk is not affected.</div>`;
    if(PILOT&&signedIn()&&ui.tab!=='home'&&!navigator.onLine) h+=`<div class="banner"><b>You're offline</b><span class="small">Changes are saved on this phone and sent when you're back online.</span></div>`;
    if(ui.viewing) h+=`<div class="banner" style="background:var(--accent-soft)"><div class="row spread"><b>Viewing as ${esc(nm('staff',ui.me))}</b><button class="btn sm primary" data-act="viewexit">Back to my view</button></div></div>`;
    if(!signedIn()) h+=vGate(); else {if(ui.acct)h+=acctCard(); if(PILOTNOTE&&['reg','time','inc'].includes(ui.tab))h+=`<div class="qtop">${qBar(ui.tab)}</div>`; h+=VIEWS[ui.tab]();}
    panel.innerHTML=h;
    setTimeout(PILOTNOTE?()=>{if(!ntcModal())ydayModal()}:ydayModal,0);setTimeout(handleClock,0);
    for(const id in saved){if([...ui.clear].some(p=>id.startsWith(p)))continue;const el=document.getElementById(id);if(!el)continue;
      if(el.type==='checkbox'||el.type==='radio')el.checked=saved[id];else el.value=saved[id]}
    panel.querySelectorAll('select[data-subj]').forEach(sel=>{const p=sel.dataset.subj,tp=document.getElementById(p+'-topic');if(!tp)return;
      const keep=tp.value;tp.innerHTML=topicOpts(sel.value.replace('__new',''),keep,'—',true);tp.value=keep;if(tp.value!==keep)tp.value=''});
    ['pf','rf','tf'].forEach(p=>linkChild(p,false));
    panel.querySelectorAll('select[id$="start"]').forEach(syncEnd);
    ui.clear.clear(); syncRecur();
    if(ui.tab==='fb'&&signedIn()&&loaded&&unread())lsSet(seenKey('fb'),new Date().toISOString());
    if(ui.tab==='inbox'&&signedIn()&&loaded&&unreadInbox())lsSet(seenKey('inbox'),new Date().toISOString());
    renderChrome();
  }catch(e){
    console.error(e);
    panel.innerHTML=`<div class="err"><b>Something went wrong showing this page.</b><span class="small">${esc(e&&e.message)}</span><span class="small">Take a screenshot of this and send it to Claude.</span><div><button class="btn sm" data-act="tab" data-t="check">Back to Checklist</button></div></div>`;
  }
}
window.addEventListener('error',e=>toast('Error: '+(e.message||'unknown')));

/* ---------- shared components ---------- */
function vGate(){
  return `<div class="card gate"><h2>Sign in</h2><p class="muted" style="margin:0">Choose your name and enter your password.</p>
  <form data-act="login"><label class="fld"><span>Name</span><select id="gate-who"><option value="">${loaded?'Choose your name':'Loading names…'}</option>${sortByName('staff').map(s=>`<option value="${s.id}"${s.id===lsGet('last')?' selected':''}>${esc(staffLabel(s))}</option>`).join('')}<option value="__mgr">Manager / Admin</option></select></label>
  <label class="fld"><span>Password</span><input type="password" id="gate-pw" inputmode="numeric" autocomplete="current-password" placeholder="••••"></label>
  <button class="btn primary" type="submit">Sign in</button></form>
  <p class="muted small" style="margin:0">Staff use their own PIN. The admin password works for any name. Default for both is 1234.</p></div>`;
}
function acctCard(){return `<div class="card">${window.__installPrompt?'<div class="row spread" style="margin-bottom:8px"><span class="small">Put the Staff Desk on your home screen like an app.</span><button class="btn sm primary" data-act="install">Install app</button></div>':''}<div class="row spread"><div><b>${esc(ui.me?nm('staff',ui.me):'Manager')}</b><div class="muted small">${ui.mgr?'Manager access':'Staff access'} · v${VERSION}</div></div>
  <div class="actions"><button class="btn sm" data-act="logout">Sign out</button><button class="btn sm" data-act="who">Close</button></div></div></div>`}
function weekNav(){
  const ds=weekDates(ui.ws), t=todayIso(), y=parse(ds[0]).getFullYear();
  return `<div class="card"><div class="weeknav">
    <button class="btn sm" data-act="wk" data-n="-1" aria-label="Previous week">‹</button>
    <div class="wl">Week ${isoWeek(ui.ws)} · ${fmt(ds[0]).slice(4)} – ${fmt(ds[4]).slice(4)} ${y}${termLabel(ds[0])}</div>
    <button class="btn sm" data-act="wk" data-n="1" aria-label="Next week">›</button>
    <button class="btn sm" data-act="wk0">This week</button><button class="btn sm primary" data-act="today">Today</button></div>
    <div class="days"><button class="day${ui.day==='all'?' on':''}" data-act="day" data-d="all"><span>Week</span><b>${isoWeek(ui.ws)}</b></button>
    ${ds.map(d=>`<button class="day${ui.day===d?' on':''}${d===t?' today':''}" data-act="day" data-d="${d}"><span>${DAYS[parse(d).getDay()]}</span><b>${parse(d).getDate()}</b></button>`).join('')}</div></div>`;
}
const selDates=()=>ui.day==='all'?weekDates(ui.ws):[ui.day];
function filtersCard(){
  const f=ui.f, n=Object.entries(f).filter(([k,v])=>v&&(ui.mgr||k!=='staff')).length;
  const s=(k,c,ph)=>`<label class="fld"><span>${ph}</span><select data-filter="${k}">${opt(c,f[k],'All')}</select></label>`;
  return `<details class="card flt" ${ui.fltOpen?'open':''} id="fltbox"><summary><span>Filters${n?` <span class="pill upcoming">${n} on</span>`:''}</span><span class="fsum">Child · grade · curriculum · time <span class="chev">▾</span></span></summary>
    <div class="filters">${ui.mgr?s('branch','branches','Branch')+s('staff','staff','Staff'):''}${s('child','children','Child')}${s('grade','grades','Grade')}${s('cur','curriculum','Curriculum')}
    <label class="fld"><span>Subject</span><select data-filter="topic">${topicOpts(f.cur,f.topic,'All',false)}</select></label>
    <label class="fld"><span>Time</span><select data-filter="period">${opt('periods',f.period,'All day',[['am','Morning'],['pm','Afternoon']])}</select></label></div>
    ${n?'<div><button class="btn sm" data-act="clearf">Clear filters</button></div>':''}</details>`;
}
function focusDay(){const ds=weekDates(ui.ws),t=todayIso();return ui.day!=='all'?ui.day:(ui.focusDay&&ds.includes(ui.focusDay)?ui.focusDay:(ds.includes(t)?t:ds[0]))}
function progress(){
  const ds=weekDates(ui.ws),t=todayIso(),day=focusDay();
  const cnt=dates=>{const it=itemsFor(dates).filter(i=>i.st!=='off'),pl=plansFor(dates);return [it.filter(i=>i.st==='done').length+pl.filter(p=>p.done).length,it.length+pl.length]};
  const [dd,dt]=cnt([day]),[wd,wt]=cnt(ds);
  const bar=(l,d,tt)=>`<div class="prog"><div class="row spread small"><b>${l}</b><span class="tnum">${d} of ${tt} done · ${pct(d,tt)}%</span></div><div class="bar big"><i style="width:${pct(d,tt)}%"></i></div></div>`;
  return `<div class="card">${bar(day===t?'Today':fmt(day),dd,dt)}${bar('Week '+isoWeek(ui.ws),wd,wt)}</div>`;
}
function setupFirst(){return `<div class="card empty"><h3>Set up your academy first</h3><span>Add branches, staff and time periods in Setup, then create responsibilities.</span>${ui.mgr?'<button class="btn primary" data-act="tab" data-t="setup">Go to Setup</button>':''}</div>`}
function reminders(){
  if(!ui.me||ui.dismissed) return '';
  const ts=testsFor(ui.me); if(!ts.length) return '';
  return `<div class="banner"><div class="row spread"><b>Test reminders</b><button class="btn sm" data-act="dismiss">Hide</button></div>
    ${ts.map(t=>{const d=daysBetween(todayIso(),t.date);return `<div>${esc(t.title||'Test')} ${[nm('grades',t.gradeId),nm('curriculum',t.curId)].filter(Boolean).map(x=>' · '+esc(x)).join('')} — <b>${fmt(t.date)}</b> <span class="muted">(${d===0?'today':d===1?'tomorrow':'in '+d+' days'})</span></div>`}).join('')}</div>`;
}
function prevWorkday(){let d=addDays(parse(todayIso()),-1);while(d.getDay()===0||d.getDay()===6)d=addDays(d,-1);return iso(d)}
function ydayCard(){if(!loaded)return '';const pd=prevWorkday(),its=itemsFor([pd]).filter(i=>i.st==='missed'&&!signed(i.sid,i.date));if(!its.length)return '';
  const o=!ui.ydayClosed;
  return `<div class="card yday"><button class="dayhead" data-act="ydaytog" aria-expanded="${o}"><span class="dhl"><span class="pm">${o?'−':'+'}</span><span class="dh" style="color:var(--bad)">Not done on ${fmt(pd)}</span></span><span class="muted small"><span class="bad">${its.length}</span> ${ui.mgr&&!ui.f.staff?'across staff':'still open'}</span></button>
  ${o?its.map(i=>itemHtml(i,false)).join(''):''}</div>`}
function overdueCount(){const t=todayIso(),prev=[];for(let i=14;i>=1;i--){const d=addDays(parse(t),-i);if(d.getDay()>0&&d.getDay()<6)prev.push(iso(d))}
  return itemsFor(prev).filter(i=>i.st==='missed'&&!signed(i.sid,i.date)).length}
function nudge(){if(ui.nudgeHide||!loaded)return '';const n=overdueCount();if(!n)return '';
  return `<div class="banner" style="background:var(--bad-bg)"><div class="row spread"><b style="color:var(--bad)">${ui.mgr&&!ui.f.staff?`${n} missed task${n>1?'s':''} across staff`:`You have ${n} missed task${n>1?'s':''}`} from the last two weeks</b><div class="actions"><button class="btn sm primary" data-act="shownudge">Show them</button><button class="btn sm" data-act="hidenudge">Hide</button></div></div></div>`}
function fbNotice(){const ni=unreadInbox();if(ni)return `<div class="banner info"><div class="row spread"><b>${ni} new message${ni>1?'s':''} from staff</b><button class="btn sm primary" data-act="tab" data-t="inbox">Open inbox</button></div></div>`;const n=unread();return n?`<div class="banner info"><div class="row spread"><b>You have ${n} new message${n>1?'s':''}</b><button class="btn sm primary" data-act="tab" data-t="fb">Open messages</button></div></div>`:''}
const photoBtn=(attr,key)=>photoOk?`<button type="button" class="btn xs" data-act="photopick" data-kind="${attr==='data-photo'?'entry':'plan'}" data-k="${esc(key)}">+ Photo</button>`:'';
function pickPhoto(kind,key){const old=document.getElementById('photoPicker');if(old)old.remove();
  const inp=document.createElement('input');inp.type='file';inp.accept='image/*';inp.id='photoPicker';inp.className='vh';document.body.appendChild(inp);
  inp.addEventListener('change',()=>{const f=inp.files&&inp.files[0];if(f)addPhoto(kind,key,f);setTimeout(()=>inp.remove(),0)},{once:true});inp.click()}
const purl=p=>p.url||(p.id?'/_blob/'+p.id:'');
const thumbs=ps=>(ps&&ps.length)?`<div class="thumbs">${ps.map(p=>`<button type="button" class="thumb" data-act="photoview" data-src="${esc(purl(p))}" aria-label="Open photo"><img src="${esc(purl(p))}" alt="Attached photo" loading="lazy"></button>`).join('')}</div>`:'';
function openPhoto(src){let lb=document.getElementById('lightbox');if(!lb){lb=document.createElement('div');lb.id='lightbox';document.body.appendChild(lb)}
  lb.innerHTML=`<div class="lbbar"><button class="btn sm" data-act="photosave" data-src="${esc(src)}">Save photo</button><button class="btn sm primary" data-act="photoclose">Close</button></div><img src="${esc(src)}" alt="Attached photo" data-act="photoclose">`;lb.hidden=false}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){const lb=document.getElementById('lightbox');if(lb)lb.hidden=true}});

/* ---------- checklist ---------- */
function itemHtml({r,date,sid,st,cover:i_cover},showDate){
  const id=ekey(r,date,sid), e=entryMap[id]||{}, off=st==='off'?offReason(sid,date):'', key=r.id+'|'+date+'|'+sid, lock=signed(sid,date)&&!ui.mgr, open=ui.openC.has(key);
  const who=e.done&&e.at?`Ticked by ${esc(nm('staff',e.by))} · ${fmtAt(e.at)}`:'';
  const cmt=open?`<textarea data-comment="${key}" rows="2" placeholder="Type your comment">${esc(e.comment||'')}</textarea><div class="actions"><button class="btn sm primary" data-act="csave" data-k="${key}">Save comment</button><button class="btn sm" data-act="cclose" data-k="${key}">Cancel</button>${!ui.mgr?'<span class="small muted">Your manager will see this comment.</span>':''}</div>`
    :(e.comment?`<div class="cmt">${esc(e.comment)}</div>`:'');
  const tl=timeLabel(r), meta=(showDate?`<span class="tag">${fmt(date)}</span>`:'')+tagsFor(r,sid,true)+kidAlerts(r.childId,date);
  return `<div class="item st-${st}"><label class="tick"><input type="checkbox" data-tick="${key}" ${e.done?'checked':''} ${lock?'disabled':''} aria-label="Mark done"></label>
  <div class="ibody"><div class="ihead"><div class="itext">${esc(r.text)}${tl?` <span class="tag ttag">${esc(tl)}</span>`:''}</div><div class="rcol">${i_cover?`<span class="pill due">Cover for ${esc(nm('staff',sid))}</span>`:''}<span class="who ${bcls(i_cover||sid)}">${esc(nm('staff',i_cover||sid))}</span><span class="pill ${st}">${off?esc(off):ST_LABEL[st]}</span>${signed(sid,date)?'<span class="pill done">Signed off</span>':''}</div></div>
  ${meta?`<div class="meta">${meta}</div>`:''}${cmt}${thumbs(e.photos)}
  ${who||(!lock&&!open)?`<div class="foot">${who?`<span class="muted">${who}</span>`:''}${!lock&&!open?`<span class="iacts"><button class="btn xs" data-act="copen" data-k="${key}">${e.comment?'Edit comment':'+ Comment'}</button>${photoBtn('data-photo',key)}${PILOT&&ui.isMgr?`<button class="btn xs danger" data-act="del" data-c="resp" data-id="${r.id}">${ui.confirmDel==='resp'+r.id?'Tap again':'Delete'}</button>`:''}</span>`:''}</div>`:''}</div></div>`;
}
function syncEnd(st){const en=document.getElementById(st.id.replace(/start$/,'end'));if(!en||en.tagName!=='SELECT')return;
  const keep=en.value,ph=(en.options[0]&&en.options[0].text)||'—';en.innerHTML=timeOpts(keep&&(!st.value||keep>st.value)?keep:'',ph,st.value)}
function linkChild(p,force){const cs=document.getElementById(p+'-child');if(!cs)return;const c=byId('children',cs.value);if(!c)return;
  const g=document.getElementById(p+'-grade');if(g&&c.gradeId&&(force||!g.value))g.value=c.gradeId;
  const cur=document.getElementById(p+'-cur'),tp=document.getElementById(p+'-topic'),ids=c.curIds||[];
  if(cur&&ids.length&&(force||!cur.value||cur.value==='__new')){cur.value=ids[0];cur.dataset.prev=ids[0];if(tp)tp.innerHTML=topicOpts(ids[0],'','—',true)}}
function fillFromChild(d,ck){const c=byId('children',d.childId);if(!c)return d;if(!d.gradeId)d.gradeId=c.gradeId||'';if(!d[ck]&&(c.curIds||[])[0])d[ck]=c.curIds[0];return d}
function vCheck(){return vCheckInner()+(S.staff.length?progress():'')}
function vCheckInner(){
  if(PILOTNOTE)return vCheckSlim();
  let h=backupDue()+reminders()+fbNotice()+bdayBanner()+nudge()+ydayCard();
  if(!S.staff.length&&loaded) return h+setupFirst();
  h+=weekNav()+filtersCard();
  const ds=selDates(), items=itemsFor(ds);
  const fd=focusDay(), c={done:0,missed:0,todo:0,tot:0};itemsFor([fd]).forEach(i=>{if(i.st==='off')return;c.tot++;if(i.st==='done')c.done++;else if(i.st==='missed')c.missed++;else c.todo++});
  plansFor([fd]).forEach(p=>{c.tot++;if(p.done)c.done++;else if(fd<todayIso())c.missed++;else c.todo++});
  h+=`<div class="row spread"><div class="stats"><span class="pill upcoming">${fd===todayIso()?'Today':fmt(fd)}</span><span class="pill done">Done ${c.done}/${c.tot}</span><span class="pill due">${fd===todayIso()?'Due today':'To do'} ${c.todo}</span><span class="pill missed">Missed ${c.missed}</span></div>
     <div class="actions">${allBtn('c',ds)}<button class="btn sm" data-act="report">Printable report</button><button class="btn sm" data-act="excel">Excel</button></div></div>`;
  if(ui.ws<=mondayOf(new Date())){
    const prev=[];for(let i=14;i>=1;i--){const d=addDays(ui.ws,-i);if(d.getDay()>0&&d.getDay()<6)prev.push(iso(d))}
    const miss=itemsFor(prev).filter(i=>i.st==='missed'&&!signed(i.sid,i.date));
    if(miss.length){h+=dayHead('carry','Carried over · missed',`<span class="bad">${miss.length}</span> from the last two weeks`,true);if(ui.openDays.has('carry'))h+=miss.slice(0,20).map(i=>itemHtml(i,true)).join('')}
  }
  if(!S.resp.length&&loaded&&!plansFor(ds).length) return h+`<div class="card empty"><span>No responsibilities yet.</span>${ui.mgr?'<button class="btn primary" data-act="tab" data-t="resp">Add responsibilities</button>':'<span class="small">Your manager adds them.</span>'}</div>`;
  ds.forEach(d=>{
    const its=items.filter(i=>i.date===d), hol=S.holidays.find(x=>x.date===d);
    const nd=its.filter(i=>i.st==='done').length,nmiss=its.filter(i=>i.st==='missed').length,tc=testsOnDate(d).length,dps=plansFor([d]),pdn=dps.filter(p=>p.done).length;
    h+=dayHead('c'+d,fmt(d)+(d===todayIso()?' · Today':''),`${nd+pdn}/${its.length+dps.length} done${nmiss?` · <span class="bad">${nmiss} missed</span>`:''}${dps.length?` · ${dps.length} plan${dps.length>1?'s':''}`:''}${tc?` · ${tc} test${tc>1?'s':''}`:''}${hol?' · holiday':''}`);
    if(!ui.openDays.has('c'+d))return;
    const tickable=its.filter(i=>i.st!=='done'&&i.st!=='off'&&!(signed(i.sid,d)&&!ui.mgr)).length;
    if(tickable>1) h+=`<div class="actions"><button class="btn sm" data-act="tickall" data-d="${d}">${ui.confirmDel==='tickall'+d?`Tap again to tick ${tickable}`:`✓ Tick all for ${fmt(d)}`}</button></div>`;
    if(ui.f.staff&&signed(ui.f.staff,d)){const req=S.feedback.find(f=>f.kind==='unlock'&&f.scope!=='plan'&&f.date===d&&f.from===ui.f.staff&&!f.closed);
      h+=`<div class="banner info"><div class="row spread"><span><b>Signed off by the manager</b><br><span class="small">Ticks for this day are locked.</span></span>${ui.mgr?`<button class="btn sm primary" data-act="unlockday" data-s="${ui.f.staff}" data-d="${d}">Unlock day</button>`:req?'<span class="pill due">Unlock requested</span>':`<button class="btn sm" data-act="requnlock" data-d="${d}">Request unlock</button>`}</div></div>`}
    if(hol) h+=`<div class="banner info"><b>Public holiday: ${esc(hol.name||'')}</b></div>`;
    testsOnDate(d).forEach(t=>h+=`<div class="banner"><span><b>Test${t.time?' · '+tRange(t):''}:</b> ${esc(t.title||'')} ${[nm('grades',t.gradeId),nm('curriculum',t.curId)].filter(Boolean).map(x=>' · '+esc(x)).join('')}</span></div>`);
    h+=its.length?its.map(i=>itemHtml(i)).join(''):(dps.length?'':`<div class="muted small" style="padding:4px 2px">Nothing scheduled${Object.values(ui.f).some(Boolean)&&ui.mgr?' for these filters':''}.</div>`);
    if(dps.length) h+=`<div class="subhd">Planned activities</div>`+planLockBanner(d)+dps.map(planHtml).join('');
  });
  return h;
}

/* ---------- planning ---------- */
function vPlan(){
  let h=reminders();
  if(!S.staff.length&&loaded) return h+setupFirst();
  h+=weekNav()+filtersCard();
  const ds=weekDates(ui.ws), ed=ui.editing.plan?byId('plans',ui.editing.plan):null, v=(k,d='')=>ed?(ed[k]??d):d;
  const defDate=ui.day!=='all'?ui.day:(ds.includes(todayIso())?todayIso():ds[0]);
  h+=`<div class="card"><div class="row spread"><button class="dayhead addhd" data-act="addtog" aria-expanded="${!!(ui.addOpen||ed)}"><span class="dhl"><span class="pm">${ui.addOpen||ed?'−':'+'}</span><span class="dh">${ed?'Edit planning':'Add planning'}</span></span></button><div class="actions"><button class="btn sm" data-act="copyweek">Copy last week's planning</button><button class="btn sm" data-act="copyday">Copy a day</button>${clearBtn()}</div></div>${copyDayBox()}${clearBox()}${ui.addOpen||ed?`
    <div class="grid2">${ui.mgr?`<label class="fld"><span>Staff member</span><select id="pf-staff">${opt('staff',v('staffId',ui.f.staff||ui.me),'Choose staff',[['*','All staff']])}</select></label>`:''}
    <label class="fld"><span>Day</span><select id="pf-date">${ds.map(d=>`<option value="${d}"${d===v('date',defDate)?' selected':''}>${fmt(d)}</option>`).join('')}</select></label></div>
    ${ed?'':`<div class="grid2"><label class="fld"><span>Repeat</span><select id="pf-rep"><option value="">Just this day</option><option value="w">Every week</option></select></label><label class="fld"><span>Repeat until</span><input type="date" id="pf-until" value="${repUntilDefault()}"></label></div>`}
    ${timeBlock('pf',ed)}
    <div class="grid2"><label class="fld"><span>Child</span><select id="pf-child">${opt('children',v('childId'),'—')}</select></label>
    <label class="fld"><span>Grade</span><select id="pf-grade">${opt('grades',v('gradeId'),'—')}</select></label></div>
    ${subjTopic('pf',ed)}
    ${pickBox('pf-text',[...S.resp.map(r=>r.text),...S.plans.filter(p=>ui.mgr||p.staffId===ui.me).map(p=>p.text)])}
    <label class="fld"><span>Add more detail</span><textarea id="pf-text" rows="2" placeholder="Type freely, or add to what you chose above">${esc(v('text'))}</textarea></label>
    ${clashBox('pf')}<div class="actions"><button class="btn primary" data-act="saveplan">${ui.clash&&ui.clash.f==='pf'?'Save anyway':ed?'Save changes':'Save planning'}</button>${ed?'<button class="btn" data-act="cancelplan">Cancel</button>':''}</div>`:''}</div>`;
  const sd=selDates(), plans=plansFor(sd);
  h+=`<div class="row spread"><span class="muted small">${plans.length} planned this ${sd.length>1?'week':'day'}</span>${allBtn('p',sd)}</div>`;
  sd.forEach(d=>{
    const ps=plans.filter(p=>p.date===d), bs=breaksFor(), ts=testsOnDate(d), tk=itemsFor([d]), tkd=tk.filter(i=>i.st==='done').length;
    h+=dayHead('p'+d,fmt(d)+(d===todayIso()?' · Today':''),`${tk.length?`${tkd}/${tk.length} tasks · `:''}${ps.length} planned${ts.length?` · ${ts.length} test${ts.length>1?'s':''}`:''}${bs.length?` · ${bs.length} break${bs.length>1?'s':''}`:''}`);
    if(!ui.openDays.has('p'+d))return;
    h+=planLockBanner(d);
    ts.forEach(t=>h+=testBanner(t));
    const rows=[...tk.map(i=>({s:oStart(i.r),html:itemHtml(i)})),...ps.map(p=>({s:oStart(p),html:planHtml(p)})),...bs.map(x=>({s:x.start||'99',html:`<div class="brk"><span class="pill">Break</span><span>${esc(x.name||'Break')} · ${esc(x.start||'')}${x.end?'–'+esc(x.end):''}${ui.mgr&&x.branchId?' · '+esc(nm('branches',x.branchId)):''}</span></div>`}))].sort((p,q)=>p.s.localeCompare(q.s));
    h+=rows.length?rows.map(r=>r.html).join(''):`<div class="muted small" style="padding:4px 2px">No planning yet.</div>`;
  });
  h+=extraForms();
  return h;
}
const plocked=(sid,d)=>S.plocks.some(x=>x.id===sid+'_'+d);
function planLockBanner(d){const sid=ui.f.staff||ui.me;if(!sid||!plocked(sid,d))return '';
  const req=S.feedback.find(f=>f.kind==='unlock'&&f.scope==='plan'&&f.date===d&&f.from===sid&&!f.closed);
  return `<div class="banner info"><div class="row spread"><span><b>Planning complete · locked</b><br><span class="small">All planned activities for ${fmt(d)} are ticked. Your manager has been told.</span></span>${ui.mgr?`<button class="btn sm primary" data-act="unlockplan" data-s="${sid}" data-d="${d}">Unlock planning</button>`:req?'<span class="pill due">Unlock requested</span>':`<button class="btn sm" data-act="requnlock" data-scope="plan" data-d="${d}">Request unlock</button>`}</div></div>`}
function checkPlanDone(sid,d){if(!sid||sid==='*'||plocked(sid,d))return;const ps=S.plans.filter(q=>q.date===d&&q.staffId===sid);if(!ps.length||!ps.every(q=>q.done))return;
  const k=sid+'_'+d,at=new Date().toISOString();S.plocks.push({id:k,staffId:sid,date:d,at});put('plocks',k,{staffId:sid,date:d,at});
  put('feedback',newId(),{to:'manager',from:sid,kind:'daydone',date:d,text:`${nm('staff',sid)} completed all planning for ${fmt(d)} (${ps.length} activit${ps.length>1?'ies':'y'}).`,at});
  logAct(`${nm('staff',sid)} completed all planning for ${fmt(d)}`);toast(`All planning for ${fmt(d)} done · locked and sent to the manager`)}
function planHtml(p){const lk=p.staffId!=='*'&&plocked(p.staffId,p.date),can=(ui.mgr||p.staffId===ui.me||p.by===ui.me)&&(!lk||ui.mgr);
  return `<div class="item st-${p.done?'done':'upcoming'}"><label class="tick"><input type="checkbox" data-ptick="${p.id}" ${p.done?'checked':''} ${lk&&!ui.mgr?'disabled':''} aria-label="Mark planning done"></label>
  <div class="ibody"><div class="ihead"><div class="itext">${esc(p.text)}${timeLabel(p)?` <span class="tag ttag">${esc(timeLabel(p))}</span>`:''}</div><div class="rcol"><span class="src ${p.by==='manager'?'srcm':'srcs'}">${p.by==='manager'?'Manager':'Staff'}</span><span class="who ${bcls(p.staffId)}">${esc(nm('staff',p.staffId))}</span><span class="pill ${p.done?'done':'upcoming'}">${p.done?'Done':'Planned'}</span>${lk?'<span class="pill">Locked</span>':''}</div></div>${tagsFor(p,'',true)||kidAlerts(p.childId,p.date)||coverOf(p)?`<div class="meta">${coverOf(p)?`<span class="pill due">Cover: ${esc(nm('staff',coverOf(p)))}</span>`:''}${tagsFor(p,'',true)}${kidAlerts(p.childId,p.date)}</div>`:''}${thumbs(p.photos)}
  ${can?`<div class="actions iacts"><button class="btn xs" data-act="editplan" data-id="${p.id}">Edit</button>${photoBtn('data-pphoto',p.id)}<button class="btn xs danger" data-act="del" data-c="plans" data-id="${p.id}">${ui.confirmDel==='plans'+p.id?'Tap again to delete':'Delete'}</button></div>`:''}</div></div>`}
const myBranch=()=>(byId('staff',ui.me)||{}).branchId||'';
function breaksFor(){const br=ui.mgr?(ui.f.branch||(ui.f.staff?(byId('staff',ui.f.staff)||{}).branchId:'')):myBranch();
  return S.breaks.filter(x=>!br||!x.branchId||x.branchId===br)}
function testBanner(t){const can=ui.mgr||t.by===ui.me;
  return `<div class="banner"><div class="row spread"><span><b>Test${t.time?' · '+tRange(t):''}:</b> ${esc(t.title||'')}${[nm('children',t.childId),nm('grades',t.gradeId),nm('curriculum',t.curId)].filter(Boolean).map(x=>' · '+esc(x)).join('')}</span>${can?`<button class="btn sm danger" data-act="del" data-c="tests" data-id="${t.id}">${ui.confirmDel==='tests'+t.id?'Tap again':'Delete'}</button>`:''}</div></div>`}
function extraForms(){
  const sd=selDates(), def=sd.includes(todayIso())?todayIso():sd[0], et=PILOTNOTE&&ui.editing.test?byId('tests',ui.editing.test):null;
  return `<details class="card flt" id="testbox"${ui.testOpen||et?' open':''}><summary><span><span class="pmx"></span> ${et?'Edit test':'Add a test'}</span><span class="fsum">${PILOTNOTE?'':'Shows as a reminder '}<span class="chev">▾</span></span></summary>
   <div class="grid2"><label class="fld"><span>Child</span><select id="tf-child">${opt('children',et?et.childId||'':'','—')}</select></label></div>
   ${subjTopic('tf',et?{curriculumId:et.curId||'',topicId:et.topicId||''}:null)}
   <div class="grid2">
   <label class="fld"><span>Date</span><input type="date" id="tf-date" value="${et?et.date:def}"></label>${PILOTNOTE?`<label class="fld"><span>Starts *</span><select id="tf-ttime" required>${timeOpts(et?et.time||'':'','Choose')}</select></label><label class="fld"><span>Ends *</span><select id="tf-tend" required>${timeOpts(et?et.timeEnd||'':'','Choose')}</select></label>`:PILOT?`<label class="fld"><span>Time</span><select id="tf-ttime">${timeOpts('','—')}</select></label>`:''}
   <label class="fld"><span>Grade</span><select id="tf-grade">${opt('grades',et?et.gradeId||'':'','—')}</select></label>
   ${ui.mgr?`<label class="fld"><span>Branch</span><select id="tf-branch">${opt('branches',et?et.branchId||'':'','All branches')}</select></label><label class="fld"><span>Staff</span><select id="tf-staff">${opt('staff',et?et.staffId||'':'','All staff at branch')}</select></label>`:''}
   <label class="fld"><span>Remind days before</span><input type="number" id="tf-lead" value="${et?esc(et.lead||'3'):'3'}" min="0" max="30"></label></div>
   <div class="actions"><button class="btn primary" data-act="savetest">${et?'Save changes':'Save test'}</button>${et?'<button class="btn" data-act="testcancel">Cancel</button>':''}</div></details>
  <details class="card flt" id="brkbox"${ui.brkOpen?' open':''}><summary><span><span class="pmx"></span> Add break time</span><span class="fsum">${breaksFor().length} saved <span class="chev">▾</span></span></summary>
   <div class="grid2"><label class="fld"><span>Name</span><input type="text" id="tf-bname" placeholder="e.g. Tea break"></label>
   ${ui.mgr?`<label class="fld"><span>Branch</span><select id="tf-bbranch">${opt('branches','','All branches')}</select></label>`:''}
   <label class="fld"><span>Start</span><select id="tf-bstart">${timeOpts('','—')}</select></label>
   <label class="fld"><span>End</span><select id="tf-bend">${timeOpts('','—')}</select></label></div>
   <div class="actions"><button class="btn primary" data-act="savebreak">Save break</button>${ui.mgr?'<button class="btn" data-act="tab" data-t="setup">Manage in Setup</button>':''}</div></details>`;
}

function clearTargets(){return plansFor([focusDay()]).filter(p=>ui.mgr||p.staffId===ui.me||p.by===ui.me)}
const clearPast=()=>focusDay()<iso(mondayOf(new Date()));
function clearBtn(){const d=focusDay();return clearPast()?`<button class="btn sm" disabled title="Past weeks can't be cleared">Clear ${fmt(d)}</button>`:`<button class="btn sm danger" data-act="clearopen">Clear ${fmt(d)}</button>`}
function clearBox(){if(!ui.clearOpen||clearPast())return '';const n=clearTargets().length;
  return `<div class="banner"><b>Clear ${n} plan${n===1?'':'s'} on ${fmt(focusDay())}</b><span class="small">Only this day is cleared. Enter your sign-in password to confirm.</span>
  <form data-act="clearplans" class="addnew"><input type="password" id="tf-clrpw" inputmode="numeric" autocomplete="off" placeholder="Your password"><button class="btn sm danger" type="submit">Clear day</button><button class="btn sm" type="button" data-act="clearcancel">Cancel</button></form></div>`}
function copyDayBox(){if(!ui.copyOpen)return '';const fd=focusDay();let pv=addDays(parse(fd),-1);while(pv.getDay()===0||pv.getDay()===6)pv=addDays(pv,-1);
  return `<div class="banner info"><b>Copy one day's planning</b><div class="grid2"><label class="fld"><span>From</span><input type="date" id="tf-cfrom" value="${iso(pv)}"></label>
  <label class="fld"><span>To</span><select id="tf-cto">${weekDates(ui.ws).map(d=>`<option value="${d}"${d===fd?' selected':''}>${fmt(d)}</option>`).join('')}</select></label></div>
  <div class="actions"><button class="btn sm primary" data-act="copydaygo">Copy</button><button class="btn sm" data-act="copyday">Cancel</button></div></div>`}
const toMin=t=>{if(!t||t==='99')return null;const [h,m]=t.split(':').map(Number);return h*60+m};
function clashList(sid,date,s,e,exId){
  if(s==null)return[];if(e==null||e<=s)e=s+30;const out=[];
  const ov=(a,b)=>{if(a==null)return false;if(b==null||b<=a)b=a+30;return a<e&&b>s};
  S.resp.forEach(r=>{if(r.id===exId||!applies(r,date)||!staffFor(r).includes(sid))return;if(ov(toMin(oStart(r)),toMin(oEnd(r))))out.push(`"${r.text}" ${timeLabel(r)}`)});
  S.plans.forEach(p=>{if(p.id===exId||p.date!==date||(p.staffId!==sid&&p.staffId!=='*'))return;if(ov(toMin(oStart(p)),toMin(oEnd(p))))out.push(`plan "${p.text}" ${timeLabel(p)}`)});
  const br=(byId('staff',sid)||{}).branchId;S.breaks.forEach(x=>{if(x.branchId&&x.branchId!==br)return;if(ov(toMin(x.start),toMin(x.end)))out.push(`${x.name||'Break'} ${x.start||''}${x.end?'–'+x.end:''}`)});
  return out}
function checkClash(f,d,sids,dates,exId){
  const s=toMin(d.start),e=toMin(d.end);if(s==null)return false;
  const key=f+JSON.stringify([d.text,d.staffId,d.start,d.end,dates]);if(ui.clash&&ui.clash.key===key)return false;
  const hits=[];sids.forEach(sid=>dates.forEach(dt=>clashList(sid,dt,s,e,exId).forEach(x=>hits.push(`${nm('staff',sid)} · ${fmt(dt)}: ${x}`))));
  if(!hits.length)return false;
  ui.clash={f,key,hits};render();toast('Time clash found. Check the warning.');return true}
function clashBox(f){const c=ui.clash;if(!c||c.f!==f)return '';
  return `<div class="banner"><b>Time clash</b>${c.hits.slice(0,4).map(x=>`<span class="small">${esc(x)}</span>`).join('')}${c.hits.length>4?`<span class="small muted">and ${c.hits.length-4} more</span>`:''}<span class="small">Change the time, or tap Save anyway to keep both.</span></div>`}

function bcls(sid){const s=byId('staff',sid);if(!s||!s.branchId)return '';const i=sortByName('branches').findIndex(b=>b.id===s.branchId);return i<0?'':'bc'+(i%6)}

/* ---------- search ---------- */
function vSearch(){
  return `<div class="card"><label class="fld"><span>Search</span><input type="search" id="q" value="${esc(ui.q)}" placeholder="Task, plan, child, curriculum, comment…" autocomplete="off"></label>
  <span class="muted small">${ui.mgr?'Searches everyone.':'Searches your own records.'}</span></div><div id="sres">${searchResults()}</div>`}
function searchResults(){
  const q=ui.q.trim().toLowerCase();if(q.length<2)return `<div class="card empty">Type at least 2 letters.</div>`;
  const has=t=>String(t||'').toLowerCase().includes(q), out=[];
  const row=(k,v,d,kind,title,sub)=>out.push(`<button class="li sr" data-act="goto" data-k="${k}" data-v="${esc(v||'')}" data-d="${esc(d||'')}"><span class="pill">${kind}</span><span class="lt"><div>${esc(title)}</div><div class="muted small">${esc(sub||'')}</div></span></button>`);
  S.resp.filter(r=>has(r.text)&&(ui.mgr||staffFor(r).includes(ui.me))).forEach(r=>row('task',r.id,'','Task',r.text,[nm('staff',r.staffId),respDesc(r).replace(/&[^;]+;/g,' ')].join(' · ')+(r.archived?' · archived':'')));
  S.plans.filter(p=>(has(p.text)||has(p.date))&&(ui.mgr||p.staffId===ui.me||p.staffId==='*')).sort((a,b)=>b.date.localeCompare(a.date)).forEach(p=>row('plan','',p.date,'Plan',p.text,`${fmt(p.date)} · ${nm('staff',p.staffId)} · ${timeLabel(p)}`));
  S.entries.filter(e=>has(e.comment)&&(ui.mgr||e.sid===ui.me||(!e.sid&&(byId('resp',e.rid)||{}).staffId===ui.me))).forEach(e=>{const r=byId('resp',e.rid)||{};row('task','',e.date,'Comment',e.comment,`${r.text||''} · ${fmt(e.date)} · ${nm('staff',e.sid||r.staffId)}`)});
  sortByName('children').filter(c=>has(c.name)).forEach(c=>row('child',c.id,'','Child',c.name,nm('grades',c.gradeId)));
  sortByName('curriculum').filter(c=>has(c.name)).forEach(c=>row('cur',c.id,'','Curriculum',c.name,''));
  sortByName('topics').filter(c=>has(c.name)).forEach(c=>row('cur',c.id,'','Subject',c.name,nm('curriculum',c.subjectId)));
  if(ui.mgr) sortByName('staff').filter(x=>has(staffLabel(x))).forEach(x=>row('staff',x.id,'','Staff',staffLabel(x),nm('branches',x.branchId)));
  fbVisible().filter(f=>has(f.text)).forEach(f=>row('fb',f.id,'','Feedback',f.text,fmtAt(f.at)));
  return out.length?`<div class="list">${out.slice(0,60).join('')}</div>${out.length>60?`<p class="muted small">Showing 60 of ${out.length}. Type more to narrow it down.</p>`:''}`:`<div class="card empty">Nothing found for "${esc(ui.q)}".</div>`;
}
document.addEventListener('input',e=>{if(e.target.id==='q'){ui.q=e.target.value;const r=document.getElementById('sres');if(r)r.innerHTML=searchResults()}});

/* ---------- pilot: announcements, resources, parent contacts, branch colours ---------- */
const THEMES=[{id:'sky',name:'Sky blue (standard)',light:'#5faed8',deep:'#23729f',soft:'#dcecf5'},{id:'teal',name:'Teal',light:'#62c2b4',deep:'#1d6b62',soft:'#d8efeb'},{id:'purple',name:'Purple',light:'#b39ddb',deep:'#5b3f8f',soft:'#ebe4f6'},{id:'orange',name:'Orange',light:'#f2b27a',deep:'#9a4a12',soft:'#f8e6d6'},{id:'green',name:'Green',light:'#9ccc8a',deep:'#2f6e22',soft:'#e2f0dc'},{id:'pink',name:'Pink',light:'#eda5c1',deep:'#93264f',soft:'#f7e1ea'},{id:'yellow',name:'Yellow',light:'#f3d36b',deep:'#7a5a00',soft:'#f7efcf'}];
function applyTheme(){if(!PILOT)return;const br=ui.isMgr?(ui.f.branch||''):((byId('staff',ui.me)||{}).branchId||''),b=byId('branches',br),t=b&&b.theme&&b.theme!=='sky'?THEMES.find(x=>x.id===b.theme):null,st=document.documentElement.style;
  if(!t){['--hdr','--accent','--accent-soft','--hdr-fg'].forEach(v=>st.removeProperty(v));return}const dk=effTheme()==='dark';
  st.setProperty('--hdr',dk?t.deep:t.light);st.setProperty('--accent',dk?t.light:t.deep);st.setProperty('--accent-soft',dk?'rgba(255,255,255,.08)':t.soft);st.setProperty('--hdr-fg',dk?'#f2f7fa':'#1a1a14')}
function annList(){const br=(byId('staff',ui.me)||{}).branchId;return S.announce.filter(a=>ui.isMgr||!a.branchId||a.branchId===br).sort((a,b)=>(b.at||'').localeCompare(a.at||''))}
const annUnread=()=>ui.me&&!ui.viewing?annList().filter(a=>!(a.reads||{})[ui.me]):[];
function pilotBars(){let h='';const au=ui.isMgr?[]:annUnread();
  if(au.length)h+=`<button class="hal hal-info" data-act="tab" data-t="news"><b>${au.length} new announcement${au.length>1?'s':''}</b><span> · ${esc(au[0].title)} · tap to read</span></button>`;
  if(ui.isMgr){const n=S.requests.filter(r=>r.status==='requested').length;if(n)h+=`<button class="hal hal-info" data-act="tab" data-t="req"><b>${n} resource request${n>1?'s':''} waiting</b><span> · tap to review</span></button>`}
  else{const seen=lsGet('rqseen_'+meKey())||'',up=S.requests.filter(r=>r.by===ui.me&&r.statusAt&&r.statusAt>seen);if(up.length)h+=`<button class="hal hal-info" data-act="tab" data-t="req"><b>Request update</b><span> · ${esc(up[0].item)} is now ${esc(up[0].status)}${up.length>1?` · +${up.length-1} more`:''}</span></button>`}
  const fu=S.contacts.filter(c=>c.followUp&&!c.fuDone&&c.followUp<=todayIso()&&(ui.isMgr||c.by===ui.me));
  if(fu.length)h+=`<button class="hal hal-bd" data-act="goto" data-k="child" data-v="${fu[0].childId}"><b>${fu.length} parent follow-up${fu.length>1?'s':''} due</b><span> · ${esc(nm('children',fu[0].childId))}</span></button>`;
  return h}
function vNews(){let h='';const staffN=br=>liveStaff().filter(x=>!br||x.branchId===br);
  if(ui.isMgr)h+=`<div class="card"><h3>Post an announcement</h3><label class="fld"><span>Title</span><input type="text" id="tf-an-title" placeholder="e.g. Staff meeting Friday 14:00"></label>
    <label class="fld"><span>Message</span><textarea id="tf-an-text" rows="3" placeholder="Details for staff"></textarea></label>
    <div class="grid2"><label class="fld"><span>For</span><select id="tf-an-br">${opt('branches','','All branches')}</select></label></div>
    <div class="actions"><button class="btn primary" data-act="annpost">Post announcement</button></div><span class="muted small">Staff see it at the top of Today until they tick "I have read this".</span></div>`;
  const l=annList();if(!l.length)return h+`<div class="card empty">No announcements yet.</div>`;
  l.forEach(a=>{const rd=a.reads||{},who=staffN(a.branchId),readN=who.filter(x=>rd[x.id]).length,notR=who.filter(x=>!rd[x.id]);
    h+=`<div class="card"><div class="row spread small muted"><span>${a.branchId?esc(nm('branches',a.branchId)):'All branches'}</span><span>${fmtAt(a.at)}</span></div><h3 style="margin:0">${esc(a.title)}</h3>${a.text?`<div class="fbtext">${esc(a.text)}</div>`:''}
    ${ui.isMgr?`<div class="row spread"><span class="pill ${readN===who.length?'done':'due'}">Read by ${readN} of ${who.length}</span><button class="btn sm danger" data-act="del" data-c="announce" data-id="${a.id}">${ui.confirmDel==='announce'+a.id?'Tap again':'Delete'}</button></div>${notR.length?`<div class="small muted">Not read yet: ${notR.map(x=>esc(staffLabel(x))).join(', ')}</div>`:''}`
      :rd[ui.me]?`<span class="pill done">Read ${fmtAt(rd[ui.me])}</span>`:`<div><button class="btn primary" data-act="annread" data-id="${a.id}">I have read this</button></div>`}</div>`});
  return h}
const RQ_PILL={requested:'due',ordered:'upcoming',delivered:'done',declined:'missed'};
function vReq(){let h=`<div class="card"><h3>Request resources</h3><div class="grid2"><label class="fld"><span>What do you need?</span><input type="text" id="tf-rq-item" placeholder="e.g. Finger paint, red and yellow"></label>
    <label class="fld"><span>How many</span><input type="text" id="tf-rq-qty" placeholder="e.g. 2 bottles"></label><label class="fld"><span>Needed by (optional)</span><input type="date" id="tf-rq-by"></label>
    <label class="fld"><span>Note (optional)</span><input type="text" id="tf-rq-note" placeholder="e.g. For Grade R art on Friday"></label></div>
    <div class="actions"><button class="btn primary" data-act="reqsave">Send request</button></div></div>`;
  const stf=ui.rqStatus||'';let l=S.requests.filter(r=>(ui.isMgr||r.by===ui.me)&&(!stf||r.status===stf)&&(!ui.isMgr||!ui.f.branch||r.branchId===ui.f.branch)).sort((a,b)=>(b.at||'').localeCompare(a.at||''));
  h+=`<div class="row spread"><h2>${ui.isMgr?'All requests':'My requests'} <span class="count">${l.length}</span></h2><select data-uiset="rqStatus" style="width:auto"><option value="">All statuses</option>${['requested','ordered','delivered','declined'].map(x=>`<option value="${x}"${x===stf?' selected':''}>${x[0].toUpperCase()+x.slice(1)}</option>`).join('')}</select></div>`;
  if(!l.length)return h+`<div class="card empty">No requests yet.</div>`;
  h+=`<div class="list">${l.map(r=>`<div class="li"><div class="lt"><b>${esc(r.item)}</b>${r.qty?` · ${esc(r.qty)}`:''}<div class="muted small">${[ui.isMgr&&(r.by==='manager'?'Manager':nm('staff',r.by)),r.branchId&&nm('branches',r.branchId),'asked '+fmtAt(r.at),r.needBy&&'needed by '+fmt(r.needBy),r.note].filter(Boolean).map(esc).join(' · ')}</div></div>
    <div class="acts"><span class="pill ${RQ_PILL[r.status]||''}">${esc(r.status)}</span>${ui.isMgr?['ordered','delivered','declined'].filter(x=>x!==r.status).map(x=>`<button class="btn sm${x==='declined'?' danger':''}" data-act="reqset" data-id="${r.id}" data-s="${x}">${x[0].toUpperCase()+x.slice(1)}</button>`).join(''):(r.status==='requested'?`<button class="btn sm" data-act="del" data-c="requests" data-id="${r.id}">${ui.confirmDel==='requests'+r.id?'Tap again':'Cancel'}</button>`:'')}</div></div>`).join('')}</div>`;
  return h}
function contactCard(cid){const c=byId('children',cid);if(!c)return '';const parents=[c.p1,c.p2].filter(Boolean);
  const l=S.contacts.filter(x=>x.childId===cid).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||(b.at||'').localeCompare(a.at||''));
  return `<div class="card"><h3>Parent contact log</h3><div class="grid2"><label class="fld"><span>Date</span><input type="date" id="tf-ct-date" value="${todayIso()}"></label>
    <label class="fld"><span>Type</span><select id="tf-ct-type">${['Call','Meeting (in person)','Meeting (on Zoom)','WhatsApp','Email','Other'].map(x=>`<option>${x}</option>`).join('')}</select></label>
    <label class="fld"><span>With</span><select id="tf-ct-with">${parents.map(p=>`<option>${esc(p)}</option>`).join('')}<option value="Parent">Parent (other)</option><option value="Guardian">Guardian</option></select></label>
    <label class="fld"><span>Follow up on (optional)</span><input type="date" id="tf-ct-fu"></label></div>
    <label class="fld"><span>What was discussed</span><textarea id="tf-ct-sum" rows="2" placeholder="e.g. Discussed Cayno's progress with counting; mom will practise at home"></textarea></label>
    <div class="actions"><button class="btn primary" data-act="ctsave">Log contact</button></div>
    ${l.length?`<div class="list">${l.map(x=>{const due=x.followUp&&!x.fuDone;return `<div class="li"><div class="lt"><b>${esc(x.type)}</b> · ${fmt(x.date)}${x.with?' · '+esc(x.with):''}<div class="small" style="white-space:pre-wrap">${esc(x.summary)}</div><div class="muted small">by ${x.by==='manager'?'Manager':esc(nm('staff',x.by))}${x.followUp?` · follow up ${fmt(x.followUp)}`:''}</div></div>
      <div class="acts">${due?`<span class="pill ${x.followUp<=todayIso()?'missed':'due'}">${x.followUp<=todayIso()?'Follow-up due':'Follow-up '+fmt(x.followUp)}</span><button class="btn sm" data-act="ctdone" data-id="${x.id}">Done</button>`:x.followUp?'<span class="pill done">Followed up</span>':''}${ui.isMgr||x.by===ui.me?`<button class="btn sm danger" data-act="del" data-c="contacts" data-id="${x.id}">${ui.confirmDel==='contacts'+x.id?'Tap again':'Delete'}</button>`:''}</div></div>`}).join('')}</div>`:'<div class="muted small">No contacts logged yet.</div>'}</div>`}

/* ---------- pilot: shared avatar helpers ---------- */
const ini=s=>{const w=String(s||'?').trim().split(/\s+/).filter(Boolean);return (w.length>1?w[0][0]+w[1][0]:(w[0]||'?').slice(0,2)).toUpperCase()};
const AVC=['#cfe6f3|#1a5a7e','#f5dbe5|#8a2a4f','#dcebdc|#2f6a3e','#f3e6c4|#6e4d10','#e6def3|#4f3a7a','#d8efeb|#1d6b62','#f6dfcf|#8a3f10','#e3eaee|#3c4a52'];
const hashI=s=>{let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))>>>0;return h};
const av=(id,name)=>{const [b,f]=AVC[hashI(id)%AVC.length].split('|');return `<span class="av" style="background:${b};color:${f}" aria-hidden="true">${esc(ini(name))}</span>`};
const dayWord=d=>fmt(d).split(' ')[0];
const relDay=d=>d===todayIso()?'Today':d===iso(addDays(parse(todayIso()),-1))?'Yesterday':fmt(d);

/* ---------- pilot: class planning ---------- */
function plBranch(){return ui.isMgr?(ui.f.branch||(ui.f.staff?(byId('staff',ui.f.staff)||{}).branchId:'')||''):myBranch()}
function classKids(){const br=plBranch();return sortByName('children').filter(c=>(!br||!c.branchId||c.branchId===br)&&(!ui.f.grade||c.gradeId===ui.f.grade))}
function classGroups(){const br=plBranch();return [...S.groups].filter(g=>!g.archived&&(!br||!g.branchId||g.branchId===br)).sort((a,b)=>(a.name||'').localeCompare(b.name||'',undefined,{numeric:true}))}
const kidsOf=p=>p.childIds&&p.childIds.length?p.childIds:(p.childId?[p.childId]:[]);
const grpKids=id=>((byId('groups',id)||{}).childIds||[]);
function whoLabel(p){const k=kidsOf(p);if(p.wholeClass)return 'Whole class';if(p.groupId&&byId('groups',p.groupId))return nm('groups',p.groupId)+' · '+k.length;if(k.length>1)return k.length+' children: '+k.map(c=>(nm('children',c)||'').split(' ')[0]).join(', ');return k.length?nm('children',k[0]):''}
const covers=(p,cid)=>p.wholeClass||kidsOf(p).includes(cid)||(!!p.groupId&&grpKids(p.groupId).includes(cid));
function plWhoMatch(p){const w=ui.plWho||'';if(!w)return true;
  if(w.startsWith('g:')){const g=byId('groups',w.slice(2));if(!g)return true;return p.groupId===g.id||p.wholeClass||kidsOf(p).some(c=>(g.childIds||[]).includes(c))}
  if(w.startsWith('c:'))return covers(p,w.slice(2));return true}
function plDaySel(){const ds=weekDates(ui.ws);if(!ds.includes(ui.plDay))ui.plDay=ds.includes(todayIso())?todayIso():ds[0];return ui.plDay}
function vPlanP(){
  if(ui.editing.plan) return vPlan();
  if(!S.staff.length&&loaded) return reminders()+setupFirst();
  if(ui.plBatch) return vPlanBatch();
  const ds=weekDates(ui.ws),d=plDaySel(),kids=classKids(),grps=classGroups(),w=ui.plWho||'';
  let h=reminders()+(PILOTNOTE?`<div class="row spread" style="margin-bottom:-4px"><h2 style="margin:0">Plan</h2>${qBar('plan')}</div>`:'')+`<div class="pwnav"><button class="iconx" data-act="wk" data-n="-1" aria-label="Previous week">‹</button><div class="wl"><b>Week ${isoWeek(ui.ws)}</b> · ${esc(fmt(ds[0]).slice(4))} – ${esc(fmt(ds[4]).slice(4))}${termLabel(ds[0])}</div><button class="iconx" data-act="wk" data-n="1" aria-label="Next week">›</button><button class="btn sm primary" data-act="pltoday">${PILOTNOTE?'This week':'Today'}</button></div>`;
  if(ui.mgr) h+=filtersCard();
  h+=`<div class="wk5">${ds.map(x=>{const ps=plansFor([x]),dn=ps.filter(p=>p.done).length,lab=ps.length?(dn===ps.length?dn+' ✓':ps.length+' planned'):'empty';
    return `<button class="wkd${x===d?' on':''}${ps.length?'':' empty'}" data-act="plday" data-d="${x}" aria-pressed="${x===d}"><span>${esc(dayWord(x))}</span><b>${parse(x).getDate()}</b><small>${lab}</small>${bdStars(x)}</button>`}).join('')}</div>`;
  if(kids.length>1) h+=`<div class="chiprow" role="group" aria-label="Show planning for">${[['','All '+kids.length],...grps.map(g=>['g:'+g.id,g.name]),...kids.map(c=>['c:'+c.id,(c.name||'').split(' ')[0]])].map(([v,l])=>`<button class="chip${v===w?' on':''}" data-act="plwho" data-v="${v}" aria-pressed="${v===w}">${esc(l)}</button>`).join('')}</div>`;
  h+=`<div class="plbar"><button class="btn primary" data-act="psopen" data-d="${d}">+ Add activity</button><button class="btn" data-act="pbopen" data-d="${d}">Plan the whole day</button><button class="btn" data-act="copyweek">Copy last week</button></div>`;
  h+=papBox();
  if(!w&&kids.length>1){const wk=plansFor(ds),miss=kids.filter(c=>!wk.some(p=>covers(p,c.id)));
    if(miss.length&&miss.length<kids.length) h+=`<div class="banner warnb"><span class="small"><b>No planning this week yet for:</b> ${miss.map(c=>esc((c.name||'').split(' ')[0])).join(', ')}</span></div>`}
  const ps=plansFor([d]).filter(plWhoMatch),bs=breaksFor(),ts=testsOnDate(d),tk=w?[]:itemsFor([d]);
  h+=`<div class="row spread"><h2 style="margin:0">${esc(fmt(d))}${d===todayIso()?' · Today':''}</h2><span class="row" style="gap:10px"><span class="muted small">${ps.length} planned${tk.length?` · ${tk.length} task${tk.length>1?'s':''}`:''}</span>${planView()}</span></div>`;
  h+=planLockBanner(d);if(!PILOTNOTE)ts.forEach(t=>h+=testBanner(t));
  const used=new Set(ps.map(p=>p.periodId).filter(Boolean)),usedSt=new Set(ps.map(p=>oStart(p)));
  const free=periodsSorted().filter(x=>!used.has(x.id)&&!usedSt.has(x.start||'~'));
  const rows=[...tk.map(i=>({s:oStart(i.r),html:PILOTNOTE&&!ui.planFull?`<div class="pslim">${chkRowTask(i)}</div>`:itemHtml(i)})),...ps.map(p=>({s:oStart(p),html:PILOTNOTE&&!ui.planFull?`<div class="pslim">${chkRowPlan(p)}</div>`:planHtml(p)})),...(PILOTNOTE?ts.map(t=>({s:t.time||'00',html:testRow(t)})):[]),
    ...bs.map(x=>({s:x.start||'99',html:`<div class="brk${PILOTNOTE?' pthin':''}"><span class="pill">Break</span><span>${esc(x.name||'Break')} · ${esc(x.start||'')}${x.end?'–'+esc(x.end):''}</span></div>`})),
    ...bdRows(d).map(x=>({s:'06:55',html:PILOTNOTE?`<div class="pthin pbd${x.boy?' boy':''}"><span class="bstar sm" aria-hidden="true">★</span><span>${esc(x.t)}</span></div>`:`<div class="brk bdrow"><span class="pill due">Birthday</span><span>${esc(x.t)}</span></div>`})),
    ...free.map(x=>({s:x.start||'99',html:`<button class="slotadd" data-act="psopen" data-d="${d}" data-slot="${x.id}">+ Add activity · ${esc(periodLabel(x))}</button>`}))].sort((a,b)=>a.s.localeCompare(b.s));
  h+=ps.length||tk.length||bdRows(d).length||(PILOTNOTE&&ts.length)?`<div class="ptl${PILOTNOTE?' thin':''}">${rows.map(r=>`<div class="ptlt">${r.s==='99'?'':esc(r.s)}</div><div class="ptlc">${r.html}</div>`).join('')}</div>`
    :`<div class="card empty">Nothing planned for ${esc(fmt(d))} yet.<div class="plbar" style="justify-content:center"><button class="btn primary" data-act="pbopen" data-d="${d}">Plan the whole day</button><button class="btn" data-act="psopen" data-d="${d}">+ Add one activity</button></div></div>`;
  h+=extraForms()+psSheet();
  return h}
function psInit(d,slot){const p=byId('periods',slot);ui.ps={date:d,slot:p?p.id:'',start:p?p.start||'':'',end:p?p.end||'':'',who:'',kids:[],topicId:'',curriculumId:'',text:'',rep:false,staff:ui.isMgr?(ui.f.staff||''):ui.me,gname:''};ui.clash=null;ui.clear.add('tf-ps-')}
function psGrab(){const s=ui.ps;if(!s)return;const g=id=>document.getElementById(id);
  if(g('tf-ps-text'))s.text=g('tf-ps-text').value;if(g('tf-ps-start'))s.start=g('tf-ps-start').value;if(g('tf-ps-end'))s.end=g('tf-ps-end').value;
  if(g('tf-ps-rep'))s.rep=g('tf-ps-rep').checked;if(g('tf-ps-test'))s.isTest=g('tf-ps-test').checked;if(g('tf-ps-staff'))s.staff=g('tf-ps-staff').value;if(g('tf-ps-gname'))s.gname=g('tf-ps-gname').value}
function psKids(){const s=ui.ps;if(s.who==='class')return classKids().map(c=>c.id);if(s.who.startsWith('g:'))return grpKids(s.who.slice(2));return s.kids}
function psSheet(){const s=ui.ps;if(!s)return '';const ds=weekDates(ui.ws),kids=classKids(),grps=classGroups(),sel=psKids();
  const chip=(act,v,l,on,extra='')=>`<button type="button" class="chip${on?' on':''}" data-act="${act}" data-v="${esc(v)}" aria-pressed="${!!on}"${extra}>${l}</button>`;
  const sid=ui.isMgr?s.staff:ui.me,used=new Set(S.plans.filter(p=>p.date===s.date&&(!sid||p.staffId===sid)).map(p=>p.periodId).filter(Boolean));
  const tops=[...S.topics].sort((a,b)=>(a.name||'').localeCompare(b.name||''));
  const sugg=[...new Set(S.plans.filter(p=>(!s.topicId||p.topicId===s.topicId)&&p.text).sort((a,b)=>(b.updated||'').localeCompare(a.updated||'')).map(p=>p.text.trim()))].slice(0,8);
  const whoTxt=s.who==='class'?'Whole class':s.who.startsWith('g:')?nm('groups',s.who.slice(2)):sel.length===1?(nm('children',sel[0])||'').split(' ')[0]:sel.length?sel.length+' children':'';
  const tm=s.start?s.start:'',lab=[tm,s.text&&(s.text.length>22?s.text.slice(0,22)+'…':s.text)||tName(s.topicId),whoTxt].filter(Boolean).join(' · ');
  return `<div class="psheet"><div class="in" role="dialog" aria-modal="true" aria-label="Add activity">
  <div class="row spread"><h3 style="margin:0">Add activity · ${esc(fmt(s.date))}</h3><button type="button" class="iconx" data-act="psclose" aria-label="Close">×</button></div>
  ${ui.isMgr?`<label class="fld"><span>Staff member</span><select id="tf-ps-staff">${opt('staff',s.staff,'Choose staff')}</select></label>`:''}
  <div class="pss"><div class="psl">Day</div><div class="chips">${ds.map(x=>chip('psday',x,esc(fmt(x).split(' ').slice(0,2).join(' ')),x===s.date)).join('')}</div></div>
  <div class="pss"><div class="psl">1 · Time slot</div><div class="chips">${periodsSorted().map(x=>chip('psslot',x.id,esc(x.start?(x.start+(x.end?'–'+x.end:'')):(x.name||'Period'))+(used.has(x.id)?' <small>· used</small>':''),x.id===s.slot)).join('')}${chip('psslot','own','Own time',s.slot==='own')}</div>
  ${s.slot==='own'?`<div class="grid2"><label class="fld"><span>From</span><select id="tf-ps-start">${timeOpts(s.start,'—')}</select></label><label class="fld"><span>To</span><select id="tf-ps-end">${timeOpts(s.end,'—')}</select></label></div>`:''}</div>
  <div class="pss"><div class="psl">2 · Who</div>
    <div class="chips">${kids.length>1?chip('pswho','class',`Whole class <small>${kids.length}</small>`,s.who==='class'):''}${grps.map(g=>chip('pswho','g:'+g.id,`${esc(g.name)} <small>${(g.childIds||[]).length}</small>`,s.who==='g:'+g.id)).join('')}</div>
    ${kids.length?`<div class="small muted">${kids.length>1?'Or tap names:':''}</div><div class="chips">${kids.map(c=>chip('pskid',c.id,(sel.includes(c.id)?'✓ ':'')+esc((c.name||'').split(' ')[0]),sel.includes(c.id))).join('')}</div>`:'<span class="muted small">No children for this branch yet. Add them in Setup → Children.</span>'}
    ${sel.length?`<div class="small"><b>${sel.length} selected</b></div>`:''}
    ${sel.length>1&&!s.who?`<div class="addnew"><input type="text" id="tf-ps-gname" placeholder="Save these ${sel.length} as a group, e.g. Group A" aria-label="Group name"><button type="button" class="btn sm" data-act="psgroup">Save group</button></div>`:''}</div>
  <div class="pss"><div class="psl">3 · Subject</div><div class="chips">${tops.map(t=>chip('pstopic',t.id,esc(t.name),t.id===s.topicId)).join('')||'<span class="muted small">Add subjects in Setup → Subjects.</span>'}</div></div>
  <div class="pss"><div class="psl">4 · Activity</div>${sugg.length?`<div class="chips">${sugg.map(x=>chip('pstext',x,esc(x.length>28?x.slice(0,28)+'…':x),x===s.text)).join('')}</div>`:''}
    <input type="text" id="tf-ps-text" value="${esc(s.text)}" placeholder="What will you do? e.g. Phonics with picture cards" aria-label="Activity"></div>
  <label class="row" style="gap:8px;min-height:40px"><input type="checkbox" id="tf-ps-rep"${s.rep?' checked':''}> Repeat every ${esc(dayWord(s.date))} this term</label>
  <label class="row" style="gap:8px;min-height:40px"><input type="checkbox" id="tf-ps-test"${s.isTest?' checked':''}> This is a test (adds a test reminder 3 days before; needs a start and end time)</label>
  ${clashBox('ps')}
  <button type="button" class="btn primary big" data-act="pssave">${ui.clash&&ui.clash.f==='ps'?'Save anyway':'Save'+(lab?' · '+esc(lab):'')}</button>
  </div></div>`}
function pbSrcDate(d,src){const dt=parse(d);if(src==='last')return iso(addDays(dt,-7));if(src==='mon')return iso(addDays(dt,-((dt.getDay()+6)%7)));
  if(src==='prev'){let p=addDays(dt,-1);while(p.getDay()===0||p.getDay()===6)p=addDays(p,-1);return iso(p)}return ''}
function vPlanBatch(){const d=ui.plBatch,b=ui.pb||(ui.pb={src:'last'}),sid=ui.isMgr?(ui.pbStaff!==undefined?ui.pbStaff:(ui.f.staff||'')):ui.me;
  const sd=pbSrcDate(d,b.src),src=sd?S.plans.filter(p=>p.date===sd&&(!sid||p.staffId===sid)).sort((x,y)=>oStart(x).localeCompare(oStart(y))):[];
  b.rows=src.map(p=>p.id);const kids=classKids(),grps=classGroups(),bs=breaksFor(),exists=S.plans.filter(p=>p.date===d&&(!sid||p.staffId===sid));
  const whoOpts=p=>{const k=kidsOf(p),cur=p.wholeClass?'class':p.groupId?'g:'+p.groupId:k.length===1?'c:'+k[0]:k.length?'keep':'';
    return [...(cur===''?[['','—']]:[]),...(cur==='keep'?[['keep',k.length+' children (as before)']]:[]),['class','Whole class'],...grps.map(g=>['g:'+g.id,g.name]),...kids.map(c=>['c:'+c.id,c.name])].map(([v,l])=>`<option value="${v}"${v===cur?' selected':''}>${esc(l)}</option>`).join('')};
  let h=`<div class="card"><div class="row spread"><button class="btn sm" data-act="pbclose">‹ Back to planning</button><span class="muted small">${exists.length} already planned</span></div>
    <h2 style="margin:0">Plan ${esc(fmt(d))}</h2><span class="small muted">Fill the whole day and save once.</span>
    ${ui.isMgr?`<label class="fld"><span>Staff member</span><select data-uiset="pbStaff">${opt('staff',sid,'All staff')}</select></label>`:''}
    <div class="psl">Start from</div><div class="chips">${[['last','Last '+dayWord(d)],['prev','Day before'],['mon','This Monday'],['empty','Empty day']].filter(x=>!(x[0]==='mon'&&parse(d).getDay()===1)).map(([v,l])=>`<button class="chip${b.src===v?' on':''}" data-act="pbsrc" data-v="${v}" aria-pressed="${b.src===v}">${esc(l)}</button>`).join('')}</div></div>`;
  if(b.src==='empty') h+=`<div class="card empty">Start with an empty day and add activities one by one.<button class="btn primary" data-act="psopen" data-d="${d}">+ Add activity</button></div>`;
  else if(!src.length) h+=`<div class="card empty">Nothing was planned on ${esc(fmt(sd))} to copy. Try another start, or add activities one by one.<button class="btn" data-act="psopen" data-d="${d}">+ Add activity</button></div>`;
  else{h+=`<div class="small muted">Copied from ${esc(fmt(sd))}. Untick what you don't want and change who takes part.</div><div class="card pbl">`+
    [...src.map((p,i)=>({s:oStart(p),h:`<div class="pbr"><input type="checkbox" id="tf-pb-c-${i}" checked aria-label="Include ${esc(p.text)}"><span class="pbt">${esc(oStart(p)==='99'?'':oStart(p))}</span><span class="pbx"><b>${esc(p.text)}</b><small>${esc([p.topicId&&tName(p.topicId),!sid&&nm('staff',p.staffId)].filter(Boolean).join(' · '))}</small></span><select id="tf-pb-w-${i}" aria-label="Who takes part in ${esc(p.text)}">${whoOpts(p)}</select></div>`})),
     ...bs.map(x=>({s:x.start||'99',h:`<div class="pbr brkr"><span></span><span class="pbt">${esc(x.start||'')}</span><span class="pbx small muted">${esc(x.name||'Break')}</span><span></span></div>`}))]
    .sort((a,c)=>a.s.localeCompare(c.s)).map(r=>r.h).join('')+`</div>
    <label class="row" style="gap:8px;min-height:40px"><input type="checkbox" id="tf-pb-rep"> Also plan this for every ${esc(dayWord(d))} this term</label>
    <button class="btn primary big" data-act="pbsave">Save ticked activities for ${esc(fmt(d))}</button>`}
  return h+psSheet()}

/* ---------- pilot: WhatsApp-style inbox ---------- */
const ibSeenK=sid=>'ibt_'+meKey()+'_'+sid;
const ibSeen=sid=>lsGet(ibSeenK(sid))||lsGet(seenKey('inbox'))||'';
function ibEvents(sid){const ev=[];
  S.feedback.filter(f=>f.from===sid||((f.to===sid||f.to==='*')&&(!f.from||f.from==='manager'))).forEach(f=>{
    if(f.to!=='*'||f.from===sid)ev.push({t:'f',at:f.at||'',f,me:isMine(f)});
    S.replies.filter(r=>r.fid===f.id&&(r.by==='manager'||r.by===sid)).forEach(r=>ev.push({t:'r',at:r.at||'',r,f,me:r.by==='manager'}));
    if(!f.from||f.from==='manager'){const t=(f.doneBy||{})[sid];if(t)ev.push({t:'d',at:t,f,me:false})}});
  photoRecs().filter(x=>x.sid===sid&&x.staffPh).forEach(x=>ev.push({t:'p',at:x.at||x.date||'',x,me:false}));
  return ev.filter(e=>ibVisible(sid,e)).sort((a,b)=>a.at.localeCompare(b.at))}
function ibThreads(){return liveStaff().map(s=>{const ev=ibEvents(s.id),seen=ibSeen(s.id);return {sid:s.id,ev,last:ev[ev.length-1],unread:ev.filter(e=>!e.me&&e.at>seen&&!(e.t==='f'&&e.f.deleted)).length}})
  .filter(t=>t.ev.length).sort((a,b)=>(b.last.at||'').localeCompare(a.last.at||''))}
function ibPrev(e){if(!e)return '';if(e.t==='p')return 'Photo · '+e.x.text;if(e.t==='d')return 'Marked done · '+e.f.text;if(e.t==='r')return (e.me?'You: ':'')+e.r.text;
  const f=e.f;if(f.deleted)return 'Deleted a message';const k=fbKind(f);return (e.me?'You: ':'')+(k==='fb'||k==='staff'?'':KIND_LABEL[k]+' · ')+f.text}
const hhmm=at=>{try{return new Date(at).toTimeString().slice(0,5)}catch(e){return ''}};
const ibTime=at=>{if(!at)return '';const d=at.slice(0,10);return d===todayIso()?hhmm(at):relDay(d)==='Yesterday'?'Yesterday':fmt(d).split(' ').slice(1,3).join(' ')};
function ibApprovals(){const out=[];
  S.feedback.forEach(f=>{if(f.deleted)return;
    if(f.kind==='unlock'&&f.scope==='week'){if(wkLock(f.from,f.date)&&!f.closed)out.push({at:f.at,sid:f.from,txt:'Unlock week '+isoWeek(parse(f.date))+' planning',note:f.text,btn:`<button class="btn sm primary" data-act="unlockweek" data-s="${f.from}" data-d="${f.date}">Unlock</button>`})}
    else if(f.kind==='unlock'){const open=(f.scope==='plan'?plocked(f.from,f.date):signed(f.from,f.date))&&!f.closed;
      if(open)out.push({at:f.at,sid:f.from,txt:(f.scope==='plan'?'Unlock planning · ':'Unlock checklist · ')+fmt(f.date),note:f.text,btn:`<button class="btn sm primary" data-act="${f.scope==='plan'?'unlockplan':'unlockday'}" data-s="${f.from}" data-d="${f.date}">Unlock</button>`})}
    else if(!f.from||f.from==='manager')Object.entries(f.doneBy||{}).forEach(([k,t])=>{if(!(f.approvedFor||{})[k])out.push({at:t,sid:k,txt:'Done · '+f.text,btn:`<button class="btn sm primary" data-act="fbapprove" data-id="${f.id}" data-s="${k}">Approve</button><button class="btn sm" data-act="fbreopen" data-id="${f.id}" data-s="${k}">Not yet</button>`})})});
  S.papprove.forEach(r=>{if(r.status!=='submitted')return;const n=S.plans.filter(p=>p.staffId===r.staffId&&weekDates(parse(r.ws)).includes(p.date)).length;
    out.push({at:r.at,sid:r.staffId,txt:`Week ${isoWeek(parse(r.ws))} planning · ${n} activities`,btn:`<button class="btn sm primary" data-act="papok" data-id="${r.id}">Approve</button><button class="btn sm" data-act="ibplan" data-s="${r.staffId}" data-ws="${r.ws}">Open week</button>`})});
  S.leavereq.forEach(r=>{if(r.status!=='pending')return;out.push({at:r.at,sid:r.staffId,txt:`${r.type} · ${fmt(r.from)}${r.to&&r.to!==r.from?' – '+fmt(r.to):''}`,note:r.note,btn:`<button class="btn sm" data-act="tab" data-t="leave">Open leave</button>`})});
  return out.sort((a,b)=>(b.at||'').localeCompare(a.at||''))}
function vInboxP(){if(ui.ibChat&&byId('staff',ui.ibChat))return ibThread(ui.ibChat);
  const tab=ui.ibTab||'chats',ap=ibApprovals(),th=ibThreads(),ph=photoRecs().filter(x=>x.staffPh);
  let h=`<div class="ibtabs" role="tablist" aria-label="Inbox">${[['chats','Chats',th.filter(t=>t.unread).length],['appr','Approvals',ap.length],['photos','Photos',0]].map(([k,l,n])=>`<button role="tab" aria-selected="${k===tab}" class="${k===tab?'on':''}" data-act="ibtab" data-v="${k}">${l}${n?` <span class="ibn">${n}</span>`:''}</button>`).join('')}</div>`;
  if(tab==='chats'){const f=ui.ibFilt||'',list=th.filter(t=>!f||t.unread);
    h+=`<div class="chips">${[['','All'],['u','Unread']].map(([v,l])=>`<button class="chip${v===f?' on':''}" data-act="ibfilt" data-v="${v}" aria-pressed="${v===f}">${l}</button>`).join('')}</div>`;
    h+=list.length?`<div class="iblist">${list.map(t=>{const s=byId('staff',t.sid);return `<button class="ibrow" data-act="ibopen" data-s="${t.sid}">${av(t.sid,staffLabel(s))}<span class="ibm"><b>${esc(staffLabel(s))}</b><span class="${t.unread?'ub':''}">${esc(ibPrev(t.last))}</span></span><span class="ibr"><span class="${t.unread?'tn':''}">${esc(ibTime(t.last.at))}</span>${t.unread?`<span class="ibn">${t.unread}</span>`:''}</span></button>`}).join('')}</div>`
      :`<div class="card empty">${f?'No unread chats.':'No messages yet.'}</div>`}
  else if(tab==='appr') h+=ap.length?`<div class="iblist">${ap.map(a=>`<div class="ibrow ibap">${av(a.sid,nm('staff',a.sid))}<span class="ibm"><b>${esc(nm('staff',a.sid))} <small class="muted">· ${esc(ibTime(a.at))}</small></b><span class="ub">${esc(a.txt)}</span>${a.note?`<span>${esc(a.note)}</span>`:''}</span><span class="acts">${a.btn}</span></div>`).join('')}</div>`+(PILOTNOTE?apprHist():''):'<div class="card empty">Nothing waiting for approval.</div>'+(PILOTNOTE?apprHist():'');
  else h+=ph.length?ph.slice(0,40).map(x=>`<div class="card"><div class="row spread small muted"><span><b>${esc(nm('staff',x.sid))}</b> · ${x.kind} · ${esc(x.text)}</span><span>${esc(fmt(x.date))}</span></div>${phGrid(x)}</div>`).join(''):'<div class="card empty">No photos from staff yet.</div>';
  return h}
function ibThread(sid){const s=byId('staff',sid),ev=ibEvents(sid);
  if(ev.length&&ev[ev.length-1].at>ibSeen(sid))lsSet(ibSeenK(sid),new Date().toISOString());
  let h=`<div class="ibhead"><button class="iconx" data-act="ibback" aria-label="Back to chats">‹</button>${av(sid,staffLabel(s))}<div style="flex:1;min-width:0"><b>${esc(staffLabel(s))}</b><div class="small">${esc([nm('branches',(s||{}).branchId),s&&s.role].filter(Boolean).join(' · '))}</div></div><span class="ibhb">${ui.ibSel?'<button class="btn sm" data-act="ibselx">Cancel</button>':`<button class="btn sm" data-act="ibselon">Select</button><button class="btn sm danger" data-act="ibclear" data-s="${sid}">${ui.confirmDel==='ibchat'+sid?'Yes, delete':'Delete chat'}</button>`}</span></div>${ui.confirmDel==='ibchat'+sid?'<div class="banner"><span class="small">This removes the whole chat from your inbox. Staff keep their own copy. Tap <b>Yes, delete</b> to confirm.</span></div>':''}<div class="ibchat${ui.ibSel?' selm':''}">`;
  let day='';
  ev.forEach(e=>{const d=(e.at||'').slice(0,10);if(d&&d!==day){day=d;h+=`<div class="dpill">${esc(relDay(d))}</div>`}
    let body='',cls=e.me?'bub me':'bub';
    if(e.t==='f'){const f=e.f,k=fbKind(f),lab=f.to==='*'?'To all staff':k==='fb'?'':k==='staff'?'To '+nm('staff',f.to):KIND_LABEL[k]+(f.date?' · '+fmt(f.date):'');
      if(f.deleted){cls+=' gone';body=`<s>${esc(f.text)}</s><div class="small muted">Deleted by ${esc(nm('staff',f.deletedBy))}</div>`}
      else body=`${lab?`<div class="bl">${esc(lab)}</div>`:''}<div class="bt">${esc(f.text)}</div>${f.kind==='unlock'?fbStatus(f):''}`}
    else if(e.t==='r') body=`<div class="bq">${esc((e.f.text||'').slice(0,90))}</div><div class="bt">${esc(e.r.text)}</div>`;
    else if(e.t==='d'){const ok=(e.f.approvedFor||{})[sid];body=`<div class="bl">Marked as done</div><div class="bt">${esc(e.f.text)}</div>${ok?'<span class="pill done">Approved</span>':`<div class="row" style="gap:6px"><button class="btn sm primary" data-act="fbapprove" data-id="${e.f.id}" data-s="${sid}">Approve</button><button class="btn sm" data-act="fbreopen" data-id="${e.f.id}" data-s="${sid}">Not yet</button></div>`}`}
    else if(e.t==='p'){cls+=' ph';body=`${phGrid(e.x)}<div class="bl">${esc(e.x.kind)} · ${esc(e.x.text)}</div>`}
    const k=ibKey(e),sl=!!(ui.ibSel&&ui.ibSel.has(k));
    h+=`<div class="${cls}${sl?' sel':''}">${ui.ibSel?`<button class="bsel" data-act="ibsel" data-k="${esc(k)}" aria-pressed="${sl}" aria-label="Select message">${sl?'✓':''}</button>`:''}${body}<div class="bm">${esc(hhmm(e.at))}</div></div>`});
  if(!ev.length)h+='<div class="muted small" style="text-align:center;padding:20px">No messages yet.</div>';
  if(ui.ibSel){const n=ui.ibSel.size;return h+`</div><div class="ibcomp"><button class="btn danger" data-act="ibseldel" data-s="${sid}"${n?'':' disabled'}>${ui.confirmDel==='ibsel'+sid?'Yes, delete '+n:'Delete '+n+' selected'}</button><button class="btn" data-act="ibselx">Cancel</button></div><div class="small muted">Deleting removes messages from your inbox only. Staff keep their own copy.</div>`}
  h+=`</div><form class="ibcomp" data-act="ibsend" data-s="${sid}"><input type="text" id="tf-ibc" placeholder="Message ${esc((staffLabel(s)||'').split(' ')[0])}" autocomplete="off" aria-label="Message to ${esc(staffLabel(s))}"><button class="btn primary" type="submit">Send</button></form>`;
  return h}

/* ---------- pilot round 3 ---------- */
const workDays=(a,b)=>{let n=0,d=parse(a);const e=parse(b||a);while(d<=e){const w=d.getDay();if(w&&w<6)n++;d=addDays(d,1)}return n};
const seenAt=k=>lsGet('p3_'+k+'_'+meKey())||'';
const markSeen=k=>lsSet('p3_'+k+'_'+meKey(),new Date().toISOString());
const fullTab=(t,label,h)=>`<button class="hal hal-info" data-act="tab" data-t="${t}"><b>${label}</b>${h?`<span> · ${h}</span>`:''}</button>`;

const BELL='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>';
function noticesHtml(){const pb=pilotBars();return backupDue()+testBars()+pb+pilotBars3()+fbNotice()+homeMissed()+homeBday()}
/* test reminders on Today */
function testBars(){const t=todayIso();
  const list=ui.isMgr?S.tests.filter(x=>x.date&&x.date>=t&&daysBetween(t,x.date)<=(Number(x.lead)||3)&&(!ui.f.branch||!x.branchId||x.branchId===ui.f.branch)).sort((a,b)=>a.date.localeCompare(b.date)):(ui.me?testsFor(ui.me):[]);
  return list.slice(0,4).map(x=>{const d=daysBetween(t,x.date),when=d===0?'Today':d===1?'Tomorrow':'In '+d+' days';
    const what=[tName(x.topicId)||x.title||'Test',x.childId&&nm('children',x.childId),ui.isMgr&&x.staffId&&nm('staff',x.staffId)].filter(Boolean).map(esc).join(' · ');
    return `<button class="hal hal-test" data-act="pltest" data-d="${x.date}"><span class="tico" aria-hidden="true">✎</span><span class="hal-t"><b>Test ${when.toLowerCase()} · ${esc(fmt(x.date))}${x.time?' at '+esc(x.time):''}</b><span>${what}</span></span></button>`}).join('')}

/* 4 weekly plan approval */
const papId=(sid,ws)=>sid+'_'+ws;
function papBox(){const sid=ui.isMgr?ui.f.staff:ui.me;if(!sid||sid==='*')return '';const ws=iso(ui.ws),r=byId('papprove',papId(sid,ws)),n=S.plans.filter(p=>p.staffId===sid&&weekDates(ui.ws).includes(p.date)).length;
  const wk='week '+isoWeek(ui.ws);
  if(ui.isMgr){if(!r)return n?`<div class="banner"><span class="small">${esc(nm('staff',sid))} has not submitted ${wk} planning for approval yet (${n} planned).</span></div>`:'';
    return `<div class="banner ${r.status==='approved'?'okb':''}"><div class="row spread"><span><b>${esc(nm('staff',sid))} · ${wk} planning</b><br><span class="small">${r.status==='approved'?'Approved '+esc(fmtAt(r.decidedAt)):r.status==='changes'?'Changes asked: '+esc(r.note||''):'Submitted '+esc(fmtAt(r.at))+' · '+n+' activities'}</span></span>${r.status==='submitted'?`<span class="acts"><button class="btn sm primary" data-act="papok" data-id="${r.id}">Approve</button>${PILOTNOTE?`<button class="btn sm" data-act="unlockweek" data-s="${r.staffId}" data-d="${r.ws}">Unlock</button>`:''}</span>`:PILOTNOTE&&r.status==='approved'?`<span class="acts"><button class="btn sm" data-act="unlockweek" data-s="${r.staffId}" data-d="${r.ws}">Unlock</button></span>`:''}</div>${r.status==='submitted'?`<div class="addnew"><input type="text" id="tf-pch-${r.id}" placeholder="What should change?" aria-label="Changes needed"><button class="btn sm" data-act="papchg" data-id="${r.id}">Ask for changes</button></div>`:''}</div>`}
  if(!r)return `<div class="banner"><div class="row spread"><span class="small"><b>${wk} planning</b> · ${n} activit${n===1?'y':'ies'} planned. When it is ready, send it to your manager.</span><button class="btn sm primary" data-act="papsend"${n?'':' disabled'}>Submit for approval</button></div></div>`;
  if(r.status==='approved'&&PILOTNOTE){const q=wkReq(sid,ws);return `<div class="banner okb"><div class="row spread"><span class="small"><b>${wk} planning approved</b> · ${esc(fmtAt(r.decidedAt))}<br>Approved planning is locked.</span>${q?'<span class="pill due">Unlock requested</span>':`<button class="btn sm" data-act="requnlock" data-scope="week" data-d="${ws}">Request unlock</button>`}</div></div>`}
  if(r.status==='approved')return `<div class="banner okb"><span class="small"><b>${wk} planning approved</b> · ${esc(fmtAt(r.decidedAt))}</span></div>`;
  if(r.status==='changes')return `<div class="banner"><div class="row spread"><span class="small"><b>Your manager asked for changes to ${wk}:</b> ${esc(r.note||'See messages')}</span><button class="btn sm primary" data-act="papsend">Submit again</button></div></div>`;
  if(PILOTNOTE){const q=wkReq(sid,ws);return `<div class="banner info"><div class="row spread"><span class="small"><b>${wk} planning submitted</b> · waiting for your manager · ${esc(fmtAt(r.at))}<br>You can't change this week's planning while it is with your manager.</span>${q?'<span class="pill due">Unlock requested</span>':`<button class="btn sm" data-act="requnlock" data-scope="week" data-d="${ws}">Request unlock</button>`}</div></div>`}
  return `<div class="banner info"><span class="small"><b>${wk} planning submitted</b> · waiting for your manager · ${esc(fmtAt(r.at))}</span></div>`}

/* 9 mood check-in */
const MOODS=[[1,'😢','1 · Sad or upset'],[2,'🙁','2 · Unhappy'],[3,'😐','3 · Okay'],[4,'🙂','4 · Good'],[5,'😄','5 · Happy']];
const moodOf=(d,cid)=>byId('mood',d+'_'+cid);
function moodBtns(d,c){const m=moodOf(d,c.id);return `<div class="moodrow" role="group" aria-label="Mood for ${esc(c.name)}"><span class="small muted">Mood</span>${MOODS.map(([v,e,l])=>`<button class="mood${m&&m.mood===v?' on':''}" data-act="moodset" data-d="${d}" data-c="${c.id}" data-v="${v}" aria-label="${l}" aria-pressed="${!!(m&&m.mood===v)}" title="${l}">${e}<i>${v}</i></button>`).join('')}</div>`}
function moodCard(cid){const days=[];let d=parse(todayIso());while(days.length<10){if(d.getDay()&&d.getDay()<6)days.unshift(iso(d));d=addDays(d,-1)}
  return `<div class="card"><h3>Mood · last 2 weeks</h3><div class="moodstrip">${days.map(x=>{const m=moodOf(x,cid),mo=m&&MOODS.find(k=>k[0]===m.mood);return `<div class="ms"><span class="me" aria-label="${mo?mo[2]:'Not recorded'}">${mo?mo[1]:'·'}</span><b class="mr">${mo?mo[0]+'/5':'&nbsp;'}</b><small>${esc(fmt(x).split(' ')[0])}<br>${esc(fmt(x).split(' ')[1])}</small></div>`}).join('')}</div><div class="row spread"><span class="small muted">Rated 1 (sad or upset) to 5 (happy) on the Register each morning.${(()=>{const ms=S.mood.filter(m=>m.childId===cid);return ms.length?' Average: <b>'+(Math.round(ms.reduce((a,m)=>a+m.mood,0)/ms.length*10)/10)+' / 5</b> over '+ms.length+' day'+(ms.length>1?'s':''):''})()}</span><button class="btn sm" data-act="moodxl" data-c="${cid}">Export to Excel</button></div></div>`}

/* 27 absence and mood alerts */
function kidsScope(){const br=ui.isMgr?(ui.f.branch||''):myBranch();return sortByName('children').filter(c=>!br||c.branchId===br)}
function absAlerts(){const t=todayIso(),from=iso(addDays(parse(t),-14)),out=[];
  kidsScope().forEach(c=>{const ab=S.attendance.filter(a=>a.childId===c.id&&!a.present&&a.date>=from&&a.date<=t);
    if(ab.length>=3){out.push({cid:c.id,txt:`${c.name} absent ${ab.length} times in 2 weeks`});return}
    const byDay={};S.attendance.filter(a=>a.childId===c.id&&!a.present&&a.date>=iso(addDays(parse(t),-28))).forEach(a=>{const w=parse(a.date).getDay();byDay[w]=(byDay[w]||0)+1});
    const w=Object.keys(byDay).find(k=>byDay[k]>=3);if(w)out.push({cid:c.id,txt:`${c.name} often absent on ${DAYS_LONG[w]}s (${byDay[w]} of the last 4)`})});
  kidsScope().forEach(c=>{const ms=S.mood.filter(m=>m.childId===c.id).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,3);if(ms.length===3&&ms.every(m=>m.mood<=2))out.push({cid:c.id,txt:`${c.name} upset 3 days in a row`,mood:true})});
  return out}

/* 16 leave requests + 24 sick note */
const LV_TYPES=['Annual leave','Sick leave','Family responsibility','Study leave','Unpaid leave','Other'];
function vLeave(){let h='';const mine=S.leavereq.filter(r=>r.staffId===ui.me).sort((a,b)=>(b.at||'').localeCompare(a.at||''));
  if(ui.me) h+=`<div class="card"><h3>Apply for leave</h3><div class="grid2"><label class="fld"><span>Type</span><select id="tf-lv-type">${LV_TYPES.map(x=>`<option>${x}</option>`).join('')}</select></label><span></span>
    <label class="fld"><span>From</span><input type="date" id="tf-lv-from" value="${todayIso()}"></label><label class="fld"><span>To</span><input type="date" id="tf-lv-to"></label></div>
    <label class="fld"><span>Note (optional)</span><input type="text" id="tf-lv-note" placeholder="e.g. Doctor's appointment in the morning"></label>
    <div class="actions"><button class="btn primary" data-act="lvsend">Send request</button></div><span class="small muted">For sick leave you can add a photo of the doctor's note after sending.</span></div>`;
  const card=(r,mgr)=>{const days=workDays(r.from,r.to);
    return `<div class="card lvc"><div class="row spread"><span><b>${mgr?esc(nm('staff',r.staffId))+' · ':''}${esc(r.type)}</b><div class="small muted">${esc(fmt(r.from))}${r.to&&r.to!==r.from?' – '+esc(fmt(r.to)):''} · ${days} work day${days===1?'':'s'}${r.note?' · '+esc(r.note):''}</div></span><span class="pill ${r.status==='approved'?'done':r.status==='declined'?'missed':'due'}">${r.status==='pending'?'Waiting':r.status==='approved'?'Approved':'Declined'}</span></div>
      ${thumbs(r.photos)}${r.mgrNote?`<div class="small">Manager: ${esc(r.mgrNote)}</div>`:''}${r.coverId?`<div class="small">Cover: ${esc(nm('staff',r.coverId))}</div>`:''}
      ${mgr&&r.status==='pending'?`<div class="grid2"><label class="fld"><span>Cover person (optional)</span><select id="tf-lv-cov-${r.id}">${opt('staff','','No cover')}</select></label><label class="fld"><span>Note to staff (optional)</span><input type="text" id="tf-lv-mn-${r.id}"></label></div><div class="actions"><button class="btn primary" data-act="lvok" data-id="${r.id}">Approve</button><button class="btn danger" data-act="lvno" data-id="${r.id}">Decline</button></div>`:''}
      ${!mgr&&(r.status==='pending'||/Sick/.test(r.type))?`<div class="actions">${photoOk?`<button class="btn sm" data-act="photopick" data-kind="leavereq" data-k="${r.id}">${/Sick/.test(r.type)?'+ Sick note photo':'+ Photo'}</button>`:''}${r.status==='pending'?`<button class="btn sm" data-act="del" data-c="leavereq" data-id="${r.id}">${ui.confirmDel==='leavereq'+r.id?'Tap again to cancel':'Cancel request'}</button>`:''}</div>`:''}</div>`};
  if(ui.isMgr){const all=S.leavereq.filter(r=>!ui.f.branch||(byId('staff',r.staffId)||{}).branchId===ui.f.branch).sort((a,b)=>(b.at||'').localeCompare(a.at||''));const pend=all.filter(r=>r.status==='pending');
    h+=`<h2>Waiting for you <span class="count">${pend.length}</span></h2>`+(pend.length?pend.map(r=>card(r,true)).join(''):'<div class="card empty">No leave requests waiting.</div>');
    h+=`<h2>Decided</h2>`+(all.filter(r=>r.status!=='pending').slice(0,20).map(r=>card(r,true)).join('')||'<div class="muted small">None yet.</div>')}
  else h+=`<h2>My requests</h2>`+(mine.length?mine.map(r=>card(r,false)).join(''):'<div class="card empty">No leave requests yet.</div>');
  return h}

/* 30 incident reports */
const INJ=['No injury','Minor (plaster, ice)','Needs medical care'];
function incForm(cid){return `<div class="card"><h3>Report an incident or injury</h3><div class="grid2">
  <label class="fld"><span>Child</span><select id="tf-in-child">${opt('children',cid||'','Choose child')}</select></label>
  <label class="fld"><span>Date</span><input type="date" id="tf-in-date" value="${todayIso()}"></label>
  <label class="fld"><span>Time</span><select id="tf-in-time">${timeOpts('','—')}</select></label>
  <label class="fld"><span>Where</span><input type="text" id="tf-in-where" placeholder="e.g. Playground"></label></div>
  <label class="fld"><span>What happened</span><textarea id="tf-in-what" rows="3" placeholder="Describe what happened, who was involved"></textarea></label>
  <div class="grid2"><label class="fld"><span>Injury</span><select id="tf-in-inj">${INJ.map(x=>`<option>${x}</option>`).join('')}</select></label>
  <label class="fld"><span>First aid given (optional)</span><input type="text" id="tf-in-aid" placeholder="e.g. Cleaned and plaster"></label>
  <label class="fld"><span>Parent informed</span><select id="tf-in-par"><option value="">Not yet</option><option>Phone call</option><option>WhatsApp</option><option>In person</option></select></label>
  <label class="fld"><span>Witness (optional)</span><select id="tf-in-wit">${opt('staff','','None')}</select></label></div>
  <div class="actions"><button class="btn primary" data-act="insave">Save report</button></div></div>`}
function incCard(x){const mgr=ui.isMgr,c=byId('children',x.childId)||{};
  return `<div class="card"><div class="row spread"><span><b>${esc(c.name||'Child')}</b> · ${esc(fmt(x.date))}${x.time?' '+esc(x.time):''}${x.where?' · '+esc(x.where):''}<div class="small muted">Reported by ${esc(x.by==='manager'?'Manager':nm('staff',x.by))}${x.witness?' · witness '+esc(nm('staff',x.witness)):''}</div></span><span class="pill ${x.status==='closed'?'done':'due'}">${x.status==='closed'?'Reviewed':'Open'}</span></div>
    <div class="fbtext">${esc(x.what)}</div>
    <div class="row" style="gap:6px;flex-wrap:wrap"><span class="pill ${x.injury===INJ[2]?'missed':x.injury===INJ[1]?'due':''}">${esc(x.injury||INJ[0])}</span>${x.aid?`<span class="pill">First aid: ${esc(x.aid)}</span>`:''}<span class="pill ${x.parent?'done':'missed'}">${x.parent?'Parent informed · '+esc(x.parent):'Parent not informed yet'}</span></div>
    ${thumbs(x.photos)}${x.mgrNote?`<div class="small"><b>Manager:</b> ${esc(x.mgrNote)}</div>`:''}${incHistHtml(x)}
    <div class="actions">${!x.parent&&(mgr||x.by===ui.me)?`<select id="tf-in-p-${x.id}" aria-label="How parent was informed"><option>Phone call</option><option>WhatsApp</option><option>In person</option></select><button class="btn sm primary" data-act="inpar" data-id="${x.id}">Parent informed</button>`:''}
      ${photoOk&&(mgr||x.by===ui.me)?`<button class="btn sm" data-act="photopick" data-kind="incidents" data-k="${x.id}">+ Photo</button>`:''}<button class="btn sm" data-act="inprint" data-id="${x.id}">PDF report</button></div>
    ${mgr&&x.status!=='closed'?`<div class="addnew"><input type="text" id="tf-in-mn-${x.id}" placeholder="Manager note (optional)" aria-label="Manager note"><button class="btn sm primary" data-act="inclose" data-id="${x.id}">Mark reviewed</button></div>`:''}</div>`}
function vInc(){const list=S.incidents.filter(x=>ui.isMgr?(!ui.f.branch||(byId('children',x.childId)||{}).branchId===ui.f.branch):x.by===ui.me).sort((a,b)=>(b.date+b.time).localeCompare(a.date+a.time));
  let h=(PILOTNOTE?incOpen('new','New incident report')+incForm('')+incClose()+incOpen('pdf','Incident report for a period (PDF)'):incForm(''))+`<div class="card"><h3>Incident report for a period (PDF)</h3><div class="grid2"><label class="fld"><span>From</span><input type="date" id="tf-inr-from" value="${iso(addDays(new Date(),-30))}"></label><label class="fld"><span>To</span><input type="date" id="tf-inr-to" value="${todayIso()}"></label><label class="fld"><span>Area</span><select id="tf-inr-br">${opt('branches','','All areas')}</select></label><label class="fld"><span>Child</span><select id="tf-inr-child">${opt('children','','All children')}</select></label></div><div class="actions"><button class="btn" data-act="inrange">Create PDF report</button></div><span class="small muted">Opens the report. Choose Save as PDF in the print window.</span></div>`+(PILOTNOTE?incClose():'');const open=list.filter(x=>x.status!=='closed');
  h+=(PILOTNOTE?incOpen('list',`${ui.isMgr?'Open reports':'My reports'} <span class="count">${ui.isMgr?open.length:list.length}</span>`):`<h2>${ui.isMgr?'Open reports':'My reports'} <span class="count">${ui.isMgr?open.length:list.length}</span></h2>`)+((ui.isMgr?open:list).map(incCard).join('')||'<div class="card empty">No incident reports.</div>');
  if(ui.isMgr){const cl=list.filter(x=>x.status==='closed');if(cl.length)h+=`<h2>Reviewed</h2>`+cl.slice(0,20).map(incCard).join('')}
  if(PILOTNOTE)h+=incClose();
  return h}

/* 38 maintenance */
const MT_PRI=['Normal','Urgent','Low'];
function vMaint(){const br=ui.isMgr?(ui.f.branch||''):myBranch();const list=S.maint.filter(x=>!br||!x.branchId||x.branchId===br).sort((a,b)=>(a.status==='fixed')-(b.status==='fixed')||(b.priority==='Urgent')-(a.priority==='Urgent')||(b.at||'').localeCompare(a.at||''));
  let h=`<div class="card"><h3>Report something to fix</h3><label class="fld"><span>What is wrong?</span><input type="text" id="tf-mt-item" placeholder="e.g. Tap in the Grade R bathroom is leaking"></label>
    <div class="grid2"><label class="fld"><span>Where</span><input type="text" id="tf-mt-where" placeholder="e.g. Bathroom 2"></label><label class="fld"><span>How urgent</span><select id="tf-mt-pri">${MT_PRI.map(x=>`<option>${x}</option>`).join('')}</select></label></div>
    <div class="actions"><button class="btn primary" data-act="mtsave">Report</button></div></div>`;
  const open=list.filter(x=>x.status!=='fixed');
  h+=`<h2>Open <span class="count">${open.length}</span></h2>`+(open.length?`<div class="list">${open.map(mtRow).join('')}</div>`:'<div class="card empty">Nothing to fix. Well done.</div>');
  const fx=list.filter(x=>x.status==='fixed').slice(0,15);if(fx.length)h+=`<h2>Fixed</h2><div class="list">${fx.map(mtRow).join('')}</div>`;
  return h}
function mtRow(x){return `<div class="li"><div class="lt"><b>${esc(x.item)}</b>${x.priority==='Urgent'?' <span class="pill missed">Urgent</span>':''}<div class="muted small">${esc([x.where,x.branchId&&nm('branches',x.branchId),'by '+(x.by==='manager'?'Manager':nm('staff',x.by)),fmtAt(x.at)].filter(Boolean).join(' · '))}${x.status==='fixed'&&x.fixedAt?' · fixed '+esc(fmtAt(x.fixedAt)):''}</div>${thumbs(x.photos)}</div>
  <div class="acts"><span class="pill ${x.status==='fixed'?'done':x.status==='busy'?'upcoming':'due'}">${x.status==='fixed'?'Fixed':x.status==='busy'?'Busy with it':'Reported'}</span>${photoOk?`<button class="btn sm" data-act="photopick" data-kind="maint" data-k="${x.id}" aria-label="Add photo">+ Photo</button>`:''}${ui.isMgr&&x.status!=='fixed'?`${x.status!=='busy'?`<button class="btn sm" data-act="mtset" data-id="${x.id}" data-s="busy">Busy</button>`:''}<button class="btn sm primary" data-act="mtset" data-id="${x.id}" data-s="fixed">Fixed</button>`:''}</div></div>`}

/* Today bars for round 3 */
function pilotBars3(){let h='';const t=todayIso();
  if(PILOT&&'Notification' in window&&Notification.permission==='default'&&!lsGet('ntfask'))h+=`<div class="hal hal-info hal-row"><span><b>Get phone notifications</b><span> · new messages, approvals and reminders pop up on this phone</span></span><span class="acts"><button class="btn sm primary" data-act="ntfon">Turn on</button><button class="btn sm" data-act="ntfno">Not now</button></span></div>`;
  if(!navigator.onLine)h+=`<div class="hal hal-bad"><span class="hal-t"><b>You're offline</b><span>Ticks and comments are saved on this phone and sent when you're back online.</span></span></div>`;
  if(ui.isMgr){
    const pap=S.papprove.filter(r=>r.status==='submitted').length;if(pap)h+=`<button class="hal hal-info" data-act="ibgo" data-v="appr"><b>${pap} weekly plan${pap>1?'s':''} waiting for approval</b><span> · tap to review</span></button>`;
    const lv=S.leavereq.filter(r=>r.status==='pending').length;if(lv)h+=fullTab('leave',`${lv} leave request${lv>1?'s':''} waiting`,'tap to approve');
    const inc=S.incidents.filter(x=>x.status!=='closed');if(inc.length)h+=`<button class="hal hal-bad" data-act="tab" data-t="inc"><span class="hal-t"><b>${inc.length} incident report${inc.length>1?'s':''} to review</b><span>${esc(nm('children',inc[0].childId))}${inc.some(x=>!x.parent)?' · parent not informed yet':''}</span></span></button>`;
    const mt=S.maint.filter(x=>x.status!=='fixed'&&(!ui.f.branch||!x.branchId||x.branchId===ui.f.branch)),ur=mt.filter(x=>x.priority==='Urgent').length;if(mt.length)h+=`<button class="hal hal-info" data-act="rqgo" data-v="fix"><b>${mt.length} repair${mt.length>1?'s':''} open</b><span> · ${ur?ur+' urgent':'tap to see'}</span></button>`;
  }else if(ui.me){
    const ws=iso(addDays(mondayOf(new Date()),7)),dw=new Date().getDay(),nx=byId('papprove',papId(ui.me,ws));
    if((dw>=4||dw===0||dw===6)&&!nx)h+=`<button class="hal hal-info" data-act="plnext"><b>Submit next week's planning</b><span> · your manager needs to approve it before Monday</span></button>`;
    const ch=S.papprove.find(r=>r.staffId===ui.me&&r.status==='changes');if(ch)h+=`<button class="hal hal-bad" data-act="plweek" data-ws="${ch.ws}"><span class="hal-t"><b>Changes asked to week ${isoWeek(parse(ch.ws))} planning</b><span>${esc(ch.note||'')}</span></span></button>`;
    const lseen=seenAt('leave'),ld=S.leavereq.filter(r=>r.staffId===ui.me&&r.decidedAt&&r.decidedAt>lseen);if(ld.length)h+=fullTab('leave',`Leave ${ld[0].status==='approved'?'approved':'declined'}`,esc(fmt(ld[0].from)));
    const np=S.incidents.filter(x=>x.by===ui.me&&!x.parent);if(np.length)h+=`<button class="hal hal-bad" data-act="tab" data-t="inc"><span class="hal-t"><b>Tell the parent about the incident</b><span>${esc(nm('children',np[0].childId))} · ${esc(fmt(np[0].date))}</span></span></button>`;
  }
  const ab=absAlerts();if(ab.length)h+=`<button class="hal hal-bd" data-act="goto" data-k="child" data-v="${ab[0].cid}"><b>${ab[0].mood?'Mood':'Absence'} pattern</b><span> · ${esc(ab[0].txt)}${ab.length>1?` · +${ab.length-1} more`:''}</span></button>`;
  return h}

/* 48 notifications while the app is running */
function ntfItems(){const out=[],me=ui.me;
  if(ui.isMgr){S.feedback.forEach(f=>{if(f.to==='manager'&&f.from&&!f.deleted)out.push([f.at,nm('staff',f.from)+': '+(f.kind==='unlock'?'unlock request':f.text)])});
    S.replies.forEach(r=>{if(r.by!=='manager')out.push([r.at,nm('staff',r.by)+' replied: '+r.text])});
    S.leavereq.forEach(r=>out.push([r.at,nm('staff',r.staffId)+' asked for '+r.type.toLowerCase()]));
    S.incidents.forEach(x=>out.push([x.at,'Incident report: '+nm('children',x.childId)]));
    S.maint.forEach(x=>{if(x.priority==='Urgent')out.push([x.at,'Urgent: '+x.item])});
    S.papprove.forEach(r=>{if(r.status==='submitted')out.push([r.at,nm('staff',r.staffId)+' submitted week '+isoWeek(parse(r.ws))+' planning'])});
    S.requests.forEach(r=>out.push([r.at,nm('staff',r.by)+' needs: '+r.item]))}
  else if(me){S.feedback.forEach(f=>{if((f.to===me||f.to==='*')&&(!f.from||f.from==='manager')&&!f.deleted)out.push([f.at,'Manager: '+f.text])});
    const mine=new Set(S.feedback.filter(f=>f.from===me).map(f=>f.id));S.replies.forEach(r=>{if(mine.has(r.fid)&&r.by==='manager')out.push([r.at,'Manager replied: '+r.text])});
    S.leavereq.forEach(r=>{if(r.staffId===me&&r.decidedAt)out.push([r.decidedAt,'Leave '+r.status])});
    S.papprove.forEach(r=>{if(r.staffId===me&&r.decidedAt)out.push([r.decidedAt,'Week '+isoWeek(parse(r.ws))+' planning '+(r.status==='approved'?'approved':'needs changes')])});
    S.announce.forEach(a=>out.push([a.at,'Announcement: '+a.title]))}
  return out.filter(x=>x[0])}
function ntfCheck(){if(!PILOT||!loaded||!signedIn()||!('Notification' in window)||Notification.permission!=='granted')return;
  const k='ntflast_'+meKey(),last=lsGet(k);const items=ntfItems().sort((a,b)=>b[0].localeCompare(a[0]));const top=items[0]?items[0][0]:new Date().toISOString();
  if(!last){lsSet(k,top);return}const nw=items.filter(x=>x[0]>last);if(!nw.length)return;lsSet(k,nw[0][0]);
  if(!document.hidden)return;
  const body=nw[0][1]+(nw.length>1?` (+${nw.length-1} more)`:'');
  const show=r=>r.showNotification('Aldeia Staff Desk',{body,tag:'staffdesk',icon:PILOTNOTE?'../icon-192.png':'icon-192.png',badge:PILOTNOTE?'../icon-192.png':'icon-192.png'});
  if(navigator.serviceWorker&&navigator.serviceWorker.controller)navigator.serviceWorker.ready.then(show).catch(()=>{try{new Notification('Aldeia Staff Desk',{body})}catch(e){}});else try{new Notification('Aldeia Staff Desk',{body})}catch(e){}}
if(PILOT){setInterval(ntfCheck,15000);window.addEventListener('online',()=>{render();toast('Back online · saving your changes')});window.addEventListener('offline',()=>render())}

/* chat delete helpers */
const ibHidden=sid=>byId('ibhide',sid)||{};
function ibVisible(sid,e){const h=ibHidden(sid);if(h.clearedAt&&(!e.at||e.at<=h.clearedAt))return false;return !(h.hidden||[]).includes(ibKey(e))}
const ibKey=e=>e.t==='f'?'f:'+e.f.id:e.t==='r'?'r:'+e.r.id:e.t==='d'?'d:'+e.f.id:'p:'+e.at;

/* ---------- pilot round 4 ---------- */
function rIcons(r){const np=(r.photos||[]).length;return (r.comment?'<span class="ricon" title="Has a comment" aria-label="Has a comment"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 5h16v11H8l-4 4z"/></svg></span>':'')+(np?`<span class="ricon" title="${np} photo${np>1?'s':''}" aria-label="${np} photo${np>1?'s':''}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="6" width="18" height="14" rx="2"/><circle cx="12" cy="13" r="3.5"/></svg>${np>1?np:''}</span>`:'')}
const whoName=by=>by==='manager'||!by?'Manager':nm('staff',by);
/* 4 birthday reminders at 06:55 */
function bdKids(){if(ui.isMgr)return kidsScope();const br=myBranch(),mine=new Set([...S.plans.filter(p=>p.staffId===ui.me).flatMap(p=>kidsOf(p)),...S.resp.filter(r=>staffFor(r).includes(ui.me)).map(r=>r.childId).filter(Boolean)]);
  return sortByName('children').filter(c=>!br||!c.branchId||c.branchId===br||mine.has(c.id))}
function bdBar(d){if(PILOTNOTE)return bdBarP(d);const l=bdRows(d);return l.length?`<div class="halerts">${l.map(x=>`<div class="hal hal-bday"><span class="tico bd" aria-hidden="true">★</span><span class="hal-t"><b>${esc(x.t)}</b><span>Reminder at 06:55 · plan something small for the class</span></span></div>`).join('')}</div>`:''}
function bdRows(d){const nx=iso(addDays(parse(d),1)),out=[];
  bdKids().forEach(c=>{if(!c.dob)return;const md=c.dob.slice(5),y=Number(c.dob.slice(0,4)),age=dt=>y>1900?Number(dt.slice(0,4))-y:null;
    if(md===d.slice(5)){const a=age(d);out.push({id:c.id+d,boy:c.sex==='boy',t:`Birthday today: ${c.name}${a?' turns '+a:''}`})}
    else if(md===nx.slice(5)){const a=age(nx);out.push({id:c.id+nx,boy:c.sex==='boy',t:`Birthday tomorrow: ${c.name}${a?' turns '+a:''}`})}});
  return out}
/* 12 birthday parent and child links */
function bdLink(x){const c=byId('children',x.cid);if(!c)return '';
  if(x.kind==='Child'){const ps=[['p1','p1dob'],['p2','p2dob']].filter(([n])=>c[n]).map(([n,d])=>esc(c[n])+(c[d]?' · '+esc(fmt(nextBday(c[d]).date)):' · no birthday saved'));return ps.length?`<div class="small">Parents: ${ps.join(' &nbsp;|&nbsp; ')}</div>`:''}
  if(x.kind==='Parent'){const nb=c.dob&&nextBday(c.dob);return `<div class="small">Child: <b>${esc(c.name)}</b>${nb?' · birthday '+esc(fmt(nb.date)):''}</div>`}return ''}

/* 3 notices: tap to mark read */
const ntcRead=()=>{try{return JSON.parse(lsGet('ntcread_'+meKey())||'[]')}catch(e){return []}};
function noticeItems(){const d=document.createElement('div');d.innerHTML=noticesHtml();const rd=ntcRead();
  return [...d.children].map(el=>{const k='n'+hashI(el.textContent.replace(/\s+/g,' ').trim()).toString(36);return {el,k,read:rd.includes(k)}})}
function noticeCount(){try{return noticeItems().filter(x=>!x.read).length}catch(e){return 0}}
function homeNoticeLine(){let all=0,n=0;try{const it=noticeItems();all=it.length;n=it.filter(x=>!x.read).length}catch(e){}
  return `<div class="halerts">${ISTEST?'<div class="pilotbar"><b>Test pilot</b> · test data only. Your real Staff Desk is not affected.</div>':''}${n?`<button class="hal hal-notice" data-act="tab" data-t="notices"><span class="nbell">${BELL}</span><span class="hal-t"><b>${n?n+' new notice'+(n>1?'s':''):all+' notice'+(all>1?'s':'')+' · all read'}</b><span>Tests, birthdays, approvals and more · tap to see</span></span>${n?`<span class="ncount">${n}</span>`:''}</button>`:''}</div>`}
function vNotices(){if(PILOTNOTE)return vNoticesP();let items=[];try{items=noticeItems()}catch(e){}const n=items.filter(x=>!x.read).length;
  let h=`<div class="row spread"><h2 style="margin:0">Notices${n?` <span class="count">${n} new</span>`:''}</h2><span class="actions">${n?'<button class="btn sm" data-act="ntcall">Mark all as read</button>':''}<button class="btn sm" data-act="tab" data-t="home">Back to Today</button></span></div><div class="small muted">Tap a notice to mark it as read. Use Open to go to it.</div>`;
  if(!items.length)return h+'<div class="card empty">No notices right now. All caught up.</div>';
  return h+`<div class="halerts">${items.map(({el,k,read})=>{let open='';
    if(el.tagName==='BUTTON'&&el.dataset.act){const ds=Object.entries(el.dataset).map(([a,v])=>`data-${a.replace(/[A-Z]/g,m=>'-'+m.toLowerCase())}="${esc(v)}"`).join(' ');open=`<button class="btn sm ntcopen" ${ds}>Open</button>`;const dv=document.createElement('div');dv.className=el.className;dv.innerHTML=el.innerHTML;el=dv}
    return `<div class="ntc${read?' read':''}" data-act="ntcread" data-nk="${k}" title="${read?'Read':'Tap to mark as read'}">${read?'':'<span class="ntcdot" aria-label="New"></span>'}<div class="ntcb">${el.outerHTML}</div>${open}</div>`}).join('')}</div>`}

/* 10 mood export */
async function moodXL(cid){if(typeof XLSX==='undefined'){toast('Excel export could not load.');return}
  const kids=cid?[byId('children',cid)].filter(Boolean):(ui.kidBr?sortByName('children').filter(c=>c.branchId===ui.kidBr):kidsScope());const ids=new Set(kids.map(c=>c.id));
  const recs=S.mood.filter(m=>ids.has(m.childId)).sort((a,b)=>a.date.localeCompare(b.date)||nm('children',a.childId).localeCompare(nm('children',b.childId)));
  if(!recs.length){toast('No moods recorded yet.');return}
  const rows=recs.map(m=>{const c=byId('children',m.childId)||{},mo=MOODS.find(k=>k[0]===m.mood)||[];return {Date:m.date,Day:DAYS_LONG[parse(m.date).getDay()],Child:c.name||'',Region:nm('branches',c.branchId),'Rating (1-5)':m.mood,Mood:(mo[2]||'').replace(/^\d · /,''),'Recorded by':whoName(m.by)}});
  const sum=kids.map(c=>{const ms=recs.filter(m=>m.childId===c.id);if(!ms.length)return null;const avg=ms.reduce((a,m)=>a+m.mood,0)/ms.length;
    return {Child:c.name,Region:nm('branches',c.branchId),'Days recorded':ms.length,'Average (out of 5)':Math.round(avg*10)/10,'Lowest':Math.min(...ms.map(m=>m.mood)),'Highest':Math.max(...ms.map(m=>m.mood)),'Days 1-2 (sad/upset)':ms.filter(m=>m.mood<=2).length}}).filter(Boolean);
  const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(sum),'Summary');XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(rows),'Daily moods');
  await save(`Aldeia-moods-${cid?(byId('children',cid)||{}).name.replace(/\s+/g,'-'):'all'}-${todayIso()}.xlsx`,new Uint8Array(XLSX.write(wb,{type:'array',bookType:'xlsx'})))}

/* 2 photos with delete */
function phGrid(x){return `<div class="thumbs">${(x.photos||[]).map((p,i)=>{const u=purl(p),k='ph'+x.c+x.rid+i;
  return `<span class="phw"><button type="button" class="thumb" data-act="photoview" data-src="${esc(u)}" aria-label="Open photo"><img src="${esc(u)}" alt="Photo from ${esc(nm('staff',x.sid))}" loading="lazy" onerror="this.parentNode.classList.add('bad');this.remove()"><span class="phbad">Photo not available</span></button>${ui.isMgr&&x.c&&!(PILOTNOTE&&ui.tab==='inbox'&&ui.ibChat&&!ui.ibSel)?`<button type="button" class="phdel${ui.confirmDel===k?' on':''}" data-act="phdel" data-c="${x.c}" data-id="${x.rid}" data-i="${i}" aria-label="Delete photo">${ui.confirmDel===k?'Delete?':'×'}</button>`:''}</span>`}).join('')}</div>`}

/* 14 + 15 incidents: history and reports */
const incHist=(x,what)=>[...(x.hist||[]),{at:new Date().toISOString(),by:ui.me||'manager',what}];
function incHistHtml(x){const h=(x.hist&&x.hist.length)?x.hist:[{at:x.at,by:x.by,what:'Report created'}];
  return `<details class="ihist"><summary>History (${h.length})</summary><div class="list">${h.map(e=>`<div class="li small"><span class="lt">${esc(e.what)}</span><span class="muted">${esc(whoName(e.by))} · ${esc(fmtAt(e.at))}</span></div>`).join('')}</div></details>`}
const incBody=x=>{const c=byId('children',x.childId)||{},h=(x.hist&&x.hist.length)?x.hist:[{at:x.at,by:x.by,what:'Report created'}];
  return `<table class="rt"><tr><th>Child</th><td>${esc(c.name||'')}${c.gradeId?' · '+esc(nm('grades',c.gradeId)):''}</td></tr><tr><th>Date and time</th><td>${esc(fmt(x.date))} ${esc(x.time||'')}</td></tr><tr><th>Where</th><td>${esc(x.where||'—')}</td></tr>
  <tr><th>What happened</th><td>${esc(x.what)}</td></tr><tr><th>Injury</th><td>${esc(x.injury||'')}</td></tr><tr><th>First aid</th><td>${esc(x.aid||'—')}</td></tr>
  <tr><th>Parent informed</th><td>${esc(x.parent||'Not yet')}${x.parentAt?' · '+esc(fmtAt(x.parentAt)):''}</td></tr><tr><th>Reported by</th><td>${esc(whoName(x.by))}${x.witness?' · witness: '+esc(nm('staff',x.witness)):''}</td></tr>
  <tr><th>Status</th><td>${x.status==='closed'?'Reviewed':'Open'}${x.mgrNote?' · '+esc(x.mgrNote):''}</td></tr></table>
  ${(x.photos||[]).length?`<div class="phs">${x.photos.map(p=>`<img src="${esc(purl(p))}" alt="Incident photo">`).join('')}</div>`:''}
  <h3>History</h3><table class="rt">${h.map(e=>`<tr><td>${esc(fmtAt(e.at))}</td><td>${esc(e.what)}</td><td>${esc(whoName(e.by))}</td></tr>`).join('')}</table>`};
const RPT_CSS='<style>.rt{width:100%;border-collapse:collapse;margin:6px 0 14px;font-size:12px}.rt th,.rt td{border:1px solid #c0c0b8;padding:5px 7px;text-align:left;vertical-align:top}.rt th{background:#e8e8e0;width:28%}.phs img{max-width:45%;margin:4px;border:1px solid #ccc}.sig{margin-top:36px;display:flex;gap:30px}.sig div{flex:1;border-top:1px solid #333;padding-top:4px;font-size:11px}.pb{page-break-after:always}</style>';
function incPrint(id){const x=byId('incidents',id);if(!x)return;const c=byId('children',x.childId)||{};
  openPrint('Incident report '+(c.name||'')+' '+x.date,RPT_CSS+`<h1>Incident report</h1><div class="m">Aldeia NeuroBehaviour Institute · ${esc(nm('branches',c.branchId)||'')} · printed ${esc(fmt(todayIso()))}</div>${incBody(x)}
  <div class="sig"><div>Staff signature</div><div>Parent signature</div><div>Manager signature</div><div>Date</div></div>`)}
function incRange(){const f=val('tf-inr-from')||iso(addDays(new Date(),-30)),t=val('tf-inr-to')||todayIso(),rb=val('tf-inr-br'),rc=val('tf-inr-child');
  const list=S.incidents.filter(x=>x.date>=f&&x.date<=t&&(!rc||x.childId===rc)&&(!rb||(byId('children',x.childId)||{}).branchId===rb)&&(ui.isMgr?(!ui.f.branch||(byId('children',x.childId)||{}).branchId===ui.f.branch):x.by===ui.me)).sort((a,b)=>(a.date+(a.time||'')).localeCompare(b.date+(b.time||'')));
  if(!list.length){toast('No incidents for that choice.');return}
  const cnt=k=>list.filter(x=>x.injury===k).length,inf=list.filter(x=>x.parent).length;
  openPrint(`Incidents ${f} to ${t}`,RPT_CSS+`<h1>Incident report · ${esc(fmt(f))} – ${esc(fmt(t))}</h1><div class="m">Aldeia NeuroBehaviour Institute${rb?' · '+esc(nm('branches',rb)):ui.f.branch?' · '+esc(nm('branches',ui.f.branch)):''}${rc?' · '+esc(nm('children',rc)):''}</div>
  <table class="rt"><tr><th>Incidents</th><td>${list.length}</td></tr><tr><th>No injury / minor / needs care</th><td>${cnt(INJ[0])} / ${cnt(INJ[1])} / ${cnt(INJ[2])}</td></tr><tr><th>Parent informed</th><td>${inf} of ${list.length}</td></tr><tr><th>Reviewed</th><td>${list.filter(x=>x.status==='closed').length} of ${list.length}</td></tr></table>
  <h2>Overview</h2><table class="rt"><tr><th style="width:auto">Date</th><th style="width:auto">Child</th><th style="width:auto">What happened</th><th style="width:auto">Injury</th><th style="width:auto">Parent</th></tr>${list.map(x=>`<tr><td>${esc(fmt(x.date))} ${esc(x.time||'')}</td><td>${esc(nm('children',x.childId))}</td><td>${esc(x.what)}</td><td>${esc(x.injury||'')}</td><td>${esc(x.parent||'Not yet')}</td></tr>`).join('')}</table>
  <div class="pb"></div>${list.map(x=>`<h2>${esc(nm('children',x.childId))} · ${esc(fmt(x.date))}</h2>${incBody(x)}`).join('<div class="pb"></div>')}`)}

/* 16 requests and repairs in one tab */
function vReqCombo(){const sec=ui.rqSec||'res',nr=S.requests.filter(r=>r.status==='requested'&&(ui.isMgr||r.by===ui.me)).length,br=ui.isMgr?(ui.f.branch||''):myBranch(),nf=S.maint.filter(x=>x.status!=='fixed'&&(!br||!x.branchId||x.branchId===br)).length;
  return `<div class="ibtabs two" role="tablist" aria-label="Requests and repairs">${[['res','Resources',nr],['fix','Repairs',nf]].map(([k,l,n])=>`<button role="tab" aria-selected="${k===sec}" class="${k===sec?'on':''}" data-act="rqsec" data-v="${k}">${l}${n?` <span class="ibn">${n}</span>`:''}</button>`).join('')}</div>`+(sec==='fix'?vMaint():vReq())}

/* ---------- pilot round 5: slim Checklist ---------- */
function bdLine(){const l=bdayList().filter(x=>x.days<=3);if(!l.length)return '';
  const w=x=>x.days===0?'today':x.days===1?'tomorrow':fmt(x.date);
  return `<div class="bdline"><span class="bstar" aria-hidden="true">★</span><span class="bdt"><b>Birthdays:</b> ${l.map(x=>esc(x.name)+(x.kind==='Parent'?` <span class="muted">(parent of ${esc((byId('children',x.cid)||{}).name||'')})</span>`:'')+' <b>'+esc(w(x))+'</b>').join(' · ')}</span><button class="linkbtn" data-act="tab" data-t="bday">See all</button></div>`}
function dayScore(d){const its=itemsFor([d]).filter(i=>i.st!=='off'),ps=plansFor([d]),tot=its.length+ps.length,dn=its.filter(i=>i.st==='done').length+ps.filter(p=>p.done).length,ms=its.filter(i=>i.st==='missed').length+(d<todayIso()?ps.filter(p=>!p.done).length:0);return {tot,dn,ms}}
const timeRange=o=>{const s=oStart(o),e=oEnd(o);return s==='99'?'Any time':s+(e?'–'+e:'')};
function crow(x){const open=ui.rowMenu===x.k,STC={done:'ok',missed:'bad',due:'due',upcoming:'',off:'muted'};
  return `<div class="crow${x.done?' cdone':''}${open?' cmopen':''}${x.qd?' cq':''}">${x.qd?'':`<input type="checkbox" ${x.tick} aria-label="Mark ${esc(x.title)} done">`}<span class="ctime">${esc(x.time)}</span><span class="ctx"><span class="ctt">${esc(x.title)}${x.icons}</span><span class="cmeta">${x.meta}<span class="cnar"> · ${esc(x.time)} · ${esc(nm('staff',x.who))} · ${esc(x.stl)}</span></span></span><span class="who ${bcls(x.who)}">${esc(nm('staff',x.who))}</span>${x.qd?x.qd:`<span class="cst ${STC[x.st]||''}">${esc(x.stl)}</span>`}<button class="cmore" data-act="rowmenu" data-k="${esc(x.k)}" aria-label="Actions for ${esc(x.title)}" aria-expanded="${open}">⋯</button>${open?`<div class="cmenu" role="menu">${x.menu.map(([a,ds,l,cls])=>`<button role="menuitem" class="${cls||''}" data-act="${a}" ${Object.entries(ds).map(([k,v])=>`data-${k}="${esc(v)}"`).join(' ')}>${esc(l)}</button>`).join('')}</div>`:''}</div>`}
function chkRowTask(i){const {r,date:d,sid,st,cover}=i,e=entryMap[ekey(r,d,sid)]||{},key=r.id+'|'+d+'|'+sid,lock=signed(sid,d)&&!ui.mgr,off=st==='off'?offReason(sid,d):'';
  if(ui.openC.has(key)||(ui.rowFull&&ui.rowFull.has('t'+key)))return `<div class="crfull">${itemHtml(i)}${ui.openC.has(key)?'':`<button class="btn sm" data-act="rowless" data-k="t${esc(key)}">Show less</button>`}</div>`;
  const a=r.childId&&byId('attendance',d+'_'+r.childId);
  const meta=[r.childId&&nm('children',r.childId),tName(r.topicId),!r.childId&&('Task'+(r.staffId==='*'?' · all staff':''))].filter(Boolean).map(esc).join(' · ')+(a&&!a.present?' · <span class="bad">absent</span>':'')+(cover?' · cover for '+esc(nm('staff',sid)):'')+(signed(sid,d)?' · signed off':'');
  const menu=[lock?null:['copen',{k:key},e.comment?'Edit comment':'Add comment'],photoOk&&!lock?['photopick',{kind:'entry',k:key},'Add photo']:null,ui.mgr?['editresp',{id:r.id},'Edit responsibility']:null,['rowmore',{k:'t'+key},'Show details'],ui.isMgr?['del',{c:'resp',id:r.id},ui.confirmDel==='resp'+r.id?'Tap again to delete':'Delete responsibility','danger']:null].filter(Boolean);
  return crow({qd:planQd()&&st!=='off'?qdBtn(!!e.done,'hdone',`data-k="${esc(key)}"`,lock,r.text):'',k:'t'+key,done:!!e.done,tick:`data-tick="${esc(key)}" ${e.done?'checked':''} ${lock||st==='off'?'disabled':''}`,time:timeRange(r),title:r.text,meta,who:cover||sid,st,stl:off||ST_LABEL[st],icons:rIcons({comment:e.comment,photos:e.photos}),menu})}
function chkRowPlan(p){const lk=p.staffId!=='*'&&plocked(p.staffId,p.date),can=(ui.mgr||p.staffId===ui.me||p.by===ui.me)&&(!lk||ui.mgr),st=p.done?'done':p.date<todayIso()?'missed':p.date===todayIso()?'due':'upcoming';
  if(ui.rowFull&&ui.rowFull.has('p'+p.id))return `<div class="crfull">${planHtml(p)}<button class="btn sm" data-act="rowless" data-k="p${p.id}">Show less</button></div>`;
  const k1=kidsOf(p),ab=k1.length===1&&byId('attendance',p.date+'_'+k1[0]);
  const meta=[k1.length>1?whoLabel(p):k1.length?nm('children',k1[0]):'',tName(p.topicId),'Plan'].filter(Boolean).map(esc).join(' · ')+(ab&&!ab.present?' · <span class="bad">absent</span>':'')+(lk?' · locked':'');
  const menu=[can?['editplan',{id:p.id},'Edit']:null,can&&photoOk?['photopick',{kind:'plan',k:p.id},'Add photo']:null,['rowmore',{k:'p'+p.id},'Show details'],can?['del',{c:'plans',id:p.id},ui.confirmDel==='plans'+p.id?'Tap again to delete':'Delete','danger']:null].filter(Boolean);
  return crow({qd:planQd()?qdBtn(!!p.done,'hpdone',`data-id="${p.id}"`,lk&&!ui.mgr,p.text):'',k:'p'+p.id,done:!!p.done,tick:`data-ptick="${p.id}" ${p.done?'checked':''} ${lk&&!ui.mgr?'disabled':''}`,time:timeRange(p),title:p.text,meta,who:p.staffId,st,stl:p.done?'Done':st==='missed'?'Missed':'Planned',icons:rIcons({comment:p.comment,photos:p.photos}),menu})}
function chkHead(){const ds=weekDates(ui.ws),t=todayIso(),nf=Object.values(ui.f).filter(Boolean).length;
  const sc=d=>{const x=dayScore(d);return x.tot?`${x.dn}/${x.tot}${x.ms?' · '+x.ms+' missed':''}`:(d===t?'today':'—')};
  return `<div class="card chead"><div class="chrow"><button class="iconx" data-act="wk" data-n="-1" aria-label="Previous week">‹</button><b class="cwk">Week ${isoWeek(ui.ws)} · ${esc(fmt(ds[0]).slice(4))} – ${esc(fmt(ds[4]).slice(4))}</b><button class="iconx" data-act="wk" data-n="1" aria-label="Next week">›</button><span class="chsp"></span>
    <button class="btn sm" data-act="tab" data-t="reg">Register</button><button class="btn sm" data-act="tab" data-t="plan">Planning</button><button class="btn sm${ui.chkFlt?' primary':''}" data-act="chkflt" aria-expanded="${!!ui.chkFlt}">Filters${nf&&ui.mgr?' ('+nf+')':''}</button>
    <span class="cmw"><button class="iconx" data-act="chkmore" aria-label="More: open all days, report and Excel" aria-expanded="${!!ui.chkMore}">⋯</button>${ui.chkMore?`<div class="cmenu" role="menu"><button role="menuitem" data-act="today">Go to today</button><button role="menuitem" data-act="dall" data-p="c" data-o="1">Open all days</button><button role="menuitem" data-act="report">Printable report</button><button role="menuitem" data-act="excel">Excel</button></div>`:''}</span></div>
    <div class="cdays"><button class="cday${ui.day==='all'?' on':''}" data-act="day" data-d="all">Week<small>${isoWeek(ui.ws)}</small></button>${ds.map(d=>`<button class="cday${ui.day===d?' on':''}${d===t?' today':''}" data-act="day" data-d="${d}">${esc(fmt(d).split(' ').slice(0,2).join(' '))}<small>${sc(d)}</small></button>`).join('')}</div></div>`+(ui.chkFlt?filtersCard():'')}
function vCheckSlim(){let h=homeNoticeLine().replace(/<div class="pilotbar">.*?<\/div>/,'')+bdLine();
  if(!S.staff.length&&loaded)return h+setupFirst();
  h+=chkHead();
  const ds=selDates(),items=itemsFor(ds);
  if(ui.ws<=mondayOf(new Date())){const prev=[];for(let i=14;i>=1;i--){const d=addDays(ui.ws,-i);if(d.getDay()>0&&d.getDay()<6)prev.push(iso(d))}
    const miss=itemsFor(prev).filter(i=>i.st==='missed'&&!signed(i.sid,i.date));
    if(miss.length){const o=ui.openDays.has('carry');h+=`<button class="cdh" data-act="dtog" data-k="carry" aria-expanded="${o}"><span class="cdt bad">Carried over · missed</span><span class="cds"><b class="bad">${miss.length}</b> from the last two weeks ${o?'▾':'▸'}</span></button>`;
      if(o)h+=`<div class="clist">${miss.slice(0,20).map(i=>chkRowTask(i).replace('<span class="ctime">','<span class="ctime">'+esc(fmt(i.date).split(' ').slice(0,2).join(' '))+'<br>')).join('')}</div>`}}
  if(!S.resp.length&&loaded&&!plansFor(ds).length)return h+`<div class="card empty"><span>No responsibilities yet.</span>${ui.mgr?'<button class="btn primary" data-act="tab" data-t="resp">Add responsibilities</button>':'<span class="small">Your manager adds them.</span>'}</div>`;
  ds.forEach(d=>{const its=items.filter(i=>i.date===d),dps=plansFor([d]),hol=S.holidays.find(x=>x.date===d),sc=dayScore(d),open=ds.length===1||ui.openDays.has('c'+d);
    h+=`<button class="cdh" data-act="dtog" data-k="c${d}" aria-expanded="${open}"><span class="cdt">${esc(DAYS_LONG[parse(d).getDay()])} ${parse(d).getDate()} ${esc(MON_LONG[parse(d).getMonth()])}${d===todayIso()?' · Today':''}</span><span class="cds">${sc.dn} of ${sc.tot} done${sc.ms?` · <b class="bad">${sc.ms} missed</b>`:''}${hol?' · holiday':''}${ds.length>1?(open?' ▾':' ▸'):''}</span><span class="cbar"><i style="width:${pct(sc.dn,sc.tot)}%"></i></span></button>`;
    if(!open)return;
    const tickable=its.filter(i=>i.st!=='done'&&i.st!=='off'&&!(signed(i.sid,d)&&!ui.mgr)).length;
    if(tickable>1)h+=`<div class="actions"><button class="btn sm" data-act="tickall" data-d="${d}">${ui.confirmDel==='tickall'+d?`Tap again to tick ${tickable}`:`✓ Tick all for ${fmt(d)}`}</button></div>`;
    if(ui.f.staff&&signed(ui.f.staff,d)){const req=S.feedback.find(f=>f.kind==='unlock'&&f.scope!=='plan'&&f.date===d&&f.from===ui.f.staff&&!f.closed);
      h+=`<div class="banner info"><div class="row spread"><span><b>Signed off by the manager</b><br><span class="small">Ticks for this day are locked.</span></span>${ui.mgr?`<button class="btn sm primary" data-act="unlockday" data-s="${ui.f.staff}" data-d="${d}">Unlock day</button>`:req?'<span class="pill due">Unlock requested</span>':`<button class="btn sm" data-act="requnlock" data-d="${d}">Request unlock</button>`}</div></div>`}
    if(hol)h+=`<div class="banner info"><b>Public holiday: ${esc(hol.name||'')}</b></div>`;
    testsOnDate(d).forEach(t=>h+=`<div class="banner"><span><b>Test${t.time?' · '+tRange(t):''}:</b> ${esc(t.title||'')}${t.childId?' · '+esc(nm('children',t.childId)):''}</span></div>`);
    h+=planLockBanner(d);
    const rows=[...its.map(i=>({s:oStart(i.r),h:chkRowTask(i)})),...dps.map(p=>({s:oStart(p),h:chkRowPlan(p)})),...bdRows(d).map(x=>({s:'06:55',h:`<div class="crow cbd"><span class="bstar sm" aria-hidden="true">★</span><span class="ctime">06:55</span><span class="ctx"><span class="ctt">${esc(x.t)}</span></span></div>`}))].sort((a,b)=>a.s.localeCompare(b.s));
    h+=rows.length?`<div class="clist">${rows.map(r=>r.h).join('')}</div>`:`<div class="muted small" style="padding:4px 2px">Nothing scheduled${Object.values(ui.f).some(Boolean)&&ui.mgr?' for these filters':''}.</div>`});
  return h}

function addRefresh(){if(!PILOTNOTE||document.getElementById('refBtn'))return;const t=document.querySelector('header.top .tools');if(!t)return;
  t.insertAdjacentHTML('beforeend','<button class="iconbtn refbtn" id="refBtn" data-act="refresh" aria-label="Refresh" title="Refresh"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M20 12a8 8 0 1 1-2.3-5.6"/><path d="M20 4v5h-5"/></svg></button>')}
try{addRefresh();document.addEventListener('DOMContentLoaded',addRefresh)}catch(e){}
/* ---------- pilot round 6 ---------- */
const tRange=t=>t.time?esc(t.time)+(t.timeEnd?'–'+esc(t.timeEnd):''):'';
function tabNav(cur){const has=k=>tabsFor().some(t=>t[0]===k),L=[['home','Today'],['plan','Plan'],['resp','Responsibilities']].filter(([k])=>k===cur||k==='home'||has(k));
  return `<div class="tabnav" role="group" aria-label="Go to">${L.map(([k,l])=>`<button class="tnb${k===cur?' on':''}" data-act="tab" data-t="${k}"${k===cur?' aria-current="page"':''}>${l}</button>`).join('')}</div>`}
function homeStrip(d){const ds=weekDates(mondayOf(parse(d))),t=todayIso();
  return `<div class="hstrip">${ds.map(x=>{const s=dayScore(x),lab=s.tot?`${s.dn}/${s.tot}${s.dn===s.tot?' ✓':''}`:'empty';
    return `<button class="hsd${x===d?' on':''}${x===t?' tdy':''}${s.tot?'':' empty'}${s.ms?' miss':''}" data-act="hdayset" data-d="${x}" aria-pressed="${x===d}"><span>${esc(dayWord(x))}</span><b>${parse(x).getDate()}</b><small>${lab}</small>${bdStars(x)}</button>`}).join('')}</div>`}
function testRow(t){const can=ui.mgr||t.by===ui.me,x=[nm('children',t.childId),nm('grades',t.gradeId),nm('curriculum',t.curId)].filter(Boolean).map(esc).join(' · ');
  return `<div class="pthin ptest${t.done?' tdone':''}"><span class="ptx"><b>Test: ${esc(t.title||'')}</b>${x?' · '+x:''}${t.time?` · ${tRange(t)}`:' · <span class="bad">no time set</span>'}</span>${can?`<button class="btn xs" data-act="edittest" data-id="${t.id}">Edit</button>`:''}${qdBtn(!!t.done,'testdone',`data-id="${t.id}"`,false,t.title)}${can?`<button class="btn xs danger" data-act="del" data-c="tests" data-id="${t.id}" aria-label="Delete test">${ui.confirmDel==='tests'+t.id?'Tap again':'Delete'}</button>`:''}</div>`}
function respMeta(r){const when=r.recur==='once'?'Once: '+fmt(r.date):((r.days||[]).length===5?'Mon–Fri':(r.days||[]).map(d=>DAYS[d]).join(', '));
  return [when,r.childId&&nm('children',r.childId),nm('grades',r.gradeId),nm('curriculum',r.curriculumId),tName(r.topicId)].filter(Boolean).map(esc).join(' · ')}
function rrow(r){const k='r'+r.id,open=ui.rowMenu===k;
  const menu=[['editresp',{id:r.id},'Edit'],['reassign',{id:r.id},'Re-assign'],['arch',{c:'resp',id:r.id},'Archive'],['del',{c:'resp',id:r.id},ui.confirmDel==='resp'+r.id?'Tap again to delete':'Delete','danger']];
  return `<div class="rrow${open?' cmopen':''}"><span class="ctime">${esc(timeLabel(r)||'Any time')}</span><span class="ctx"><span class="ctt">${esc(r.text)}</span><span class="cmeta">${respMeta(r)}<span class="cnar"> · ${esc(timeLabel(r)||'Any time')}</span></span>
    ${ui.reassign===r.id?`<span class="addnew" style="margin-top:6px"><select id="tf-ra">${opt('staff',r.staffId,'Choose staff',[['*','All staff']])}</select><button class="btn sm primary" data-act="rasave" data-id="${r.id}">Save</button><button class="btn sm" data-act="racancel">Cancel</button></span>`:''}</span>
    <span class="who ${bcls(r.staffId)}">${esc(r.staffId==='*'?'All staff':nm('staff',r.staffId)||'Unassigned')}</span><button class="cmore" data-act="rowmenu" data-k="${k}" aria-label="Actions for ${esc(r.text)}" aria-expanded="${open}">⋯</button>
    ${open?`<div class="cmenu" role="menu">${menu.map(([a,ds,l,cls])=>`<button role="menuitem" class="${cls||''}" data-act="${a}" ${Object.entries(ds).map(([k2,v])=>`data-${k2}="${esc(v)}"`).join(' ')}>${esc(l)}</button>`).join('')}</div>`:''}</div>`}
function vRespP(){const sec=ui.editing.resp?'new':(ui.respSec||'list'),bOf=id=>(byId('staff',id)||{}).branchId;
  const arch=S.resp.filter(r=>r.archived);
  const list=S.resp.filter(r=>!r.archived&&(!ui.respStaff||r.staffId===ui.respStaff)&&(!ui.respBranch||r.staffId==='*'||bOf(r.staffId)===ui.respBranch));
  const head=(k,l,sub)=>`<button class="rsh" data-act="respsec" data-v="${k}" aria-expanded="${sec===k}"><span class="pmb${sec===k?'':' c'}" aria-hidden="true">${sec===k?'−':'+'}</span><b>${l}</b><span class="rsp"></span><span class="muted small">${sub}</span></button>`;
  const filt=`<div class="rflt"><select data-uiset="respBranch">${opt('branches',ui.respBranch,'All branches')}</select><select data-uiset="respStaff"><option value="">Everyone</option><option value="*"${ui.respStaff==='*'?' selected':''}>Tasks for all staff</option>${sortByName('staff').filter(x=>!ui.respBranch||x.branchId===ui.respBranch).map(x=>`<option value="${x.id}"${x.id===ui.respStaff?' selected':''}>${esc(staffLabel(x))}</option>`).join('')}</select></div>`;
  let h=`<div class="row spread"><h2 style="margin:0">Responsibilities</h2>${qBar('resp')}</div>`;
  // list
  h+=`<div class="card rsec">${head('list','All responsibilities',`${list.length}${sec==='list'?'':' · tap to open'}`)}`;
  if(sec==='list'){h+=filt;const srt=[...list].sort((a,b)=>oStart(a).localeCompare(oStart(b))||nm('staff',a.staffId).localeCompare(nm('staff',b.staffId)));
    h+=srt.length?`<div class="rlist">${srt.map(rrow).join('')}</div>`:'<div class="muted small rpad">No responsibilities yet. Open "New responsibility" to add one.</div>';
    if(arch.length){h+=`<div class="rpad"><button class="btn sm" data-act="togarch">${ui.showArch?'Hide':'Show'} archived (${arch.length})</button></div>`;
      if(ui.showArch)h+=`<div class="rlist">${arch.map(r=>`<div class="rrow"><span class="ctime">Archived</span><span class="ctx"><span class="ctt">${esc(r.text)}</span><span class="cmeta">${esc(nm('staff',r.staffId))} · archived ${fmt(r.archivedAt)}</span></span><span class="actions"><button class="btn xs" data-act="restore" data-c="resp" data-id="${r.id}">Restore</button><button class="btn xs danger" data-act="del" data-c="resp" data-id="${r.id}">${ui.confirmDel==='resp'+r.id?'Tap again':'Delete forever'}</button></span></div>`).join('')}</div>`}}
  h+=`</div>`;
  // week table
  const ds=weekDates(ui.ws);
  h+=`<div class="card rsec">${head('week','Week view',`Week ${isoWeek(ui.ws)}`)}`;
  if(sec==='week'){const groups={};list.forEach(r=>(groups[r.staffId]=groups[r.staffId]||[]).push(r));
    const sids=Object.keys(groups).sort((a,b)=>(a==='*'?-1:b==='*'?1:nm('staff',a).localeCompare(nm('staff',b))));
    h+=filt+`<div class="rwknav"><button class="iconx" data-act="wk" data-n="-1" aria-label="Previous week">‹</button><b>Week ${isoWeek(ui.ws)} · ${esc(fmt(ds[0]).slice(4))} – ${esc(fmt(ds[4]).slice(4))}</b><button class="iconx" data-act="wk" data-n="1" aria-label="Next week">›</button><span class="muted small">Tap a block to edit · + to add</span></div>`;
    h+=`<div class="rwk"><div class="rwh">Staff</div>${ds.map(d=>`<div class="rwh">${esc(fmt(d).split(' ').slice(0,2).join(' '))}</div>`).join('')}`;
    sids.forEach(sid=>{h+=`<div class="rwn"><span class="who ${bcls(sid)}">${esc(sid==='*'?'All staff':nm('staff',sid)||'Unassigned')}</span></div>`;
      ds.forEach(d=>{const rs=groups[sid].filter(r=>applies(r,d)).sort((a,b)=>oStart(a).localeCompare(oStart(b)));
        h+=`<div class="rwc">${rs.map(r=>`<button class="rwb" data-act="editresp" data-id="${r.id}" title="${esc(r.text)}"><b>${esc(r.text)}</b>${timeLabel(r)?`<small>${esc(timeLabel(r))}</small>`:''}</button>`).join('')}<button class="rwadd" data-act="respadd" data-s="${esc(sid)}" data-n="${parse(d).getDay()}" aria-label="Add for ${esc(nm('staff',sid)||'all staff')} on ${esc(fmt(d))}">+</button></div>`})});
    h+=`</div>`;if(!sids.length)h+='<div class="muted small rpad">Nothing for these filters.</div>'}
  h+=`</div>`;
  // new
  h+=`<div class="card rsec">${head('new',ui.editing.resp?'Edit responsibility':'New responsibility',ui.editing.resp?'':'tap to add')}${sec==='new'?respForm():''}</div>`;
  return h}

/* ---------- pilot round 7 ---------- */
const canTest=t=>ui.mgr||t.by===ui.me;
function testBtns(t){return `<span class="tacts"><button class="btn xs${t.done?'':' primary'}" data-act="testdone" data-id="${t.id}">${t.done?'Undo':'✓ Done'}</button>${canTest(t)?`<button class="btn xs" data-act="edittest" data-id="${t.id}">Edit</button>`:''}</span>`}
function regPrint(){const kind=val('tf-rp-kind')||'month',br=ui.regBranch||'',kids=regKids();if(!kids.length){toast('No children to print.');return}
  const st=`<style>table{max-width:none;table-layout:auto}th,td{padding:4px 5px;font-size:10.5px}td.c{text-align:center}.P{color:#2f6a3e;font-weight:700}.A{color:#a3322a;font-weight:700}.H{color:#888}</style>`;
  const att=(d,c)=>{const r=byId('attendance',d+'_'+c.id);return r?(r.present?'P':'A'):''},hol=d=>S.holidays.some(h=>h.date===d);
  const bl=br?' · '+nm('branches',br):'';
  if(kind==='month'){const m=val('tf-rp-month')||todayIso().slice(0,7),[y,mo]=m.split('-').map(Number),ds=[];
    for(let d=new Date(y,mo-1,1);d.getMonth()===mo-1;d=addDays(d,1))if(d.getDay()>0&&d.getDay()<6)ds.push(iso(d));
    let rows=kids.map(c=>{let p=0,a=0;const cells=ds.map(d=>{if(hol(d))return '<td class="c H">H</td>';const v=att(d,c);if(v==='P')p++;if(v==='A')a++;return `<td class="c ${v}">${v}</td>`}).join('');
      return `<tr><td>${esc(c.name)}</td>${cells}<td class="n">${p}</td><td class="n">${a}</td><td class="n">${p+a?Math.round(p/(p+a)*100)+'%':'—'}</td></tr>`}).join('');
    const tp=kids.reduce((s,c)=>s+ds.filter(d=>att(d,c)==='P').length,0),ta=kids.reduce((s,c)=>s+ds.filter(d=>att(d,c)==='A').length,0);
    rows+=`<tr class="g"><td>Total</td>${ds.map(d=>`<td class="c">${hol(d)?'H':kids.filter(c=>att(d,c)==='P').length||''}</td>`).join('')}<td class="n">${tp}</td><td class="n">${ta}</td><td class="n">${tp+ta?Math.round(tp/(tp+ta)*100)+'%':'—'}</td></tr>`;
    const title=`Register · ${MON_LONG[mo-1]} ${y}${bl}`;
    openPrint(title,st+`<h1>${esc(title)}</h1><div class="m">P = present · A = absent · H = public holiday · blank = not marked · Printed ${esc(fmtAt(new Date().toISOString()))}</div><table><thead><tr><th>Child</th>${ds.map(d=>`<th class="c">${esc(DAYS[parse(d).getDay()].slice(0,2))}<br>${parse(d).getDate()}</th>`).join('')}<th class="n">P</th><th class="n">A</th><th class="n">%</th></tr></thead><tbody>${rows}</tbody></table>`,true);return}
  const y=Number(val('tf-rp-year'))||new Date().getFullYear(),all=S.attendance.filter(r=>(r.id||'').startsWith(String(y)));
  const cnt=(c,mo)=>{let p=0,a=0;all.forEach(r=>{const [d,cid]=[r.id.slice(0,10),r.id.slice(11)];if(cid===c.id&&Number(d.slice(5,7))===mo){r.present?p++:a++}});return [p,a]};
  let tp=0,ta=0,rows=kids.map(c=>{let P=0,A=0;const cells=[...Array(12)].map((_,i)=>{const [p,a]=cnt(c,i+1);P+=p;A+=a;return `<td class="c">${p+a?`<span class="P">${p}</span>/<span class="A">${a}</span>`:''}</td>`}).join('');tp+=P;ta+=A;
    return `<tr><td>${esc(c.name)}</td>${cells}<td class="n">${P}</td><td class="n">${A}</td><td class="n">${P+A?Math.round(P/(P+A)*100)+'%':'—'}</td></tr>`}).join('');
  rows+=`<tr class="g"><td>Total</td>${[...Array(12)].map(()=>'<td></td>').join('')}<td class="n">${tp}</td><td class="n">${ta}</td><td class="n">${tp+ta?Math.round(tp/(tp+ta)*100)+'%':'—'}</td></tr>`;
  const title=`Register · ${y}${bl}`;
  openPrint(title,st+`<h1>${esc(title)}</h1><div class="m">Each month shows days present / days absent · Printed ${esc(fmtAt(new Date().toISOString()))}</div><table><thead><tr><th>Child</th>${MON.map(m=>`<th class="c">${esc(m)}</th>`).join('')}<th class="n">Present</th><th class="n">Absent</th><th class="n">%</th></tr></thead><tbody>${rows}</tbody></table>`,true)}
function regPrintCard(){const k=ui.rpKind||'month',y=new Date().getFullYear();
  return `<details class="card flt" id="rpbox"${ui.rpOpen?' open':''}><summary><span><span class="pmx"></span> Print register (PDF)</span><span class="fsum">Month or year <span class="chev">▾</span></span></summary>
  <div class="grid3"><label class="fld"><span>Period</span><select id="tf-rp-kind" data-uiset="rpKind"><option value="month"${k==='month'?' selected':''}>Month</option><option value="year"${k==='year'?' selected':''}>Year</option></select></label>
  ${k==='month'?`<label class="fld"><span>Month</span><input type="month" id="tf-rp-month" value="${todayIso().slice(0,7)}"></label>`:`<label class="fld"><span>Year</span><select id="tf-rp-year">${[y,y-1,y-2].map(v=>`<option>${v}</option>`).join('')}</select></label>`}</div>
  <div class="actions"><button class="btn primary" data-act="regprint">Print PDF</button><span class="muted small">Uses the branch chosen above. Choose "Save as PDF" in the print window.</span></div></details>`}
function apprHist(){const done=S.papprove.filter(r=>r.status==='approved').sort((a,b)=>(b.decidedAt||'').localeCompare(a.decidedAt||'')).slice(0,30);
  if(!done.length)return '';
  return `<h3 class="ibh">Approved planning</h3><div class="iblist">${done.map(r=>`<div class="ibrow ibap">${av(r.staffId,nm('staff',r.staffId))}<span class="ibm"><b>${esc(nm('staff',r.staffId))} <small class="muted">· approved ${esc(ibTime(r.decidedAt))}</small></b><span class="ub">Week ${isoWeek(parse(r.ws))} · ${esc(fmt(r.ws).slice(4))} – ${esc(fmt(iso(addDays(parse(r.ws),4))).slice(4))}</span></span><span class="acts"><button class="btn sm" data-act="ibplan" data-s="${r.staffId}" data-ws="${r.ws}">Open week</button></span></div>`).join('')}</div>`}

/* ---------- pilot round 8 ---------- */
function qdBtn(done,act,ds,dis,label){return `<button class="qdone${done?' on':''}" data-act="${act}" ${ds}${dis?' disabled':''} aria-pressed="${done}" aria-label="${done?'Done. Tap to undo':'Mark '+esc(label||'')+' done'}">${done?'<span aria-hidden="true">✓</span> Done':'Done'}</button>`}
const planQd=()=>PILOTNOTE&&ui.tab==='plan';
function testCard(r,isOpen){const t=r.o,x=[t.time?tRange(t):'',nm('children',t.childId),nm('grades',t.gradeId),nm('curriculum',t.curId)].filter(Boolean).join(' · ');
  return `<div class="tlc tltest slim qrow${t.done?' tdone':''}${isOpen?' tlx':''}"><button class="tlhit" data-act="hopen" data-k="${r.key}" aria-expanded="${isOpen}"><span class="tlh"><span><span class="tlt">${esc(r.t)}</span><span class="tlsub">${x?' · '+x:''}</span></span></span></button>${qdBtn(!!t.done,'testdone',`data-id="${t.id}"`,false,r.t)}${isOpen?`<div class="tlbody"><div class="tlacts">${canTest(t)?`<button class="btn" data-act="edittest" data-id="${t.id}">Edit test</button><button class="btn danger" data-act="del" data-c="tests" data-id="${t.id}">${ui.confirmDel==='tests'+t.id?'Tap again to delete':'Delete test'}</button>`:'<span class="small muted">Only the person who added this test can change it.</span>'}</div></div>`:''}</div>`}
function planView(){return PILOTNOTE?`<div class="mmx" role="group" aria-label="Row size"><button class="${ui.planFull?'':'on'}" data-act="planfull" data-v="0" aria-pressed="${!ui.planFull}">Min</button><button class="${ui.planFull?'on':''}" data-act="planfull" data-v="1" aria-pressed="${!!ui.planFull}">Max</button></div>`:''}

/* ---------- pilot round 9: weekly plan lock ---------- */
const wkLock=(sid,d)=>{if(!PILOTNOTE||!sid||sid==='*'||!d)return null;const r=byId('papprove',papId(sid,iso(mondayOf(parse(d)))));return r&&(r.status==='submitted'||r.status==='approved')?r:null};
const wkReq=(sid,ws)=>S.feedback.find(f=>f.kind==='unlock'&&f.scope==='week'&&f.from===sid&&f.date===ws&&!f.closed);
function wkGuard(b){if(!PILOTNOTE||ui.mgr||!ui.me)return false;const a=b.dataset.act;
  if(!['psopen','pbopen','copyweek','editplan','slotadd','psave','pbsave'].includes(a)&&!(a==='del'&&b.dataset.c==='plans'))return false;
  const p=b.dataset.id&&byId('plans',b.dataset.id),d=b.dataset.d||(p&&p.date)||(a==='copyweek'?iso(ui.ws):(ui.ps&&ui.ps.date)||plDaySel());
  const r=wkLock(ui.me,d);if(!r)return false;
  toast(`Week ${isoWeek(parse(r.ws))} planning is ${r.status==='approved'?'approved':'with your manager'}. Tap "Request unlock" to change it.`);return true}

/* ---------- pilot round 10 ---------- */
function qBar(cur){const has=k=>tabsFor().some(t=>t[0]===k),L=[['reg','Register'],['plan','Plan'],['time','Timetable'],['inc','Incidents']].filter(([k])=>has(k));
  return `<div class="qbar" role="group" aria-label="Go to">${L.map(([k,l])=>`<button class="btn sm${k===cur?' primary':''}" data-act="tab" data-t="${k}"${k===cur?' aria-current="page"':''}>${l}</button>`).join('')}</div>`}
/* notices: green unread, unread again, remind me */
const ntcSnz=()=>{try{return JSON.parse(lsGet('ntcsnz_'+meKey())||'{}')}catch(e){return {}}};
const ntcSave=r=>lsSet('ntcread_'+meKey(),JSON.stringify(r.slice(-300)));
const SNZ=[[15,'in 15 min'],[30,'in 30 min'],[60,'in 1 hour'],[120,'in 2 hours'],[180,'in 3 hours']];
function ntcRows(items){const sz=ntcSnz();return items.map(({el,k,read})=>{let open='';
  if(el.tagName==='BUTTON'&&el.dataset.act){const ds=Object.entries(el.dataset).map(([a,v])=>`data-${a.replace(/[A-Z]/g,m=>'-'+m.toLowerCase())}="${esc(v)}"`).join(' ');open=`<button class="btn xs ntcopen" ${ds} data-ntcgo="1">Open</button>`;const dv=document.createElement('div');dv.className=el.className;dv.innerHTML=el.innerHTML;el=dv}
  const until=sz[k];
  return `<div class="ntc ntcp${read?' read':''}" data-act="ntcread" data-nk="${k}" title="${read?'Read':'Tap to mark as read'}">${read?'':'<span class="ntcdot" aria-label="New"></span>'}<div class="ntcb">${el.outerHTML}</div><span class="ntcctl">${open}
    ${until?`<span class="ntcz" title="Reminder set">⏰ ${esc(fmtAt(until).split(' ').pop())}</span><button class="btn xs" data-act="ntcsnzx" data-nk="${k}" aria-label="Cancel reminder">✕</button>`:`<select class="ntcsnz" data-act="noop" data-snz="${k}" aria-label="Remind me later"><option value="">Remind me</option>${SNZ.map(([m,l])=>`<option value="${m}">${l}</option>`).join('')}</select>`}
    ${read?`<button class="btn xs" data-act="ntcunread" data-nk="${k}">Unread</button>`:''}</span></div>`}).join('')}
function vNoticesP(){let items=[];try{items=noticeItems()}catch(e){}const n=items.filter(x=>!x.read).length;
  let h=`<div class="row spread"><h2 style="margin:0">Notices${n?` <span class="count">${n} new</span>`:''}</h2><span class="actions">${n?'<button class="btn sm" data-act="ntcall">Mark all as read</button>':''}<button class="btn sm" data-act="tab" data-t="home">Back to Today</button></span></div><div class="small muted">Green = new. Tap to mark as read. Use Remind me to see it again later.</div>`;
  if(!items.length)return h+'<div class="card empty">No notices right now. All caught up.</div>';
  return h+`<div class="halerts">${ntcRows(items)}</div>`}
function ntcModal(){if(document.getElementById('ntm'))return true;if(!loaded||!signedIn()||ui.viewing)return false;
  if(ui.ntcDone||lsGet('ntcpop_'+meKey())===todayIso())return false;let items=[];try{items=noticeItems()}catch(e){}if(!items.some(x=>!x.read)){ui.ntcDone=true;return false}
  if(ui.tab!=='home')return true;ui.ntcDone=true;
  const m=document.createElement('div');m.id='ntm';m.className='modal';document.body.appendChild(m);ntcModalFill();return true}
function ntcModalFill(){const m=document.getElementById('ntm');if(!m)return;let items=[];try{items=noticeItems()}catch(e){}const n=items.filter(x=>!x.read).length;
  m.innerHTML=`<div class="modalcard ntmcard" role="dialog" aria-modal="true" aria-labelledby="ntmh"><div class="row spread"><h2 id="ntmh" style="margin:0">Read your notices first</h2>${n?`<span class="count">${n} new</span>`:''}</div>
  <p class="small muted" style="margin:0">Tap each notice once you have read it. Then go to your tasks for the day.</p><div class="halerts ntmlist">${ntcRows(items)}</div>
  <div class="actions"><button class="btn primary" data-act="ntmclose" data-all="1">${n?'Mark all read and see my tasks':'See my tasks'}</button>${n?'<button class="btn" data-act="ntmclose">Later</button>':''}</div></div>`}
function ntcTick(){if(!signedIn())return;const sz=ntcSnz(),now=new Date().toISOString(),due=Object.keys(sz).filter(k=>sz[k]<=now);if(!due.length)return;
  const r=ntcRead().filter(k=>!due.includes(k));ntcSave(r);due.forEach(k=>delete sz[k]);lsSet('ntcsnz_'+meKey(),JSON.stringify(sz));
  let txt='';try{const it=noticeItems().find(x=>due.includes(x.k));if(it)txt=it.el.textContent.replace(/\s+/g,' ').trim()}catch(e){}
  toast('Reminder: '+(txt||'a notice is waiting'),6000);try{if('Notification' in window&&Notification.permission==='granted')new Notification('Aldeia reminder',{body:txt||'A notice is waiting'})}catch(e){}
  render()}
if(PILOTNOTE)setInterval(ntcTick,30000);
/* staff messages, chat style */
function stPeers(){const me=ui.me,set=new Set(['manager']);S.feedback.forEach(f=>{if(f.deleted)return;if(f.from===me&&f.to&&f.to!=='manager'&&f.to!=='*')set.add(f.to);if(f.to===me&&f.from&&f.from!=='manager')set.add(f.from)});return [...set]}
function stEvents(peer){const me=ui.me,ev=[];
  S.feedback.forEach(f=>{const inT=peer==='manager'?((f.from===me&&f.to==='manager')||((!f.from||f.from==='manager')&&(f.to===me||f.to==='*'))):((f.from===me&&f.to===peer)||(f.from===peer&&f.to===me));if(!inT)return;
    ev.push({t:'f',at:f.at||'',f,me:f.from===me});S.replies.filter(r=>r.fid===f.id).forEach(r=>ev.push({t:'r',at:r.at||'',r,f,me:r.by===me}))});
  return ev.sort((a,b)=>a.at.localeCompare(b.at))}
const stSeenK=p=>'stseen_'+p+'_'+meKey();
const stName=p=>p==='manager'?'Manager':staffLabel(byId('staff',p)||{})||'Staff';
function vFbStaffP(){const peer=ui.stChat;if(peer)return stThread(peer);
  const rows=stPeers().map(p=>{const ev=stEvents(p),last=ev[ev.length-1],seen=lsGet(stSeenK(p))||'';return {p,last,unread:ev.filter(e=>!e.me&&e.at>seen&&!(e.f&&e.f.deleted)).length}}).sort((a,b)=>(b.last?b.last.at:'').localeCompare(a.last?a.last.at:'')||(a.p==='manager'?-1:1));
  let h=`<div class="row spread"><h2 style="margin:0">Messages</h2></div><div class="iblist">${rows.map(x=>{const t=x.last?(x.last.t==='r'?x.last.r.text:x.last.f.text):'No messages yet';
    return `<button class="ibrow" data-act="stopen" data-s="${esc(x.p)}">${av(x.p==='manager'?'mgr':x.p,stName(x.p))}<span class="ibm"><b>${esc(stName(x.p))}${x.last?` <small class="muted">· ${esc(ibTime(x.last.at))}</small>`:''}</b><span class="${x.unread?'ub':''}">${x.last&&x.last.me?'You: ':''}${esc((t||'').slice(0,80))}</span></span>${x.unread?`<span class="ibn">${x.unread}</span>`:''}</button>`}).join('')}</div>`;
  h+=`<div class="card"><div class="addnew"><select id="tf-stnew" aria-label="Start a chat with"><option value="">New chat with…</option>${sortByName('staff').filter(x=>x.id!==ui.me&&!stPeers().includes(x.id)).map(x=>`<option value="${x.id}">${esc(staffLabel(x))}</option>`).join('')}</select><button class="btn sm primary" data-act="stnew">Start chat</button></div></div>`;
  return h}
function stThread(peer){const ev=stEvents(peer);if(ev.length)lsSet(stSeenK(peer),new Date().toISOString());
  let h=`<div class="ibhead"><button class="iconx" data-act="stback" aria-label="Back to chats">‹</button>${av(peer==='manager'?'mgr':peer,stName(peer))}<div style="flex:1;min-width:0"><b>${esc(stName(peer))}</b></div></div><div class="ibchat">`;
  let day='';ev.forEach(e=>{const d=(e.at||'').slice(0,10);if(d&&d!==day){day=d;h+=`<div class="dpill">${esc(relDay(d))}</div>`}
    let body='',cls=e.me?'bub me':'bub';
    if(e.t==='f'){const f=e.f,k=fbKind(f),lab=f.to==='*'?'To all staff':k==='fb'||k==='staff'||k==='note'?'':(KIND_LABEL[k]||'')+(f.date?' · '+fmt(f.date):'');
      if(f.deleted){cls+=' gone';body=`<s>${esc(f.text)}</s>`}
      else{const done=(f.doneBy||{})[ui.me],ok=(f.approvedFor||{})[ui.me];
        body=`${lab?`<div class="bl">${esc(lab)}</div>`:''}<div class="bt">${esc(f.text)}</div>${f.kind==='unlock'?fbStatus(f):''}${!e.me&&(!f.from||f.from==='manager')&&!f.kind?`<label class="bdone"><input type="checkbox" data-fbdone="${f.id}"${done?' checked':''}> Done${ok?' · <span class="ok">approved</span>':done?' · waiting for approval':''}</label>`:''}`}}
    else body=`<div class="bq">${esc((e.f.text||'').slice(0,90))}</div><div class="bt">${esc(e.r.text)}</div>`;
    h+=`<div class="${cls}">${body}<div class="bm">${esc(hhmm(e.at))}</div></div>`});
  if(!ev.length)h+='<div class="muted small" style="text-align:center;padding:20px">No messages yet. Say hello.</div>';
  h+=`</div><form class="ibcomp" data-act="stsend" data-s="${esc(peer)}"><input type="text" id="tf-stc" placeholder="Message ${esc(stName(peer).split(' ')[0])}" autocomplete="off" aria-label="Message to ${esc(stName(peer))}"><button class="btn primary" type="submit">Send</button></form>`;
  return h}

/* ---------- pilot round 11: birthdays ---------- */
const bdCol=c=>c&&c.sex==='boy'?'boy':'girl';
const bdOn=d=>bdKids().filter(c=>c.dob&&c.dob.slice(5)===d.slice(5));
function bdStars(d){if(!PILOTNOTE)return '';const ks=bdOn(d);if(!ks.length)return '';const cols=[...new Set(ks.map(bdCol))];
  return `<span class="sdstars" aria-label="Birthday: ${esc(ks.map(c=>c.name).join(', '))}" title="Birthday: ${esc(ks.map(c=>c.name).join(', '))}">${cols.map(k=>`<span class="sdstar ${k}">★</span>`).join('')}</span>`}
const waNum=n=>{let d=String(n||'').replace(/\D/g,'');if(d.startsWith('00'))d=d.slice(2);if(d.startsWith('0'))d='27'+d.slice(1);return d};
const bdMsg=c=>`Happy birthday to ${(c.name||'').split(' ')[0]} from all of us at Aldeia! 🎉 Have a wonderful day.`;
const bdMinK=(c,d)=>'bdmin_'+c.id+'_'+d+'_'+meKey();
function bdWa(c){const msg=bdMsg(c);
  const ps=[['p1','p1cell'],['p2','p2cell']].filter(([n,k])=>c[k]);
  if(!ps.length)return `<a class="btn sm wab" href="https://wa.me/?text=${encodeURIComponent(msg)}" target="_blank" rel="noopener">WhatsApp a greeting</a><div class="small muted">Add a parent cellphone in Setup → Children to send it straight to the parent.</div>`;
  return ps.map(([n,k])=>`<a class="btn sm wab" href="https://wa.me/${waNum(c[k])}?text=${encodeURIComponent(msg)}" target="_blank" rel="noopener">WhatsApp ${esc(c[n]||'parent')}</a>`).join('')}
function bdBarP(d){const nx=iso(addDays(parse(d),1)),age=(c,dt)=>{const y=Number((c.dob||'').slice(0,4));return y>1900?Number(dt.slice(0,4))-y:null};
  const td=bdOn(d),tm=bdOn(nx);if(!td.length&&!tm.length)return '';
  return `<div class="bdcards">${td.map(c=>{const a=age(c,d);if(lsGet(bdMinK(c,d)))return `<div class="bdc soon ${bdCol(c)}"><span class="bdcs sm" aria-hidden="true">★</span><div class="bdct sm">${esc(c.name)}${a?` turns ${a}`:''} today</div><button class="bdx" data-act="bdmin" data-c="${c.id}" data-d="${d}" aria-label="Show birthday card" title="Show">+</button></div>`;
    const showM=ui.bdMsg===c.id;return `<div class="bdc ${bdCol(c)}"><button class="bdx" data-act="bdmin" data-c="${c.id}" data-d="${d}" aria-label="Minimise birthday card" title="Minimise">−</button><span class="bdcs" aria-hidden="true">★</span><div class="bdct">${esc(c.name)}${a?` turns ${a}`:''} today</div><div class="bdcsub">${esc([nm('grades',c.gradeId),nm('branches',c.branchId)].filter(Boolean).join(' · '))}</div><div class="bdcwa">${bdWa(c)}<button class="btn sm" data-act="bdmsg" data-c="${c.id}" aria-expanded="${showM}">${showM?'Hide message':'Show message'}</button></div>${showM?`<div class="bdmsgbox"><span id="bdm-${c.id}">${esc(bdMsg(c))}</span><button class="bdcopy" data-act="bdcopy" data-c="${c.id}" aria-label="Copy message" title="Copy"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/></svg></button></div>`:''}</div>`}).join('')}
  ${tm.map(c=>{const a=age(c,nx);return `<div class="bdc soon ${bdCol(c)}"><span class="bdcs sm" aria-hidden="true">★</span><div class="bdct sm">Tomorrow: ${esc(c.name)}${a?` turns ${a}`:''}</div></div>`}).join('')}</div>`}
function bdPosterCard(){return `<div class="card"><h3>Birthday poster (PDF)</h3><div class="grid2"><label class="fld"><span>Month</span><input type="month" id="tf-bdp-month" value="${todayIso().slice(0,7)}"></label><label class="fld"><span>Branch</span><select id="tf-bdp-br">${opt('branches',ui.f.branch||'','All branches')}</select></label></div>
  <div class="actions"><button class="btn primary" data-act="bdposter">Print poster</button><span class="muted small">A page for the classroom wall. Choose "Save as PDF" in the print window.</span></div></div>`}
function bdPoster(){const m=val('tf-bdp-month')||todayIso().slice(0,7),[y,mo]=m.split('-').map(Number),br=val('tf-bdp-br');
  const ks=sortByName('children').filter(c=>c.dob&&Number(c.dob.slice(5,7))===mo&&(!br||c.branchId===br)).sort((a,b)=>a.dob.slice(8).localeCompare(b.dob.slice(8)));
  if(!ks.length){toast(`No children's birthdays in ${MON_LONG[mo-1]}.`);return}
  const st=`<style>.pt{text-align:center;margin:10px 0 18px}.pt .ck{font-size:46px}.pt h1{font-size:34px;color:#b0124f;margin:4px 0}.r{display:flex;align-items:center;gap:14px;border-bottom:2px dashed #ffb3d1;padding:10px 4px;font-size:20px;max-width:680px;margin:0 auto}.a{width:44px;height:44px;border-radius:22px;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:20px;flex:none}.girl{background:#ff2d87}.boy{background:#2f7fd6}.r b{flex:1}.dd{color:#b0124f;font-weight:800}</style>`;
  const rows=ks.map(c=>{const a=Number(c.dob.slice(0,4))>1900?y-Number(c.dob.slice(0,4)):null;return `<div class="r"><span class="a ${bdCol(c)}">${esc((c.name||'?')[0])}</span><b>${esc(c.name)}${a?` · turns ${a}`:''}</b><span class="dd">${Number(c.dob.slice(8))} ${MON[mo-1]}</span></div>`}).join('');
  openPrint(`${MON_LONG[mo-1]} birthdays`,st+`<div class="pt"><div class="ck">🎂</div><h1>${MON_LONG[mo-1]} birthdays</h1><div class="m">Aldeia${br?' · '+esc(nm('branches',br)):''}</div></div>${rows}`)}

/* ---------- pilot round 12 ---------- */
function incOpen(k,t){const on=ui.incSec===k;return `<div class="card incsec incsec-${k}${on?' on':''}"><button class="rsh" data-act="incsec" data-v="${k}" aria-expanded="${on}"><span class="pmb${on?'':' c'}" aria-hidden="true">${on?'−':'+'}</span><b>${t}</b></button><div class="incbody"${on?'':' hidden'}>`}
const incClose=()=>'</div></div>';
/* ---------- Students tab ---------- */
const stWho=b=>b==='manager'?'Manager':(nm('staff',b)||'');
const stAt=a=>a?fmtAt(a):'';
function stTests(c){return S.tests.filter(t=>t.date&&(t.childId?t.childId===c.id:(!!t.gradeId&&t.gradeId===c.gradeId&&(!t.branchId||t.branchId===c.branchId)))).sort((a,b)=>(a.date+(a.time||'')).localeCompare(b.date+(b.time||'')))}
function stState(t,c){const r=byId('stutests',t.id+'_'+c.id)||{},w=!!(r.written||t.done);
  return {r,w,wBy:r.written?r.wBy:t.doneBy,wAt:r.written?r.wAt:t.doneAt,hq:w&&!!r.hq,hqBy:r.hqBy,hqAt:r.hqAt}}
const stSubj=t=>t.title||tName(t.topicId)||'Test';
function stScope(){const br=ui.isMgr?(ui.stArea||''):myBranch();return {br,kids:sortByName('children').filter(c=>!br||c.branchId===br)}}
function stRow(t,c){const s=stState(t,c),k=t.id+'_'+c.id,cm=ui.stCm===k,ph=s.r.photos||[];
  return `<div class="strow"><div class="sthd"><b>${esc(stSubj(t))}</b><span class="s"> · ${esc(fmt(t.date))}${t.time?' '+esc(t.time):''}</span><span class="stic"><button class="sticon${s.r.comment?' has':''}" data-act="stcm" data-k="${k}" aria-label="${s.r.comment?'Edit comment':'Add comment'}" title="Comment"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 5h16v11H8l-4 4z"/></svg></button><button class="sticon${ph.length?' has':''}" data-act="photopick" data-kind="stu" data-k="${k}" aria-label="Add photo" title="Photo"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg></button></span></div>
  <div class="sttk"><button class="stcb${s.w?' on':''}" data-act="stuw" data-t="${t.id}" data-c="${c.id}" aria-pressed="${s.w}" aria-label="Test written">${s.w?'✓':''}</button><span>Test written</span>${s.w&&s.wBy?`<span class="stwho">· ${esc(stWho(s.wBy))} ${esc(stAt(s.wAt))}</span>`:''}</div>
  <div class="sttk"><button class="stcb wa${s.hq?' on':''}" data-act="stuhq" data-t="${t.id}" data-c="${c.id}" aria-pressed="${s.hq}" aria-label="WhatsApp to HQ"${s.w?'':' disabled'}>${s.hq?'✓':''}</button><span>WhatsApp to HQ</span>${s.hq?`<span class="stwho">· ${esc(stWho(s.hqBy))} ${esc(stAt(s.hqAt))}</span>`:''}</div>
  ${cm?`<div class="stcmf"><textarea id="tf-stcm" rows="2" placeholder="Comment about this test">${esc(s.r.comment||'')}</textarea><span class="actions"><button class="btn xs primary" data-act="stcmsave" data-k="${k}">Save</button><button class="btn xs" data-act="stcmx">Cancel</button></span></div>`:s.r.comment?`<div class="stcmt" data-act="stcm" data-k="${k}" role="button" tabindex="0">💬 ${esc(s.r.comment)}</div>`:''}
  ${ph.length?`<div class="stph">${ph.map(p=>`<button type="button" class="stthumb" data-act="photoview" data-src="${esc(purl(p))}" aria-label="Open photo"><img src="${esc(purl(p))}" alt="Photo" loading="lazy"></button>`).join('')}</div>`:''}</div>`}
function vStud(){const {br,kids}=stScope(),cid=ui.stKid&&kids.some(c=>c.id===ui.stKid)?ui.stKid:'',f=ui.stF||'',subj=ui.stSub||'';
  const subjects=[...new Set(kids.flatMap(c=>stTests(c).map(stSubj)))].sort();
  const rows=(cid?kids.filter(c=>c.id===cid):kids).map(c=>{const all=stTests(c).filter(t=>!subj||stSubj(t)===subj);
    const nw=all.filter(t=>!stState(t,c).w),hq=all.filter(t=>{const s=stState(t,c);return s.w&&!s.hq});
    return {c,all,nw,hq,shown:f==='nw'?nw:f==='hq'?hq:all}});
  const N=rows.reduce((a,x)=>a+x.all.length,0),NW=rows.reduce((a,x)=>a+x.nw.length,0),HQ=rows.reduce((a,x)=>a+x.hq.length,0);
  let h=`<div class="row spread"><h2 style="margin:0">Students</h2><span class="muted small">Tests written and sent to HQ</span></div>
  <div class="card stflt"><div class="grid2">${ui.isMgr?`<label class="fld"><span>Area</span><select data-uiset="stArea">${opt('branches',ui.stArea||'','All areas')}</select></label>`:`<label class="fld"><span>Area</span><select disabled><option>${esc(nm('branches',br)||'My area')}</option></select></label>`}
  <label class="fld"><span>Child</span><select data-uiset="stKid"><option value="">All children</option>${kids.map(c=>`<option value="${c.id}"${c.id===cid?' selected':''}>${esc(c.name)}</option>`).join('')}</select></label></div>
  <label class="fld"><span>Subject</span><select data-uiset="stSub"><option value="">All subjects</option>${subjects.map(s=>`<option${s===subj?' selected':''}>${esc(s)}</option>`).join('')}</select></label></div>
  <div class="sttot"><div class="nw"><b>${NW}</b>test${NW===1?'':'s'} outstanding</div><div class="hq"><b>${HQ}</b>still to WhatsApp to HQ</div></div>
  <div class="stchips">${[['','All',N],['nw','Not written',NW],['hq','To send to HQ',HQ]].map(([k,l,n])=>`<button class="stchip${f===k?' on':''} ${k}" data-act="stf" data-v="${k}" aria-pressed="${f===k}">${l} ${n}</button>`).join('')}</div>`;
  const list=rows.filter(x=>cid||x.shown.length||!f);
  if(!list.length)return h+'<div class="card empty">Nothing to show for these filters.</div>';
  const av=c=>`<span class="stav ${c.sex==='boy'?'boy':''}">${esc((c.name||'?')[0])}</span>`;
  const cnt=x=>x.all.length?(x.nw.length||x.hq.length?`${x.nw.length?`<span class="stp nw">${x.nw.length} not written</span>`:''}${x.hq.length?`<span class="stp hq">${x.hq.length} to HQ</span>`:''}`:'<span class="stp ok">All done</span>'):'<span class="stp ok">No tests</span>';
  if(cid){const x=list[0];return h+`<div class="card stbox"><div class="stkidh">${av(x.c)}<div><b>${esc(x.c.name)}</b><div class="s">${esc([nm('grades',x.c.gradeId),nm('branches',x.c.branchId)].filter(Boolean).join(' · '))}</div></div><span class="stcnt">${cnt(x)}</span></div>${x.shown.map(t=>stRow(t,x.c)).join('')||'<div class="muted small" style="padding:10px">No tests for these filters.</div>'}</div>`}
  return h+`<div class="card stbox">${list.map(x=>{const on=ui.stOpen===x.c.id;return `<button class="stkid" data-act="stopenk" data-c="${x.c.id}" aria-expanded="${on}"><span class="pmb${on?'':' c'}" aria-hidden="true">${on?'−':'+'}</span>${av(x.c)}<b>${esc(x.c.name)}</b><span class="stcnt">${cnt(x)}</span></button>${on?x.shown.map(t=>stRow(t,x.c)).join('')||'<div class="muted small" style="padding:8px 12px">No tests for these filters.</div>':''}`}).join('')}</div>`}
async function stSave(k,patch){const cur=byId('stutests',k)||{};const {id,...rest}=cur;const [tid,cid]=k.split('_');const d={...rest,testId:tid,childId:cid,...patch};
  const ix=S.stutests.findIndex(x=>x.id===k);if(ix>=0)S.stutests[ix]={id:k,...d};else S.stutests.push({id:k,...d});render();await put('stutests',k,d)}

/* ---------- home (design E) ---------- */
function homeDay(){if(ui.homeDay)return ui.homeDay;const t=todayIso(),wd=parse(t).getDay();return (wd===0||wd===6)?iso(mondayOf(new Date())):t}
function vHome(){
  const d=homeDay(),t=todayIso(),now=new Date(),nowM=now.getHours()*60+now.getMinutes(),me=byId('staff',ui.me),hr=now.getHours();
  const greet=(hr<12?'Good morning':hr<17?'Good afternoon':'Good evening')+(me?', '+esc(me.first||staffLabel(me)):'');
  const its=itemsFor([d]).filter(i=>i.st!=='off'),pls=plansFor([d]),tot=its.length+pls.length,dn=its.filter(i=>i.st==='done').length+pls.filter(p=>p.done).length;
  let h=`<div class="hhead"><div class="hgreet">${greet}</div><div class="hdrow"><div><div class="hdate">${DAYS_LONG[parse(d).getDay()]} ${parse(d).getDate()} ${MON_LONG[parse(d).getMonth()]}${d!==t?` <button class="hlink" data-act="htoday">Back to today</button>`:''}</div><div class="hweek">Week ${isoWeek(parse(d))}${termLabel(d)}</div></div>
    <div class="harrows"><button aria-label="Previous day" data-act="hday" data-n="-1">‹</button><button aria-label="Next day" data-act="hday" data-n="1">›</button></div></div>
    ${PILOTNOTE?homeStrip(d):''}<div class="hprog"${PILOTNOTE?' hidden':''}><div class="row spread"><b>${dn} of ${tot} done</b><b>${pct(dn,tot)}%</b></div><div class="hbar"><i style="width:${pct(dn,tot)}%"></i></div></div>${PILOTNOTE?'<div class="hquick">'+qBar('home')+'</div>':''}</div>`;
  h+=PILOT?homeNoticeLine()+bdBar(d):`<div class="halerts">${backupDue()}${fbNotice()}${homeMissed()}${homeBday()}${reminders()}</div>`;
  const rows=[];
  its.forEach(i=>{const k=i.r.id+'|'+i.date+'|'+i.sid,e=entryMap[ekey(i.r,i.date,i.sid)]||{};rows.push({type:'task',key:'t:'+k,k,s:oStart(i.r),e:oEnd(i.r),t:i.r.text,o:i.r,done:i.st==='done',miss:i.st==='missed',who:i.cover||i.sid,cover:i.cover?i.sid:'',lock:signed(i.sid,i.date)&&!ui.mgr,comment:e.comment,photos:e.photos})});
  pls.forEach(p=>{const lk=p.staffId!=='*'&&plocked(p.staffId,p.date);rows.push({type:'plan',key:'p:'+p.id,id:p.id,s:oStart(p),e:oEnd(p),t:p.text,o:p,done:!!p.done,who:p.staffId,lock:lk&&!ui.mgr,comment:p.comment,photos:p.photos,cover:coverOf(p)?p.staffId:''})});
  breaksFor().forEach(b=>rows.push({type:'brk',key:'b:'+b.id,s:b.start||'99',e:b.end||'',t:b.name||'Break'}));
  if(PILOT)bdRows(d).forEach(x=>rows.push({type:'bday',key:'bd:'+x.id,s:'06:55',e:'',t:x.t,boy:x.boy}));
  testsOnDate(d).forEach(x=>rows.push({type:'test',key:'x:'+x.id,s:x.time||'99',e:x.timeEnd||'',t:'Test: '+(x.title||''),o:x}));
  rows.sort((a,b)=>a.s.localeCompare(b.s));
  if(!rows.length)return h+`<div class="card empty">Nothing scheduled for ${d===t?'today':fmt(d)}.<button class="btn primary" data-act="tab" data-t="plan">Add planning</button></div>`;
  const toM=x=>x&&x!=='99'?Number(x.slice(0,2))*60+Number(x.slice(3,5)):null;
  let cur=null;if(d===t){const act=rows.filter(r=>(r.type==='task'||r.type==='plan')&&!r.done&&toM(r.s)!=null);
    cur=act.find(r=>toM(r.s)<=nowM&&nowM<(toM(r.e)||toM(r.s)+30))||act.find(r=>toM(r.s)>nowM)||null}
  const open=ui.homeOpen==='__none'?null:(ui.homeOpen||(PILOTNOTE?null:cur&&cur.key));ui.homeOpenEff=open;
  const card=r=>{
    if(r.type==='brk')return `<div class="tlc tlbrk">${esc(r.t)} · ${esc(r.s)}${r.e?'–'+esc(r.e):''}</div>`;
    if(r.type==='bday')return `<div class="tlc tlbday${PILOTNOTE&&r.boy?' boy':''}"><span class="tlhit"><span class="tlt">${esc(r.t)}</span><span class="tlsub">Reminder · 06:55</span></span></div>`;
    if(r.type==='test'&&PILOTNOTE)return testCard(r,open===r.key);
    if(r.type==='test')return `<div class="tlc tltest"><b>${esc(r.t)}</b><div class="tlsub">${[nm('grades',r.o.gradeId),nm('curriculum',r.o.curId)].filter(Boolean).map(esc).join(' · ')}</div></div>`;
    const isNow=cur&&cur.key===r.key,isOpen=open===r.key,o=r.o;
    const sub=[r.s!=='99'?r.s+(r.e?'–'+r.e:''):'Any time',r.type==='task'?'Task':'Plan',o.childId&&nm('children',o.childId),tName(o.topicId)||nm('curriculum',o.curriculumId),(ui.mgr||r.cover)&&nm('staff',r.who)].filter(Boolean).map(esc).join(' · ');
    const tags=kidAlerts(o.childId,o.date||d)+(r.cover?`<span class="pill due">Cover for ${esc(nm('staff',r.cover))}</span>`:'')+(r.miss?'<span class="pill missed">Missed</span>':'')+(r.lock?'<span class="pill">Locked</span>':'');
    const ck=r.type==='task'?r.k:'p:'+r.id,editing=ui.openC.has(ck);
    let act='';
    if(isOpen){
      act=`${r.comment&&!editing?`<div class="cmt">${esc(r.comment)}</div>`:''}${thumbs(r.photos)}`;
      if(editing)act+=r.type==='task'?`<textarea data-comment="${r.k}" rows="2" placeholder="Type your comment">${esc(r.comment||'')}</textarea><div class="actions"><button class="btn sm primary" data-act="csave" data-k="${r.k}">Save comment</button><button class="btn sm" data-act="cclose" data-k="${r.k}">Cancel</button></div>`
        :`<textarea id="pc-${r.id}" rows="2" placeholder="Type your comment">${esc(r.comment||'')}</textarea><div class="actions"><button class="btn sm primary" data-act="pcsave" data-id="${r.id}">Save comment</button><button class="btn sm" data-act="pcclose" data-id="${r.id}">Cancel</button></div>`;
      else if(!r.lock)act+=`<div class="tlacts">${PILOTNOTE?'':`<button class="btn ${r.done?'':'primary'} tlgo" data-act="${r.type==='task'?'hdone':'hpdone'}" ${r.type==='task'?`data-k="${r.k}"`:`data-id="${r.id}"`}>${r.done?'Undo':'Done'}</button>`}<button class="btn" data-act="${r.type==='task'?'copen':'pcopen'}" ${r.type==='task'?`data-k="${r.k}"`:`data-id="${r.id}"`}>${r.comment?'Edit comment':'Comment'}</button>${photoOk?`<button class="btn tlph" aria-label="Add photo" data-act="photopick" data-kind="${r.type==='task'?'entry':'plan'}" data-k="${r.type==='task'?r.k:r.id}"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="6" width="18" height="14" rx="2"/><circle cx="12" cy="13" r="3.5"/><path d="M8 6l2-3h4l2 3"/></svg></button>`:''}</div>`;
      else act+='<div class="small muted">This day is locked. Ask your manager to unlock it.</div>';
      if(PILOT&&ui.isMgr)act+=r.type==='task'?`<div class="tlmgr"><button class="btn sm danger" data-act="del" data-c="resp" data-id="${o.id}">${ui.confirmDel==='resp'+o.id?'Tap again to delete':'Delete this responsibility'}</button>${o.staffId==='*'?'<span class="small muted">This task is for all staff, so it is deleted for everyone. To stop it for one person only, use Re-assign or Archive under Responsibilities.</span>':''}</div>`:`<div class="tlmgr"><button class="btn sm danger" data-act="del" data-c="plans" data-id="${r.id}">${ui.confirmDel==='plans'+r.id?'Tap again to delete':'Delete this plan'}</button></div>`;
    }
    return `<div class="tlc ${r.done?'tldone':'tlopen'}${r.miss?' tlmiss':''}${isOpen?' tlx':''}${r.type==='plan'?' tlplan':''}${PILOTNOTE?' qrow':''}"><button class="tlhit" data-act="hopen" data-k="${r.key}" aria-expanded="${isOpen}"><span class="tlh"><span><span class="tlt">${esc(r.t)}${PILOT?rIcons(r):''}</span><span class="tlsub">${sub}</span></span>${isNow?'<span class="nowb">NOW</span>':''}</span></button>${PILOTNOTE?qdBtn(!!r.done,r.type==='task'?'hdone':'hpdone',r.type==='task'?`data-k="${r.k}"`:`data-id="${r.id}"`,r.lock,r.t):''}${tags||act?`<div class="tlbody">${tags?`<div class="meta">${tags}</div>`:''}${act}</div>`:''}</div>`};
  h+=`<div class="tline${PILOT&&ui.isMgr?' thin':''}">${rows.map(r=>`<div class="tltime${cur&&cur.key===r.key?' tlnow':''}">${r.s==='99'?'Any':esc(r.s)}</div>${card(r)}`).join('')}</div>`;
  h+=`<div class="hfoot"><button class="btn sm" data-act="tab" data-t="check">Full checklist and week view</button></div>`;
  return h}
const DAYS_LONG=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],MON_LONG=['January','February','March','April','May','June','July','August','September','October','November','December'];
function homeMissed(){if(!loaded)return '';const pd=prevWorkday(),its=itemsFor([pd]).filter(i=>i.st==='missed'&&!signed(i.sid,i.date)),pls=plansFor([pd]).filter(p=>!p.done&&pd<todayIso());const n=its.length+pls.length;if(!n)return '';
  const first=its[0]?its[0].r.text+(its[0].r.childId?' · '+nm('children',its[0].r.childId):''):pls[0].text+(pls[0].childId?' · '+nm('children',pls[0].childId):'');
  return `<div class="hal hal-bad"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17v.5"/></svg><div class="hal-t"><b>${n} not done on ${fmt(pd)}</b><span>${esc(first)}${n>1?` and ${n-1} more`:''}</span></div><button class="btn sm" data-act="hmissed">View</button></div>`}
function homeBday(){const l=bdayList().filter(x=>x.days<=3);if(!l.length)return '';const x=l[0];
  return `<button class="hal hal-bd" data-act="tab" data-t="bday"><b>Birthday ${x.days===0?'today':x.days===1?'tomorrow':fmt(x.date)}</b><span> · ${esc(x.name)}${x.age&&x.kind!=='Parent'?' turns '+x.age:x.kind==='Parent'?' ('+esc(x.sub.toLowerCase())+')':''}${l.length>1?` · +${l.length-1} more`:''}</span></button>`}

/* ---------- v2.1 helpers ---------- */
function kidAlerts(cid,date){if(!cid)return '';const c=byId('children',cid);if(!c)return '';let h='';
  if(c.medical)h+=`<button type="button" class="tag medtag" data-act="medview" data-id="${cid}">Medical alert</button>`;
  const a=date&&byId('attendance',date+'_'+cid);if(a&&!a.present)h+='<span class="pill missed">Absent</span>';return h}
function nextBday(dob){if(!dob)return null;const [y,m,d]=dob.split('-').map(Number);const t=parse(todayIso());let yr=t.getFullYear();
  const mk=yy=>{const last=new Date(yy,m,0).getDate();return new Date(yy,m-1,Math.min(d,last))};let nb=mk(yr);if(nb<t)nb=mk(++yr);
  return {date:iso(nb),days:daysBetween(todayIso(),iso(nb)),age:y>1900?yr-y:null}}
function bdayList(){const out=[];
  sortByName('children').forEach(c=>{if(c.dob)out.push({kind:'Child',cid:c.id,name:c.name,dob:c.dob,sub:nm('grades',c.gradeId)});
    [['p1','p1dob'],['p2','p2dob']].forEach(([n,dd])=>{if(c[dd])out.push({kind:'Parent',cid:c.id,name:c[n]||'Parent',dob:c[dd],sub:'Parent of '+c.name})})});
  sortByName('staff').forEach(x=>{if(x.dob)out.push({kind:'Staff',name:staffLabel(x),dob:x.dob,sub:nm('branches',x.branchId)})});
  return out.map(x=>({...x,...nextBday(x.dob)})).sort((a,b)=>a.days-b.days)}
function bdayBanner(){const l=bdayList().filter(x=>x.days<=3);if(!l.length)return '';
  return `<div class="banner info"><div class="row spread"><b>Birthdays coming up</b><button class="btn sm" data-act="tab" data-t="bday">See all</button></div>${l.map(x=>`<span class="small">${esc(x.name)} <span class="muted">(${x.kind.toLowerCase()}${x.kind==='Parent'?', '+esc(x.sub.toLowerCase()):''})</span> · <b>${x.days===0?'today':x.days===1?'tomorrow':fmt(x.date)}</b>${x.age&&x.kind!=='Parent'?' · turns '+x.age:''}</span>`).join('')}</div>`}
function vBday(){const f=ui.bdKind||'';const l=bdayList().filter(x=>!f||x.kind===f);
  let h=`<div class="card"><div class="grid2"><label class="fld"><span>Show</span><select data-uiset="bdKind"><option value="">Everyone</option>${['Child','Staff','Parent'].map(k=>`<option value="${k}"${k===f?' selected':''}>${k==='Child'?'Children':k==='Staff'?'Staff':'Parents'}</option>`).join('')}</select></label></div>
    <span class="muted small">Reminders show on the Checklist 3 days before. Add birthdays in Setup → Children (child and parents) and Setup → Staff.</span></div>`;
  if(PILOTNOTE)h+=bdPosterCard();
  if(!l.length)return h+`<div class="card empty">No birthdays added yet.</div>`;
  const row=x=>`<div class="li"><div class="lt"><b>${esc(x.name)}</b> <span class="pill">${x.kind}</span><div class="muted small">${esc(x.sub||'')}</div>${PILOT?bdLink(x):''}</div><div class="acts" style="text-align:right"><b>${fmt(x.date)}</b><div class="small ${x.days<=3?'bad':'muted'}">${x.days===0?'Today':x.days===1?'Tomorrow':'In '+x.days+' days'}${x.age&&x.kind!=='Parent'?' · turns '+x.age:''}</div></div></div>`;
  const soon=l.filter(x=>x.days<=30),later=l.filter(x=>x.days>30);
  h+=`<div class="subhd">Next 30 days</div>`+(soon.length?`<div class="list">${soon.map(row).join('')}</div>`:'<div class="muted small">None in the next 30 days.</div>');
  if(later.length)h+=`<div class="subhd">Later this year</div><div class="list">${later.map(row).join('')}</div>`;
  return h}
function regKids(){const br=ui.isMgr||ui.mgr?(ui.regBranch||''):(byId('staff',ui.me)||{}).branchId||'';return sortByName('children').filter(c=>!br||c.branchId===br)}
function vReg(){const d=focusDay(),kids=regKids(),rec=c=>byId('attendance',d+'_'+c.id);
  const p=kids.filter(c=>rec(c)&&rec(c).present).length,a=kids.filter(c=>rec(c)&&!rec(c).present).length;
  let h=weekNav();
  if(ui.isMgr)h+=`<div class="card"><div class="grid2"><label class="fld"><span>Branch</span><select data-uiset="regBranch">${opt('branches',ui.regBranch||'','All branches')}</select></label></div></div>`;
  if(PILOTNOTE)h+=regPrintCard();
  h+=`<div class="row spread"><div class="stats"><span class="pill upcoming">${d===todayIso()?'Today':fmt(d)}</span><span class="pill done">Present ${p}</span><span class="pill missed">Absent ${a}</span><span class="pill">Not marked ${kids.length-p-a}</span></div><button class="btn sm" data-act="attall" data-d="${d}">Mark the rest present</button></div>`;
  if(!kids.length)return h+`<div class="card empty">No children in this branch yet. Add them in Setup → Children.</div>`;
  if(PILOT){const ab=absAlerts().filter(a=>kids.some(k=>k.id===a.cid));if(ab.length)h+=`<div class="banner warnb"><b>Patterns to look at</b>${ab.map(a=>`<span class="small">${esc(a.txt)}</span>`).join('')}</div>`}
  h+=`<div class="list">${kids.map(c=>{const r=rec(c);return `<div class="li"><div class="lt"><b>${esc(c.name)}</b>${c.medical?` <button type="button" class="tag medtag" data-act="medview" data-id="${c.id}">Medical alert</button>`:''}<div class="muted small">${esc(nm('grades',c.gradeId))}${r?' · marked by '+esc(nm('staff',r.by)):''}</div></div>
    <div class="acts"><button class="btn sm ${r&&r.present?'primary':''}" data-act="att" data-d="${d}" data-c="${c.id}" data-v="1">Present</button><button class="btn sm ${r&&!r.present?'danger attabs':''}" data-act="att" data-d="${d}" data-c="${c.id}" data-v="0">Absent</button></div>${PILOT&&r&&r.present?moodBtns(d,c):''}</div>`}).join('')}</div>`;
  return h}
function backupDue(){if(!ui.isMgr||!loaded)return '';const lb=(S.settings.lastBackup||'').slice(0,10),t=todayIso();
  const due=!lb||daysBetween(lb,t)>=7||(new Date().getDay()===5&&lb<t);if(!due)return '';
  return `<div class="banner"><div class="row spread"><span><b>Weekly backup due</b><br><span class="small">${lb?'Last backup: '+fmt(lb):'No backup made yet.'} Export one now and keep it safe.</span></span><button class="btn sm primary" data-act="backup">Export backup</button></div></div>`}
function ydayModal(){if(ui.ydayDone||!loaded||!signedIn()||ui.viewing)return;ui.ydayDone=true;if(lsGet('ydayack_'+meKey())===todayIso())return;
  const pd=prevWorkday(),its=itemsFor([pd]).filter(i=>i.st==='missed'&&!signed(i.sid,i.date)),pls=plansFor([pd]).filter(p=>!p.done);if(!its.length&&!pls.length)return;
  const m=document.createElement('div');m.id='ydm';m.className='modal';
  m.innerHTML=`<div class="modalcard"><h2 style="margin:0;color:var(--bad)">Not done on ${fmt(pd)}</h2><p class="small muted" style="margin:0">${ui.mgr&&!ui.f.staff?'Across staff':'These are still open'}. Please finish them or add a comment.</p>
    <div class="list">${its.map(i=>`<div class="li"><div class="lt">${esc(i.r.text)}<div class="muted small">${[timeLabel(i.r),ui.mgr?nm('staff',i.sid):''].filter(Boolean).map(esc).join(' · ')} · task</div></div></div>`).join('')}${pls.map(p=>`<div class="li"><div class="lt">${esc(p.text)}<div class="muted small">${[timeLabel(p),ui.mgr?nm('staff',p.staffId):''].filter(Boolean).map(esc).join(' · ')} · planned activity</div></div></div>`).join('')}</div>
    <div class="actions"><button class="btn primary" data-act="ydayack" data-go="1">Show me</button><button class="btn" data-act="ydayack">OK</button></div></div>`;
  document.body.appendChild(m)}
function onlineRows(dates,staff){return staff.map(s=>{const per=dates.map(d=>{const o=byId('online',s.id+'_'+d);return o?(o.minutes||0):0});return {s,per,tot:per.reduce((a,b)=>a+b,0),first:dates.map(d=>(byId('online',s.id+'_'+d)||{}).first||''),last:dates.map(d=>(byId('online',s.id+'_'+d)||{}).last||'')}})}
const hmm=m=>m?`${Math.floor(m/60)}:${pad(m%60)}`:'–';
function onlineTable(dates,staff){const rows=onlineRows(dates,staff),T=dates.map((_,i)=>rows.reduce((a,r)=>a+r.per[i],0));
  return `<div class="row spread"><h2>Time online</h2><button class="btn sm primary" data-act="onlinexl">Export to Excel</button></div><span class="muted small">Hours:minutes with the app open on screen, counted per minute.</span>`+
    repTable(['Staff',...dates.map(d=>DAYS[parse(d).getDay()]+' '+parse(d).getDate()),'Total'],rows.map(r=>[esc(staffLabel(r.s)),...r.per.map(hmm),`<b>${hmm(r.tot)}</b>`]),['Total',...T.map(hmm),hmm(T.reduce((a,b)=>a+b,0))])}
async function onlineExcel(){if(typeof XLSX==='undefined'){toast('Excel export could not load.');return}const dates=selDates(),rows=onlineRows(dates,stats(dates).map(x=>x.s)),out=[];
  rows.forEach(r=>dates.forEach((d,i)=>{if(r.per[i])out.push({Staff:staffLabel(r.s),Branch:nm('branches',r.s.branchId),Date:d,Day:DAYS[parse(d).getDay()],'First seen':r.first[i]?fmtAt(r.first[i]).split(' ').pop():'','Last seen':r.last[i]?fmtAt(r.last[i]).split(' ').pop():'',Minutes:r.per[i],'Hours:minutes':hmm(r.per[i])})}));
  const sum=rows.map(r=>({Staff:staffLabel(r.s),...Object.fromEntries(dates.map((d,i)=>[d,r.per[i]])),'Total minutes':r.tot,'Total h:mm':hmm(r.tot)}));
  const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(sum.length?sum:[{Note:'No data'}]),'Summary');XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(out.length?out:[{Note:'No time recorded'}]),'Per day');
  await save(`Aldeia-online-time-week-${isoWeek(ui.ws)}.xlsx`,new Uint8Array(XLSX.write(wb,{type:'array',bookType:'xlsx'})))}
function printTimetable(){const ds=selDates(),who=ui.f.staff?nm('staff',ui.f.staff):'All staff';
  const ev=d=>{const e=[];itemsFor([d]).forEach(i=>e.push({s:oStart(i.r),e:oEnd(i.r),t:i.r.text,w:nm('staff',i.cover||i.sid),k:'Task',done:i.st==='done'}));plansFor([d]).forEach(p=>e.push({s:oStart(p),e:oEnd(p),t:p.text,w:nm('staff',p.staffId),k:'Plan',done:p.done}));
    breaksFor().forEach(b=>e.push({s:b.start||'99',e:b.end||'',t:b.name||'Break',w:'',k:'Break'}));testsOnDate(d).forEach(t=>e.push({s:'99',e:'',t:'Test: '+(t.title||''),w:'',k:'Test'}));return e.sort((a,b)=>a.s.localeCompare(b.s))};
  const all=ds.map(ev),hours=[];for(let hh=7;hh<17;hh++)hours.push(pad(hh));
  const cell=(list,h)=>list.filter(x=>h==='any'?x.s==='99':x.s.slice(0,2)===h).map(x=>`<div class="e e-${x.k}${x.done?' dn':''}"><b>${x.s==='99'?'':x.s+(x.e?'–'+x.e:'')}</b> ${esc(x.t)}${x.w&&!ui.f.staff?` <i>${esc(x.w)}</i>`:''}</div>`).join('');
  const rows=[['any','Any time'],...hours.map(h=>[h,h+':00'])].filter(([h])=>all.some(l=>cell(l,h))).map(([h,l])=>`<tr><th class="t">${l}</th>${all.map(x=>`<td>${cell(x,h)}</td>`).join('')}</tr>`).join('');
  const html=`<!doctype html><html><head><meta charset="utf-8"><title>Timetable week ${isoWeek(ui.ws)}</title><style>@page{size:A4 landscape;margin:10mm}body{font-family:-apple-system,"Segoe UI",Arial,sans-serif;color:#333;margin:0;padding:12px;background:#fff}
h1{font-size:16px;margin:0 0 2px}.m{font-size:11px;color:#666;margin-bottom:8px}table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:10.5px}th{background:#c0c0b8;border:1px solid #b0b0a8;padding:5px;text-align:left}
th.t{width:60px}td{border:1px solid #d5d5cd;vertical-align:top;padding:3px;background:#fafaf8}.e{border-radius:3px;padding:2px 4px;margin:0 0 2px;border-left:3px solid #3f5f5a;background:#e9efed}
.e-Plan{border-left-color:#2f7a46;background:#e6f0e6}.e-Break{border-left-color:#999;background:#eee}.e-Test{border-left-color:#8a6414;background:#f5ecd5}.dn{text-decoration:line-through;opacity:.6}i{color:#666}
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}.pb{margin-bottom:8px;padding:6px 12px;font-weight:600;background:#3f5f5a;color:#fff;border:0;border-radius:5px}@media print{.pb{display:none}}</style></head>
<body><button class="pb" onclick="window.print()">Print / Save as PDF</button><h1>Aldeia Timetable · ${esc(who)}</h1><div class="m">Week ${isoWeek(ui.ws)} · ${fmt(ds[0])} – ${fmt(ds[ds.length-1])} ${parse(ds[0]).getFullYear()} · printed ${fmtAt(new Date().toISOString())}</div>
<table><tr><th class="t">Time</th>${ds.map(d=>`<th>${fmt(d)}</th>`).join('')}</tr>${rows||'<tr><td colspan="6">Nothing scheduled.</td></tr>'}</table></body></html>`;
  const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();setTimeout(()=>{try{w.focus();w.print()}catch(e){}},500)}else save(`Aldeia-timetable-week-${isoWeek(ui.ws)}.html`,html)}

/* ---------- v2.2 helpers ---------- */
function termOf(d){return S.terms.find(t=>t.start&&t.end&&t.start<=d&&d<=t.end)}
function termLabel(d){const t=termOf(d);if(!t)return '';const w=Math.floor(daysBetween(iso(mondayOf(parse(t.start))),d)/7)+1;return ` · ${esc(t.name)} wk ${w}`}
function repUntilDefault(){const t=termOf(todayIso());return t?t.end:iso(addDays(new Date(),56))}
const LOGO=()=>(document.querySelector('.logo')||{}).src||'';
function openPrint(title,body,landscape){const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>@page{size:A4 ${landscape?'landscape':'portrait'};margin:12mm}
body{font-family:-apple-system,"Segoe UI",Arial,sans-serif;color:#333;margin:0;padding:14px;background:#fff;font-size:12px}h1{font-size:18px;margin:6px 0 2px}h2{font-size:13px;text-transform:uppercase;letter-spacing:.05em;margin:16px 0 6px}.m{font-size:11px;color:#666}
.lg{height:46px}table{width:100%;max-width:680px;border-collapse:collapse;table-layout:fixed}th{background:#c0c0b8;border:1px solid #b0b0a8;border-right-color:#b0b0a8;padding:6px 8px;text-align:left}th:last-child,td:last-child{border-right:0}
td{background:#fafaf8;border-bottom:1px solid #d5d5cd;border-right:1px solid #d5d5cd;padding:6px 8px;vertical-align:top;overflow-wrap:anywhere}tr.g td{background:#c0c0b8;border-color:#b0b0a8;font-weight:600}.n{text-align:right}
.ph{display:flex;gap:6px;flex-wrap:wrap}.ph img{width:150px;height:150px;object-fit:cover;border-radius:6px}.box{border:1px solid #d5d5cd;border-radius:8px;padding:10px;background:#fafaf8;margin:6px 0}
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}.pb{margin-bottom:8px;padding:7px 14px;font-weight:600;background:#3f5f5a;color:#fff;border:0;border-radius:5px}@media print{.pb{display:none}}</style></head>
<body><button class="pb" onclick="window.print()">Print / Save as PDF</button>${LOGO()?`<div><img class="lg" src="${LOGO()}" alt="Aldeia"></div>`:''}${body}<p class="m">Aldeia Staff Desk v${VERSION} · printed ${fmtAt(new Date().toISOString())}</p></body></html>`;
  const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();setTimeout(()=>{try{w.focus();w.print()}catch(e){}},600)}else save(title.replace(/[^A-Za-z0-9]+/g,'-')+'.html',html)}
const tbl2=(head,rows,total,num)=>`<table><tr>${head.map((h,i)=>`<th${num&&num.includes(i)?' class="n"':''}>${h}</th>`).join('')}</tr>${rows.map((r,ri)=>`<tr${total&&ri===rows.length-1?' class="g"':''}>${r.map((c,i)=>`<td${num&&num.includes(i)?' class="n"':''}>${c}</td>`).join('')}</tr>`).join('')}${total?`<tr class="g">${total.map((c,i)=>`<td${num&&num.includes(i)?' class="n"':''}>${c}</td>`).join('')}</tr>`:''}</table>`;
function absRange(){const p=ui.absPeriod||'week',ref=parse(ui.absRef||todayIso());
  if(p.startsWith('term:')){const t=byId('terms',p.slice(5))||{};return {from:t.start||'0000',to:t.end||'9999',label:`${t.name||'Term'} · ${fmt(t.start)} – ${fmt(t.end)}`}}
  if(p==='month'){const f=new Date(ref.getFullYear(),ref.getMonth(),1),l=new Date(ref.getFullYear(),ref.getMonth()+1,0);return {from:iso(f),to:iso(l),label:`${MON[ref.getMonth()]} ${ref.getFullYear()}`}}
  if(p==='year'){return {from:ref.getFullYear()+'-01-01',to:ref.getFullYear()+'-12-31',label:'Year '+ref.getFullYear()}}
  const m=mondayOf(ref);return {from:iso(m),to:iso(addDays(m,4)),label:`Week ${isoWeek(m)} · ${fmt(iso(m))} – ${fmt(iso(addDays(m,4)))}`}}
function absRows(r){const kids=sortByName('children').filter(c=>!ui.absBranch||c.branchId===ui.absBranch);
  return kids.map(c=>{const recs=S.attendance.filter(a=>a.childId===c.id&&a.date>=r.from&&a.date<=r.to);return {c,dates:recs.filter(a=>!a.present).map(a=>a.date).sort(),present:recs.filter(a=>a.present).length}}).filter(x=>x.dates.length)}
function absPrint(){const r=absRange(),rows=absRows(r),tot=rows.reduce((a,x)=>a+x.dates.length,0);
  openPrint('Absence report '+r.label,`<h1>Absence report</h1><div class="m">${esc(r.label)} · ${ui.absBranch?esc(nm('branches',ui.absBranch)):'All branches'}</div>`+
    (rows.length?tbl2(['Child','Grade','Branch','Days absent','Dates'],rows.map(x=>[esc(x.c.name),esc(nm('grades',x.c.gradeId)),esc(nm('branches',x.c.branchId)),x.dates.length,x.dates.map(d=>fmt(d)).join(', ')]),['Total',`${rows.length} children`,'',tot,''],[3]):'<p>No absences recorded in this period.</p>'))}
async function absExcel(){if(typeof XLSX==='undefined'){toast('Excel export could not load.');return}const r=absRange(),rows=absRows(r),out=[];
  rows.forEach(x=>x.dates.forEach(d=>out.push({Child:x.c.name,Grade:nm('grades',x.c.gradeId),Branch:nm('branches',x.c.branchId),Date:d,Day:DAYS[parse(d).getDay()]})));
  const sum=rows.map(x=>({Child:x.c.name,Grade:nm('grades',x.c.gradeId),Branch:nm('branches',x.c.branchId),'Days absent':x.dates.length,'Days present':x.present}));
  const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(sum.length?sum:[{Note:'No absences'}]),'Summary');XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(out.length?out:[{Note:'No absences'}]),'Absent days');
  await save(`Aldeia-absences-${r.from}-to-${r.to}.xlsx`,new Uint8Array(XLSX.write(wb,{type:'array',bookType:'xlsx'})))}
function parentSummary(asText){const c=byId('children',ui.kid);if(!c)return;const d=ui.psDate||todayIso(),a=byId('attendance',d+'_'+c.id);
  const tasks=[];S.resp.forEach(r=>{if(r.childId!==c.id||!applies(r,d))return;staffFor(r).forEach(sid=>{const e=entryMap[ekey(r,d,sid)];if(e&&(e.done||e.comment))tasks.push({t:r.text,done:!!(e&&e.done),cm:e&&e.comment,ph:(e&&e.photos)||[],tm:timeLabel(r)})})});
  const plans=S.plans.filter(p=>(PILOT?covers(p,c.id):p.childId===c.id)&&p.date===d).map(p=>({t:p.text,done:!!p.done,ph:p.photos||[],tm:timeLabel(p),sub:tName(p.topicId)}));
  const did=[...plans.filter(p=>p.done),...tasks.filter(t=>t.done)];
  if(asText){const txt=`${c.name} – ${fmt(d)}\n${a?(a.present?'Present today':'Absent today'):''}${PILOT&&moodOf(d,c.id)?'\nMood: '+MOODS.find(k=>k[0]===moodOf(d,c.id).mood)[2]:''}\n\nToday we:\n${did.length?did.map(x=>'• '+x.t+(x.sub?' ('+x.sub+')':'')).join('\n'):'• (nothing recorded yet)'}${tasks.filter(t=>t.cm).length?'\n\nNotes:\n'+tasks.filter(t=>t.cm).map(t=>'• '+t.cm).join('\n'):''}${PILOT?S.incidents.filter(x=>x.childId===c.id&&x.date===d).map(x=>'\n\nIncident today: '+x.what+(x.aid?' (first aid: '+x.aid+')':'')).join(''):''}\n\nAldeia NeuroBehaviour Institute`;
    if(asText==='wa'){window.open('https://wa.me/?text='+encodeURIComponent(txt),'_blank');return}
    navigator.clipboard?.writeText(txt).then(()=>toast('Summary copied. Paste it into WhatsApp.'),()=>toast('Could not copy. Try Print instead.'));return}
  const photos=[...plans,...tasks].flatMap(x=>x.ph).map(p=>purl(p)).filter(Boolean);
  openPrint(`${c.name} ${d}`,`<h1>${esc(c.name)} · ${fmt(d)}</h1><div class="m">${esc(nm('grades',c.gradeId))}${a?' · '+(a.present?'Present':'Absent'):''}</div>
    <h2>What we did today</h2>${did.length?did.map(x=>`<div class="box"><b>${esc(x.t)}</b>${x.sub?` <span class="m">· ${esc(x.sub)}</span>`:''}${x.tm?`<div class="m">${esc(x.tm)}</div>`:''}</div>`).join(''):'<p class="m">Nothing ticked yet for this day.</p>'}
    ${tasks.filter(t=>t.cm).length?`<h2>Notes from the teacher</h2>${tasks.filter(t=>t.cm).map(t=>`<div class="box">${esc(t.cm)}</div>`).join('')}`:''}
    ${photos.length?`<h2>Photos</h2><div class="ph">${photos.map(u=>`<img src="${esc(u)}" alt="Photo">`).join('')}</div>`:''}`)}
function monthlyReport(){const sid=ui.mrStaff,st=byId('staff',sid);if(!st){toast('Choose a staff member first.');return}const mo=ui.mrMonth||todayIso().slice(0,7),[y,m]=mo.split('-').map(Number);
  const days=[];for(let d=new Date(y,m-1,1);d.getMonth()===m-1;d=addDays(d,1))if(d.getDay()>0&&d.getDay()<6)days.push(iso(d));
  const sv=ui.f.staff;ui.f.staff=sid;const its=itemsFor(days).filter(i=>i.st!=='off'&&(i.sid===sid||i.cover===sid)),pls=plansFor(days).filter(p=>p.staffId===sid);ui.f.staff=sv;
  const done=its.filter(i=>i.st==='done'),miss=its.filter(i=>i.st==='missed'),pd=pls.filter(p=>p.done),onl=days.reduce((a,d)=>a+((byId('online',sid+'_'+d)||{}).minutes||0),0),clk=days.filter(d=>byId('clock',sid+'_'+d)).length;
  const lv=days.filter(d=>offReason(sid,d)==='On leave').length,cms=its.filter(i=>{const e=entryMap[ekey(i.r,i.date,i.sid)];return e&&e.comment});
  const ph=its.reduce((a,i)=>a+(((entryMap[ekey(i.r,i.date,i.sid)]||{}).photos||[]).length),0)+pls.reduce((a,p)=>a+(p.photos||[]).length,0);
  openPrint(`Monthly report ${staffLabel(st)} ${mo}`,`<h1>Monthly report · ${esc(staffLabel(st))}</h1><div class="m">${MON[m-1]} ${y} · ${esc(nm('branches',st.branchId))}${st.role?' · '+esc(st.role):''}</div><h2>Summary</h2>`+
    tbl2(['Measure','Count'],[['Tasks',its.length],['Tasks done',done.length],['Tasks missed',miss.length],['Planned activities',pls.length],['Plans done',pd.length],['Days on leave',lv],['Days clocked in (QR)',clk],['Time online',hmm(onl)],['Comments written',cms.length],['Photos added',ph],['Plans + tasks complete',pct(done.length+pd.length,its.length+pls.length)+'%']],null,[1])+
    (miss.length?`<h2>Missed tasks</h2>`+tbl2(['Date','Task','Time'],miss.map(i=>[fmt(i.date),esc(i.r.text),esc(timeLabel(i.r))])):'')+
    (cms.length?`<h2>Comments</h2>`+tbl2(['Date','Task','Comment'],cms.map(i=>[fmt(i.date),esc(i.r.text),esc(entryMap[ekey(i.r,i.date,i.sid)].comment)])):'')+
    `<h2>Sign-off</h2><table><tr><td style="height:40px">Staff signature</td><td>Manager signature</td><td>Date</td></tr></table>`)}
function clockTable(dates,staff){const any=staff.some(s=>dates.some(d=>byId('clock',s.id+'_'+d)));if(!any)return '';const tm=x=>x?fmtAt(x).split(' ').pop():'–';
  return `<h2>Clock-in and out (QR)</h2>`+repTable(['Staff',...dates.map(d=>DAYS[parse(d).getDay()]+' '+parse(d).getDate())],staff.map(s=>[esc(staffLabel(s)),...dates.map(d=>{const c=byId('clock',s.id+'_'+d);return c?`${tm(c.in)}–${c.out?tm(c.out):'…'}<div class="muted small">${esc(nm('branches',c.branchId))}</div>`:'–'})]),null)}
async function qrShow(bid){const b=byId('branches',bid);if(!b)return;if(typeof QRCode==='undefined'){toast('The QR maker could not load. Check your connection.');return}
  let key=b.qrKey;if(!key){key=Math.random().toString(36).slice(2,10);const {id,...rest}=b;await put('branches',id,{...rest,qrKey:key});b.qrKey=key}
  const url=location.origin+location.pathname+`?clockin=${encodeURIComponent(bid)}&k=${key}`,el=document.createElement('div');el.style.cssText='position:fixed;left:-9999px';document.body.appendChild(el);
  new QRCode(el,{text:url,width:600,height:600,correctLevel:QRCode.CorrectLevel.M});await new Promise(r=>setTimeout(r,150));const cv=el.querySelector('canvas'),src=cv?cv.toDataURL('image/png'):(el.querySelector('img')||{}).src;el.remove();
  openPrint(`QR ${b.name}`,`<div style="text-align:center"><h1 style="font-size:28px">${esc(b.name)}</h1><p style="font-size:16px">Scan with your phone camera to <b>clock in</b> when you arrive and <b>clock out</b> when you leave.</p><img src="${src}" style="width:420px;height:420px" alt="QR code"><p class="m">If the QR code is replaced, old printouts stop working.</p></div>`)}
function handleClock(){if(ui.clockDone||!loaded||!ui.me||ui.viewing)return;let v='';try{v=sessionStorage.getItem('asd_clock')||''}catch(e){}if(!v)return;ui.clockDone=true;try{sessionStorage.removeItem('asd_clock')}catch(e){}
  const [bid,k]=v.split('|'),b=byId('branches',bid);if(!b||!b.qrKey||b.qrKey!==k){toast('This QR code is not valid any more. Ask your manager for the new one.',6000);return}
  const d=todayIso(),id=ui.me+'_'+d,cur=byId('clock',id),now=new Date().toISOString(),hm_=fmtAt(now).split(' ').pop();
  if(!cur){put('clock',id,{sid:ui.me,date:d,branchId:bid,in:now});toast(`Clocked in at ${hm_} · ${b.name}`,6000)}else{put('clock',id,{...cur,out:now});toast(`Clocked out at ${hm_} · ${b.name}`,6000)}}

/* ---------- timetable ---------- */
function evObj(E){return E.k==='task'?byId('resp',E.id):E.k==='plan'?byId('plans',E.id):byId('breaks',E.id)}
function evPanel(){const E=ui.evEdit;if(!E)return '';const o=evObj(E);if(!o)return '';
  const st=oStart(o)==='99'?'':oStart(o), en=oEnd(o), weekly=E.k==='task'&&o.recur!=='once';
  return `<div class="card" id="evbox"><div class="row spread"><h3>Move or re-assign: ${esc(o.text||o.name||'')}</h3><span class="pill">${E.k==='task'?'Task':E.k==='plan'?'Plan':'Break'}</span></div>
  <div class="grid2">${E.k!=='brk'?`<label class="fld"><span>Day</span><select id="tf-eday">${weekDates(ui.ws).map(d=>`<option value="${d}"${d===E.d?' selected':''}>${fmt(d)}</option>`).join('')}</select></label>
  <label class="fld"><span>Staff</span><select id="tf-estaff"${ui.mgr?'':' disabled'}>${opt('staff',o.staffId,'—',[['*','All staff']])}</select></label>`:''}
  ${E.k!=='brk'?`<label class="fld"><span>Child</span><select id="tf-echild">${opt('children',o.childId||'','—')}</select></label><label class="fld"><span>Grade</span><select id="tf-egrade">${opt('grades',o.gradeId||'','—')}</select></label>`:''}
  <label class="fld"><span>From</span><select id="tf-estart">${timeOpts(st,'Any time')}</select></label><label class="fld"><span>To</span><select id="tf-eend">${timeOpts(en,'—')}</select></label></div>
  ${weekly?`<div class="fld"><span>Apply to</span><div class="seg"><label><input type="radio" name="tf-escope" id="tf-esc-one" checked> ${fmt(E.d)} only</label><label><input type="radio" name="tf-escope" id="tf-esc-all"> Every week</label></div></div>`:''}
  ${clashBox('ev')}<div class="actions"><button class="btn primary" data-act="evsave">${ui.clash&&ui.clash.f==='ev'?'Save anyway':'Save'}</button><button class="btn" data-act="evcancel">Cancel</button></div></div>`}
function vTime(){
  let h=weekNav()+(ui.mgr&&!PILOTNOTE?`<div class="card"><div class="grid2"><label class="fld"><span>Staff</span><select data-filter="staff"><option value="">All staff</option>${sortByName('staff').filter(x=>!ui.f.branch||x.branchId===ui.f.branch).map(x=>`<option value="${x.id}"${x.id===ui.f.staff?' selected':''}>${esc(staffLabel(x))}</option>`).join('')}</select></label>
    <label class="fld"><span>Branch</span><select data-filter="branch">${opt('branches',ui.f.branch,'All branches')}</select></label></div></div>`:'')+filtersCard()+evPanel();
  const F0=420,F1=1020,PX=12, ds=selDates();let T0=F0,T1=F1;
  if(ui.mgr&&!ui.f.staff) h+=`<div class="banner info"><span class="small">Showing everyone. Pick one staff member above for a clearer timetable. Tap a block to edit it.</span></div>`;
  const cols=ds.map(d=>{
    const ev=[];
    itemsFor([d]).forEach(i=>ev.push({id:i.r.id,ed:ui.mgr,k:'task',t:i.r.text,who:i.sid,done:i.st==='done',miss:i.st==='missed',s:toMin(oStart(i.r)),e:toMin(oEnd(i.r))}));
    plansFor([d]).forEach(p=>ev.push({id:p.id,ed:ui.mgr||p.staffId===ui.me||p.by===ui.me,k:'plan',t:p.text,who:p.staffId,done:p.done,s:toMin(oStart(p)),e:toMin(oEnd(p))}));
    breaksFor().forEach(b=>ev.push({id:b.id,ed:ui.mgr,k:'brk',t:b.name||'Break',who:'',s:toMin(b.start),e:toMin(b.end)}));
    const any=ev.filter(x=>x.s==null).concat(testsOnDate(d).map(t=>({k:'test',t:'Test: '+(t.title||'')})));
    let tim=ev.filter(x=>x.s!=null).map(x=>{let s=Math.max(F0,Math.min(F1-15,x.s)),e=x.e==null||x.e<=x.s?x.s+30:x.e;e=Math.max(s+15,Math.min(F1,e));return {...x,s,e}});
    tim.forEach(x=>x.clash=x.k!=='brk'&&tim.some(y=>y!==x&&y.s<x.e&&y.e>x.s&&(y.k==='brk'||y.who===x.who||y.who==='*'||x.who==='*')));
    tim.sort((a,b)=>a.s-b.s||b.e-a.e);
    let cl=[],cEnd=-1;const out=[];
    const flush=()=>{const lanes=[];cl.forEach(x=>{let i=lanes.findIndex(v=>v<=x.s);if(i<0){i=lanes.length;lanes.push(0)}lanes[i]=x.e;x.lane=i});cl.forEach(x=>x.n=lanes.length);out.push(...cl);cl=[]};
    tim.forEach(x=>{if(cl.length&&x.s>=cEnd){flush();cEnd=-1}cl.push(x);cEnd=Math.max(cEnd,x.e)});flush();
    return {d,any,out};
  });
  const all=cols.flatMap(c=>c.out);
  if(all.length){T0=Math.max(F0,Math.floor(Math.min(...all.map(x=>x.s))/60)*60);T1=Math.min(F1,Math.ceil(Math.max(...all.map(x=>x.e))/60)*60);if(T1-T0<360)T1=Math.min(F1,T0+360);if(T1-T0<360)T0=Math.max(F0,T1-360)}
  else{T0=480;T1=600}
  const H=(T1-T0)/15*PX, maxAny=Math.max(0,...cols.map(c=>c.any.length)), anyH=maxAny?maxAny*20+6:0;
  if(!all.length&&!maxAny) return h+`<div class="card empty">Nothing scheduled with a time${ui.day==='all'?' this week':' on '+fmt(ui.day)}.</div>`;
  const hm=m=>pad(Math.floor(m/60))+':'+pad(m%60);
  const lbl=x=>`${esc(x.t)}${ui.mgr&&x.who&&x.who!==ui.f.staff?` · ${esc(nm('staff',x.who))}`:''}`;
  let g=`<div class="ttc ttime"><div class="tth"></div><div class="ttany${anyH?'':' ttany0'}" style="height:${anyH}px">${anyH?'<span class="small muted">Any</span>':''}</div><div class="ttbody" style="height:${H}px">${Array.from({length:(T1-T0)/60+1},(_,i)=>`<span class="tthr" style="top:${i*4*PX}px">${pad(T0/60+i)}:00</span>`).join('')}</div></div>`;
  cols.forEach(c=>{
    g+=`<div class="ttc"><div class="tth${c.d===todayIso()?' ttoday':''}">${DAYS[parse(c.d).getDay()]} ${parse(c.d).getDate()}</div>
    <div class="ttany${anyH?'':' ttany0'}" style="height:${anyH}px">${c.any.map(x=>`<div class="chip ev-${x.k}${x.done?' evdone':''}${x.ed?' evx':''}"${x.ed?` data-act="evedit" data-ek="${x.k}" data-eid="${x.id}" data-ed="${c.d}" data-es="${x.who||''}" role="button" tabindex="0"`:''}>${lbl(x)}</div>`).join('')}</div>
    <div class="ttbody" style="height:${H}px;background-size:100% ${4*PX}px">${c.out.map(x=>`<div class="ev ev-${x.k}${x.done?' evdone':''}${x.miss?' evmiss':''}${x.clash?' clash':''}${x.ed?' evx':''}"${x.ed?` data-act="evedit" data-ek="${x.k}" data-eid="${x.id}" data-ed="${c.d}" data-es="${x.who||''}" role="button" tabindex="0"`:''} style="top:${(x.s-T0)/15*PX}px;height:${(x.e-x.s)/15*PX-2}px;left:calc(${x.lane/x.n*100}% + 2px);width:calc(${100/x.n}% - 4px)" title="${esc(x.t)} ${hm(x.s)}–${hm(x.e)}"><b>${hm(x.s)}</b> ${lbl(x)}</div>`).join('')}</div></div>`;
  });
  const clashes=cols.flatMap(c=>c.out.filter(x=>x.clash).map(x=>({...x,d:c.d})));
  h+=`<div class="row spread"><span></span><button class="btn sm primary" data-act="ttprint">Print timetable (landscape PDF)</button></div>`;
  h+=`<div class="legend"><span class="lg ev-task">Task</span><span class="lg ev-plan">Plan</span><span class="lg ev-brk">Break</span><span class="lg ev-test">Test</span><button class="lg clash lgbtn" data-act="clashlist">${ui.clashOpen?'Hide clashes':'Clashes'} (${clashes.length})</button></div>`;
  if(ui.clashOpen) h+=`<div class="card"><h3>Clashes</h3>${clashes.length?`<div class="list">${clashes.map(x=>`<div class="li"><div class="lt"><div>${esc(x.t)}</div><div class="muted small">${fmt(x.d)} · ${hm(x.s)}–${hm(x.e)}${x.who?' · '+esc(nm('staff',x.who)):''}</div></div><div class="acts">${x.ed?`<button class="btn sm" data-act="evedit" data-ek="${x.k}" data-eid="${x.id}" data-ed="${x.d}" data-es="${x.who||''}">Move or re-assign</button>`:'<span class="muted small">Ask your manager</span>'}</div></div>`).join('')}</div>`:'<div class="muted small">No clashes this week.</div>'}</div>`;
  h+=`<div class="ttwrap"><div class="tt" style="grid-template-columns:48px repeat(${ds.length},minmax(${ds.length>1?88:200}px,1fr))">${g}</div></div>`;
  return h;
}

/* ---------- overview ---------- */
function stats(dates){
  const per={};
  liveStaff().forEach(s=>{if((!ui.f.branch||s.branchId===ui.f.branch)&&(ui.mgr||s.id===ui.me)&&(!ui.mgr||!ui.f.staff||s.id===ui.f.staff))per[s.id]={s,tot:0,done:0,missed:0,open:0,off:0,plans:0,pdone:0}});
  S.resp.forEach(r=>staffFor(r).forEach(sid=>{const p=per[sid];if(!p)return;dates.forEach(d=>{if(!applies(r,d)||(r.skip||[]).includes(d+'|'+sid))return;const st=status(r,d,sid);
    if(st==='off'){p.off++;return}p.tot++;if(st==='done')p.done++;else if(st==='missed')p.missed++;else p.open++})}));
  S.plans.forEach(pl=>{if(!dates.includes(pl.date))return;const tg=pl.staffId==='*'?Object.values(per):per[pl.staffId]?[per[pl.staffId]]:[];tg.forEach(p=>{p.plans++;if(pl.done)p.pdone++})});
  return Object.values(per).sort((a,b)=>staffLabel(a.s).localeCompare(staffLabel(b.s)));
}
function repTable(head,rows,total,numFrom=1){
  const tr=(cells,cls='')=>`<tr${cls?` class="${cls}"`:''}>${cells.map((c,i)=>`<td${i>=numFrom?' class="n"':''}>${c}</td>`).join('')}</tr>`;
  return `<div class="tablebox"><table class="rep"><thead><tr>${head.map((x,i)=>`<th${i>=numFrom?' class="n"':''}>${x}</th>`).join('')}</tr></thead><tbody>
    ${rows.map((r,i)=>tr(r,i===rows.length-1?'pre':'')).join('')}${total?tr(total,'tot'):''}</tbody></table></div>`;
}
const cellPct=(d,t)=>`${pct(d,t)}%<div class="bar"><i style="width:${pct(d,t)}%"></i></div>`;
function myProgress(dates,span){
  const kids=[...new Set([...S.resp.filter(r=>!r.archived&&staffFor(r).includes(ui.me)).map(r=>r.childId),...S.plans.filter(p=>p.staffId===ui.me||p.staffId==='*').map(p=>p.childId)].filter(Boolean))]
    .map(id=>byId('children',id)).filter(Boolean).sort((a,b)=>(a.name||'').localeCompare(b.name||''));
  if(ui.pgChild&&!kids.some(k=>k.id===ui.pgChild))ui.pgChild='';
  const ok=o=>!ui.pgChild||o.childId===ui.pgChild;
  const its=itemsFor(dates).filter(i=>i.st!=='off'&&ok(i.r)), pls=plansFor(dates).filter(ok);
  const tdone=its.filter(i=>i.st==='done'),miss=its.filter(i=>i.st==='missed'),open=its.filter(i=>i.st==='due'||i.st==='upcoming'),pd=pls.filter(p=>p.done),pn=pls.filter(p=>!p.done);
  const row=(text,date,o)=>`<div class="li"><div class="lt"><div>${esc(text)}</div><div class="muted small">${[fmt(date),timeLabel(o),o.childId&&nm('children',o.childId)].filter(Boolean).map(esc).join(' · ')}</div></div></div>`;
  const grp=(k,l,arr,f,bad)=>{const o=ui.openDays.has(k);return dayHead(k,l,bad&&arr.length?`<span class="bad">${arr.length}</span>`:String(arr.length),bad)+(o?(arr.length?`<div class="list">${arr.map(f).join('')}</div>`:'<div class="muted small" style="padding:4px 2px">None.</div>'):'')};
  let h=`<div class="card"><label class="fld"><span>Child</span><select data-uiset="pgChild"><option value="">All my children</option>${kids.map(c=>`<option value="${c.id}"${c.id===ui.pgChild?' selected':''}>${esc(c.name)}</option>`).join('')}</select></label></div>`;
  h+=progress();
  h+=`<div class="subhd">This ${span}${ui.pgChild?' · '+esc(nm('children',ui.pgChild)):''} · tap + to see the items</div>`;
  h+=grp('pg-done','Tasks done',tdone,i=>row(i.r.text,i.date,i.r));
  h+=grp('pg-miss','Missed',miss,i=>row(i.r.text,i.date,i.r),true);
  h+=grp('pg-open','Still open',open,i=>row(i.r.text,i.date,i.r));
  h+=grp('pg-pdone','Plans done',pd,p=>row(p.text,p.date,p));
  h+=grp('pg-popen','Plans not done yet',pn,p=>row(p.text,p.date,p));
  const T=its.length+pls.length,D=tdone.length+pd.length;
  h+=`<div class="card"><div class="row spread"><b>Complete</b><b class="tnum">${D} of ${T} · ${pct(D,T)}%</b></div></div>`;
  return h;
}
function vOver(){
  if(!S.staff.length&&loaded) return setupFirst();
  const dates=selDates(), span=dates.length>1?'week':'day';
  let h=weekNav();
  if(!ui.mgr){
    return h+myProgress(dates,span);
  }
  h+=`<div class="card"><div class="row spread"><div class="grid2" style="flex:1;min-width:220px"><label class="fld"><span>Branch</span><select data-filter="branch">${opt('branches',ui.f.branch,'All branches')}</select></label>
    <label class="fld"><span>Staff</span><select data-filter="staff"><option value="">All staff</option>${sortByName('staff').filter(x=>!ui.f.branch||x.branchId===ui.f.branch).map(x=>`<option value="${x.id}"${x.id===ui.f.staff?' selected':''}>${esc(staffLabel(x))}</option>`).join('')}</select></label></div>
    <div class="actions" style="align-self:flex-end"><button class="btn sm" data-act="report">Printable report</button><button class="btn sm primary" data-act="excel">Export to Excel</button></div></div></div>`;
  const st=stats(dates);
  if(!st.length) return h+`<div class="card empty">No staff in this branch yet.</div>`;
  const so=x=>dates.every(d=>signed(x.s.id,d))?`<span class="pill done">Signed</span> <button class="btn sm" data-act="unsign" data-s="${x.s.id}">Undo</button>`
    :`<button class="btn sm primary" data-act="sign" data-s="${x.s.id}">Sign off ${span}</button>`;
  const T=st.reduce((a,x)=>{['tot','done','missed','open','plans'].forEach(k=>a[k]+=x[k]);return a},{tot:0,done:0,missed:0,open:0,plans:0});
  h+=`<h2>Staff · ${dates.length>1?'Week '+isoWeek(ui.ws):fmt(dates[0])}</h2>`+repTable(['Staff','Tasks','Done','Missed','Plans done','Complete','Sign-off'],
    st.map(x=>[esc(staffLabel(x.s))+(x.off?` <span class="muted small">(${x.off} off)</span>`:'')+(hasPerm('viewas')?` <button class="btn xs" data-act="viewas" data-s="${x.s.id}">View as</button>`:''),x.tot,x.done,x.missed?`<span class="bad">${x.missed}</span>`:0,`${x.pdone}/${x.plans}`,cellPct(x.done+x.pdone,x.tot+x.plans),so(x)]),
    ['Total',T.tot,T.done,T.missed,T.plans,cellPct(T.done,T.tot),`<button class="btn sm" data-act="signall">Sign off all</button>`]);
  const br={};st.forEach(x=>{const k=x.s.branchId||'';br[k]=br[k]||{tot:0,done:0,missed:0,n:0};br[k].tot+=x.tot;br[k].done+=x.done;br[k].missed+=x.missed;br[k].n++});
  const bk=Object.keys(br).sort((a,b)=>(nm('branches',a)||'zz').localeCompare(nm('branches',b)||'zz'));
  h+=`<h2>Branches</h2>`+repTable(['Branch','Staff','Tasks','Done','Missed','Complete'],
    bk.map(k=>[esc(nm('branches',k)||'No branch'),br[k].n,br[k].tot,br[k].done,br[k].missed,cellPct(br[k].done,br[k].tot)]),
    ['Total',st.length,T.tot,T.done,T.missed,cellPct(T.done,T.tot)]);
  h+=onlineTable(dates,st.map(x=>x.s));
  h+=clockTable(dates,st.map(x=>x.s));
  h+=`<div class="card"><h3>Monthly staff report</h3><div class="grid2"><label class="fld"><span>Staff member</span><select data-uiset="mrStaff">${opt('staff',ui.mrStaff||'','Choose staff')}</select></label>
    <label class="fld"><span>Month</span><input type="month" data-uiset="mrMonth" value="${ui.mrMonth||todayIso().slice(0,7)}"></label></div>
    <div class="actions"><button class="btn primary" data-act="mrprint">Print monthly report</button></div></div>`;
  return h;
}

/* ---------- records (children + coverage) ---------- */
function records({child,grade,since}){
  const recs=[];
  S.entries.forEach(e=>{const r=byId('resp',e.rid);if(!r||e.date<since)return;const sid=e.sid||r.staffId;
    if(!ui.mgr&&sid!==ui.me)return;
    if(child&&r.childId!==child)return; if(grade&&r.gradeId!==grade&&childGrade(r.childId)!==grade)return;
    if(!e.done&&!e.comment&&!(e.photos||[]).length)return;
    recs.push({date:e.date,kind:'Task',text:r.text,sid,done:!!e.done,comment:e.comment,photos:e.photos,o:r})});
  S.plans.forEach(p=>{if(p.date<since)return;if(!ui.mgr&&p.staffId!==ui.me&&p.staffId!=='*')return;
    if(child&&p.childId!==child)return; if(grade&&p.gradeId!==grade&&childGrade(p.childId)!==grade)return;
    recs.push({date:p.date,kind:'Plan',text:p.text,sid:p.staffId,done:!!p.done,photos:p.photos,o:p})});
  return recs.sort((a,b)=>b.date.localeCompare(a.date));
}
function covTable(recs,only){
  const rows=[];let P=0,T=0;
  sortByName('curriculum').filter(s=>!only||only.includes(s.id)).forEach(s=>{
    const tops=S.topics.filter(t=>t.subjectId===s.id).sort((a,b)=>(a.name||'').localeCompare(b.name||''));
    const line=(label,tf)=>{const rs=recs.filter(r=>r.o.curriculumId===s.id&&tf(r)),pl=rs.filter(r=>r.kind==='Plan').length,tk=rs.filter(r=>r.kind==='Task'&&r.done).length,last=rs.map(r=>r.date).sort().pop();
      P+=pl;T+=tk;rows.push([esc(s.name),esc(label),pl,tk,last?fmt(last):'<span class="bad">Not yet</span>'])};
    if(!tops.length) line('—',()=>true);
    else{tops.forEach(t=>line(t.name,r=>r.o.topicId===t.id));if(recs.some(r=>r.o.curriculumId===s.id&&!r.o.topicId))line('General',r=>!r.o.topicId)}
  });
  if(!rows.length) return `<div class="card empty">${only?'No curriculum linked to this child yet. Link it in Setup → Children.':'No curriculum yet. Add it in Planning or Setup.'}</div>`;
  return repTable(['Curriculum','Subject','Plans','Tasks done','Last covered'],rows,['Total','',P,T,''],2);
}
function timeline(recs){
  if(!recs.length) return `<div class="card empty">Nothing recorded yet for this choice.</div>`;
  let h='',last='';
  recs.slice(0,120).forEach(r=>{if(r.date!==last){h+=`<div class="dayhead"><h3>${fmt(r.date)}</h3></div>`;last=r.date}
    h+=`<div class="tlrow"><span class="pill ${r.done?'done':'upcoming'}">${r.kind}${r.done?' ✓':''}</span><div class="ibody"><div class="ihead"><div class="itext">${esc(r.text)}</div><span class="who ${bcls(r.sid)}">${esc(nm('staff',r.sid))}</span></div><div class="meta">${tagsFor(r.o,r.sid)}</div>${r.comment?`<div class="cmt">${esc(r.comment)}</div>`:''}${thumbs(r.photos)}</div></div>`});
  return `<div class="tl">${h}</div>`;
}
function childCur(id,recs){const c=byId('children',id)||{};return (c.curIds&&c.curIds.length)?c.curIds:[...new Set(recs.map(r=>r.o.curriculumId).filter(Boolean))]}
function vKids(){
  if(PILOT&&ui.kidBr&&ui.kid&&(byId('children',ui.kid)||{}).branchId!==ui.kidBr)ui.kid='';
  let h=`<div class="card"><div class="grid3">${PILOT?`<label class="fld"><span>Region</span><select data-uiset="kidBr">${opt('branches',ui.kidBr||'','All regions')}</select></label>`:''}<label class="fld"><span>Child</span><select data-uiset="kid">${PILOT?'<option value="">All children</option>'+sortByName('children').filter(c=>!ui.kidBr||c.branchId===ui.kidBr).map(c=>`<option value="${c.id}"${c.id===ui.kid?' selected':''}>${esc(c.name)}</option>`).join(''):opt('children',ui.kid,'All children')}</select></label>
    ${ui.kid?'':`<label class="fld"><span>Grade</span><select data-uiset="covGrade">${opt('grades',ui.covGrade,'All grades')}</select></label><label class="fld"><span>Since</span><input type="date" data-uiset="covSince" value="${ui.covSince}"></label>`}</div>
    <span class="muted small">${ui.kid?'Every tick, comment, plan and photo for this child over the last 8 weeks.':'Curriculum coverage for all children. Choose a child to see their profile.'}${ui.mgr?'':' Shows your own records only.'}</span></div>`;
  if(!ui.kid){const recs=records({grade:ui.covGrade,since:ui.covSince||'0000'});return h+(PILOT?`<div class="actions"><button class="btn" data-act="moodxl">Export moods to Excel${ui.kidBr?' ('+esc(nm('branches',ui.kidBr))+')':''}</button></div>`:'')+`<h2>Curriculum covered</h2>`+covTable(recs,null)}
  const c=byId('children',ui.kid)||{}, recs=records({child:ui.kid,since:iso(addDays(new Date(),-56))});
  h+=`<div class="card"><h2>${esc(c.name)}</h2><div class="muted small">${[nm('grades',c.gradeId),nm('branches',c.branchId)].filter(Boolean).map(esc).join(' · ')}${ui.mgr?'':' · your records only'}</div>
    <div class="stats"><span class="pill done">${recs.filter(r=>r.kind==='Task'&&r.done).length} tasks done</span><span class="pill upcoming">${recs.filter(r=>r.kind==='Plan').length} plans</span><span class="pill">${recs.filter(r=>r.comment).length} comments</span><span class="pill">${recs.reduce((a,r)=>a+(r.photos||[]).length,0)} photos</span></div></div>`;
  if(PILOT){h+=contactCard(ui.kid)+moodCard(ui.kid);absAlerts().filter(a=>a.cid===ui.kid).forEach(a=>h+=`<div class="banner warnb"><span class="small">${esc(a.txt)}</span></div>`);const inc=S.incidents.filter(x=>x.childId===ui.kid&&(ui.isMgr||x.by===ui.me));if(inc.length)h+='<h2>Incidents</h2>'+inc.map(incCard).join('')}
  h+=`<div class="card"><h3>Parent daily summary</h3><div class="grid2"><label class="fld"><span>Day</span><input type="date" data-uiset="psDate" value="${ui.psDate||todayIso()}"></label></div>
    <div class="actions"><button class="btn primary" data-act="psprint">Print or save PDF</button><button class="btn" data-act="pscopy">Copy as text (WhatsApp)</button>${PILOT?'<button class="btn" data-act="pswa">Send on WhatsApp</button>':''}</div></div>`;
  h+=`<h2>Curriculum covered</h2>`+covTable(recs,childCur(ui.kid,recs))+`<h2>Timeline</h2>`+timeline(recs);
  return h;
}
function vCover(){
  let h=`<div class="card"><div class="grid3"><label class="fld"><span>Grade</span><select data-uiset="covGrade">${opt('grades',ui.covGrade,'All grades')}</select></label>
    <label class="fld"><span>Child</span><select data-uiset="covChild">${opt('children',ui.covChild,'All children')}</select></label>
    <label class="fld"><span>Since</span><input type="date" data-uiset="covSince" value="${ui.covSince}"></label></div>
    <span class="muted small">Plans and ticked tasks per curriculum and subject.${ui.mgr?'':' Shows your own records only.'}</span></div>`;
  const recs=records({child:ui.covChild,grade:ui.covGrade,since:ui.covSince||'0000'});
  return h+covTable(recs,ui.covChild?childCur(ui.covChild,recs):null);
}

/* ---------- feedback ---------- */
const meKey=()=>ui.mgr&&!ui.me?'mgr':ui.me+(ui.mgr?'_a':'');
const seenKey=t=>'seen_'+meKey()+(t==='inbox'?'_ib':'');
function fbKind(f){if(f.kind==='contact'||f.kind==='leave')return f.kind;if(f.kind==='unlock')return 'unlock';if(f.kind==='daydone')return 'daydone';if(f.to==='manager')return f.ref?'comment':'note';if(f.from&&f.from!=='manager')return 'staff';return 'fb'}
const isMine=f=>ui.mgr?(!f.from||f.from==='manager'):f.from===ui.me;
function fbVisible(){return S.feedback.filter(f=>ui.mgr||(!f.deleted&&(f.to===ui.me||f.to==='*'||f.from===ui.me))).sort((a,b)=>(b.at||'').localeCompare(a.at||''))}
function unreadIn(list,seen,byOthers){const ids=new Set(list.map(f=>f.id));
  const a=list.filter(f=>!f.deleted&&f.at>seen&&!isMine(f)).length;
  const b=S.replies.filter(r=>ids.has(r.fid)&&r.at>seen&&byOthers(r)).length;
  const c=list.filter(f=>ui.mgr?Object.values(f.doneBy||{}).some(t=>t>seen):Object.entries(f.approvedFor||{}).some(([k,t])=>k===ui.me&&t>seen)).length;
  return a+b+c}
function unread(){if(!signedIn())return 0;
  if(ui.isMgr) return unreadIn(fbVisible().filter(f=>fbKind(f)==='fb'),lsGet(seenKey('fb'))||'',r=>r.by!=='manager');
  return unreadIn(fbVisible(),lsGet(seenKey('fb'))||'',r=>r.by!==ui.me)}
function unreadInbox(){if(!signedIn()||!(ui.isMgr||hasPerm('inbox')))return 0;const seen=lsGet(seenKey('inbox'))||'';return unreadIn(fbVisible().filter(f=>fbKind(f)!=='fb'),seen,r=>r.by!=='manager')+photoRecs().filter(x=>x.staffPh&&x.at>seen).length}
function fbStatus(f){
  if(f.deleted) return '';
  if(f.kind==='unlock'&&f.scope==='week'){const open=!!wkLock(f.from,f.date)&&!f.closed;
    return `<div class="row small" style="gap:8px">${open?(ui.mgr?`<button class="btn sm primary" data-act="unlockweek" data-s="${f.from}" data-d="${f.date}">Unlock week ${isoWeek(parse(f.date))}</button>`:'<span class="pill due">Waiting for manager</span>'):'<span class="pill done">Unlocked</span>'}</div>`}
  if(f.kind==='unlock'&&f.scope==='plan'){const open=plocked(f.from,f.date)&&!f.closed;
    return `<div class="row small" style="gap:8px">${open?(ui.mgr?`<button class="btn sm primary" data-act="unlockplan" data-s="${f.from}" data-d="${f.date}">Unlock planning ${fmt(f.date)}</button>`:'<span class="pill due">Waiting for manager</span>'):'<span class="pill done">Unlocked</span>'}</div>`}
  if(f.kind==='unlock'){const open=signed(f.from,f.date)&&!f.closed;
    return `<div class="row small" style="gap:8px">${open?(ui.mgr?`<button class="btn sm primary" data-act="unlockday" data-s="${f.from}" data-d="${f.date}">Unlock ${fmt(f.date)}</button>`:'<span class="pill due">Waiting for manager</span>'):'<span class="pill done">Unlocked</span>'}</div>`}
  if(f.from&&f.from!=='manager') return '';
  const db_=f.doneBy||{},ap=f.approvedFor||{};
  if(ui.mgr){const ks=Object.keys(db_);if(!ks.length)return '<div><span class="pill">Not completed yet</span></div>';
    return `<div class="list">${ks.map(k=>`<div class="li"><div class="lt small"><b>${esc(nm('staff',k))}</b> marked it completed · ${fmtAt(db_[k])}</div><div class="acts">${ap[k]?'<span class="pill done">Approved</span>':`<button class="btn sm primary" data-act="fbapprove" data-id="${f.id}" data-s="${k}">Approve</button><button class="btn sm" data-act="fbreopen" data-id="${f.id}" data-s="${k}">Not yet</button>`}</div></div>`).join('')}</div>`}
  if(ap[ui.me]) return '<div><span class="pill done">Completed · approved by manager</span></div>';
  return `<label class="row small" style="gap:8px"><input type="checkbox" data-fbdone="${f.id}" ${db_[ui.me]?'checked':''}> Completed${db_[ui.me]?' <span class="pill due">Waiting for approval</span>':''}</label>`;
}
const KIND_LABEL={contact:'Parent contact',leave:'Leave request',note:'Note',comment:'Task comment',unlock:'Unlock request',daydone:'Planning completed',staff:'Between staff',fb:'Message'};
function fbCard(f){
  const from=f.from&&f.from!=='manager'?nm('staff',f.from):'Manager', to=f.to==='manager'?'Manager':nm('staff',f.to);
  const reps=S.replies.filter(r=>r.fid===f.id&&(ui.mgr||r.by==='manager'||r.by===ui.me||f.from===ui.me||f.to===ui.me)).sort((a,b)=>(a.at||'').localeCompare(b.at||''));
  if(f.deleted) return `<div class="card fbgone"><div class="row spread small muted"><span><b>${esc(from)}</b> → ${esc(to)} · ${KIND_LABEL[fbKind(f)]}</span><span>${fmtAt(f.at)}</span></div><div class="fbtext">${esc(f.text)}</div>
    ${reps.map(r=>`<div class="reply"><div class="small muted">${esc(nm('staff',r.by))} · ${fmtAt(r.at)}</div>${esc(r.text)}</div>`).join('')}
    <span class="pill missed">Deleted by ${esc(nm('staff',f.deletedBy))} · ${fmtAt(f.deletedAt)}</span></div>`;
  return `<div class="card"><div class="row spread small muted"><span><b>${esc(from)}</b> → ${esc(to)}${ui.mgr?' · '+KIND_LABEL[fbKind(f)]:''}</span><span>${fmtAt(f.at)}</span></div><div class="fbtext">${esc(f.text)}</div>
    ${reps.map(r=>`<div class="reply ${r.by==='manager'?'mgr':''}"><div class="small muted">${esc(nm('staff',r.by))} · ${fmtAt(r.at)}</div>${esc(r.text)}</div>`).join('')}
    ${fbStatus(f)}
    ${ui.mgr&&fbKind(f)==='staff'?'<span class="small muted">Between staff · view only</span>':`<div class="addnew"><input type="text" id="fb-r-${f.id}" placeholder="Write a reply"><button class="btn sm primary" data-act="fbreply" data-id="${f.id}">Reply</button></div>`}
    ${isMine(f)?`<label class="row small selbox" style="gap:6px"><input type="checkbox" data-fbsel="${f.id}" ${ui.fbSel.has(f.id)?'checked':''}> Select to delete</label>`:''}</div>`;
}
function selBar(){const sel=[...ui.fbSel].filter(id=>{const f=byId('feedback',id);return f&&!f.deleted&&isMine(f)});if(!sel.length)return '';
  return `<div class="banner"><b>${sel.length} message${sel.length>1?'s':''} selected</b><span class="small">Enter your PIN to delete.${ui.mgr?'':' Your manager still sees deleted messages, crossed out.'}</span>
    <form data-act="fbdel" class="addnew"><input type="password" id="fb-delpw" inputmode="numeric" autocomplete="off" placeholder="PIN"><button class="btn sm danger" type="submit">Delete selected</button><button class="btn sm" type="button" data-act="fbselclear">Cancel</button></form></div>`}
function vFb(){if(PILOTNOTE&&!ui.mgr)return vFbStaffP();
  let h='';
  if(ui.mgr) h+=`<div class="card"><h3>Send a message</h3><label class="fld"><span>To</span><select id="fb-to" data-fbto="1">${opt('staff',ui.fbTo,'Choose staff',[['*','All staff']])}</select></label>
    <label class="fld"><span>Message</span><textarea id="fb-text" rows="3" placeholder="e.g. Great work with the sensory room this week"></textarea></label>
    <div class="actions"><button class="btn primary" data-act="fbsend">Send message</button></div></div>`;
  else h+=`<div class="card"><h3>Send a message</h3><label class="fld"><span>To</span><select id="fb-noteto"><option value="manager">Manager</option>${sortByName('staff').filter(x=>x.id!==ui.me).map(x=>`<option value="${x.id}">${esc(staffLabel(x))}</option>`).join('')}</select></label>
    <label class="fld"><span>Message</span><textarea id="fb-note" rows="3" placeholder="e.g. We are out of paint for Grade R"></textarea></label>
    <div class="actions"><button class="btn primary" data-act="fbnote">Send message</button></div></div>`;
  const fv=ui.mgr&&ui.fbTo&&ui.fbTo!=='*'?ui.fbTo:'';
  const list=fbVisible().filter(f=>(!ui.mgr||fbKind(f)==='fb')&&(!fv||f.to===fv));
  if(ui.mgr) h+=`<div class="row spread"><h2>${fv?'Messages to '+esc(nm('staff',fv)):'All messages you sent'} <span class="count">${list.length}</span></h2><span class="muted small">Latest first · staff messages are in Inbox</span></div>`;
  h+=selBar();
  if(!list.length) return h+`<div class="card empty">${fv?'No feedback to '+esc(nm('staff',fv))+' yet.':ui.mgr?'No feedback sent yet.':'No messages yet.'}</div>`;
  list.forEach(f=>h+=fbCard(f));
  return h;
}
function photoRecs(){const out=[];
  S.entries.forEach(e=>{if(!(e.photos||[]).length)return;const r=byId('resp',e.rid)||{};out.push({c:'entries',rid:e.id,sid:e.sid||r.staffId,kind:'Task',text:r.text||'Task',date:e.date,photos:e.photos,at:e.photos.map(p=>p.at||'').sort().pop()||e.at||'',staffPh:e.photos.some(p=>p.by!=='manager')})});
  S.plans.forEach(p=>{if(!(p.photos||[]).length)return;out.push({c:'plans',rid:p.id,sid:p.staffId,kind:'Plan',text:p.text,date:p.date,photos:p.photos,at:p.photos.map(x=>x.at||'').sort().pop()||p.updated||'',staffPh:p.photos.some(x=>x.by!=='manager')})});
  return out.sort((a,b)=>b.date.localeCompare(a.date))}
const dOf=f=>((f.deleted&&f.deletedBy!=='manager'?f.deletedAt:f.at)||'').slice(0,10);
function ibDates(){return [...new Set(fbVisible().filter(f=>fbKind(f)!=='fb'||f.doneBy).map(dOf).filter(Boolean))].sort().reverse()}
function vInbox(){
  const groups=[['note','Notes to manager'],['comment','Task comments'],['unlock','Unlock requests'],['daydone','Planning completed'],['approve','Waiting for approval'],['staff','Between staff'],['photos','Photos from staff'],['deleted','Deleted by staff']];
  if(ui.ibPrev===undefined)ui.ibPrev=lsGet(seenKey('inbox'))||'';const seen=ui.ibPrev;
  let h=`<div class="card"><div class="grid2"><label class="fld"><span>Staff</span><select data-uiset="ibStaff"><option value="">All staff</option>${sortByName('staff').map(x=>`<option value="${x.id}"${x.id===ui.ibStaff?' selected':''}>${esc(staffLabel(x))}</option>`).join('')}</select></label>
    <label class="fld"><span>Date</span><select data-uiset="ibDate"><option value="">All dates</option>${ibDates().map(d=>`<option value="${d}"${d===ui.ibDate?' selected':''}>${fmt(d)}</option>`).join('')}</select></label></div><span class="muted small">Messages from staff, latest first. Tap a type to open it. Deleted messages go by the day they were deleted.</span></div>`+selBar();
  const all=fbVisible().filter(f=>(!ui.ibStaff||f.from===ui.ibStaff||f.to===ui.ibStaff)&&(!ui.ibDate||dOf(f)===ui.ibDate));
  {const nf=all.filter(f=>!f.deleted&&((f.at>seen&&!isMine(f))||Object.values(f.doneBy||{}).some(t=>t>seen))).map(f=>({at:f.at,html:fbCard(f)}));
   const np=photoRecs().filter(x=>x.staffPh&&x.at>seen&&(!ui.ibStaff||x.sid===ui.ibStaff)).map(x=>({at:x.at,html:`<div class="card"><div class="row spread small muted"><span><b>${esc(nm('staff',x.sid))}</b> · Photo · ${x.kind}</span><span>${fmtAt(x.at)}</span></div><div class="fbtext">${esc(x.text)}</div>${thumbs(x.photos)}</div>`}));
   const nn=[...nf,...np].sort((a,b)=>(b.at||'').localeCompare(a.at||''));
   h+=`<div class="newhd"><b>New since your last visit</b><span class="pill ${nn.length?'missed':''}">${nn.length}</span></div>`+(nn.length?nn.map(x=>x.html).join(''):'<div class="muted small" style="padding:0 2px 6px">Nothing new.</div>')+'<div class="subhd">All messages by type</div>'}
  groups.forEach(([k,l])=>{
    if(k==='photos'){const ph=photoRecs().filter(x=>(!ui.ibStaff||x.sid===ui.ibStaff)&&(!ui.ibDate||x.date===ui.ibDate)),key='ib-photos',o=ui.openDays.has(key),nw=ph.filter(x=>x.staffPh&&(x.at||'')>seen).length;
      h+=dayHead(key,l,`${ph.length}${nw?` · <span class="bad">${nw} new</span>`:''}`);
      if(o)h+=ph.length?ph.map(x=>`<div class="card"><div class="row spread small muted"><span><b>${esc(nm('staff',x.sid))}</b> · ${x.kind}</span><span>${fmt(x.date)}</span></div><div class="fbtext">${esc(x.text)}</div>${thumbs(x.photos)}</div>`).join(''):'<div class="muted small" style="padding:4px 2px">No photos yet.</div>';return}
    const items=k==='deleted'?all.filter(f=>f.deleted&&f.deletedBy!=='manager').sort((a,b)=>(b.deletedAt||'').localeCompare(a.deletedAt||'')):k==='approve'?all.filter(f=>fbKind(f)==='fb'&&!f.deleted&&Object.keys(f.doneBy||{}).some(s=>!(f.approvedFor||{})[s])):all.filter(f=>!f.deleted&&fbKind(f)===k);
    const nw=items.filter(f=>(!f.deleted&&f.at>seen&&!isMine(f))||Object.values(f.doneBy||{}).some(t=>t>seen)).length, key='ib-'+k, o=ui.openDays.has(key);
    h+=dayHead(key,l,`${items.length}${nw?` · <span class="bad">${nw} new</span>`:''}`);
    if(o) h+=items.length?items.map(fbCard).join(''):'<div class="muted small" style="padding:4px 2px">Nothing here.</div>';
  });
  return h;
}

/* ---------- responsibilities ---------- */
function respForm(){
  const r=ui.editing.resp?byId('resp',ui.editing.resp):null, v=(k,d='')=>r?(r[k]??d):d, once=v('recur','weekly')==='once', days=v('days',[]);
  return `<div class="card" id="respform"><h3>${r?'Edit responsibility':'New responsibility'}</h3>
  <label class="fld"><span>Staff member</span><select id="rf-staff">${opt('staff',v('staffId'),'Choose staff',[['*','All staff']])}</select></label>
  <div class="fld"><span>Repeats</span><div class="seg"><label><input type="radio" name="rf-recur" id="rf-recur-w" value="weekly" ${!once?'checked':''}> Every week</label><label><input type="radio" name="rf-recur" id="rf-recur-o" value="once" ${once?'checked':''}> Once-off</label></div></div>
  <div class="fld" id="rf-dayswrap"><span>Days</span><div class="wkdays">${[1,2,3,4,5].map(n=>`<label><input type="checkbox" id="rf-d${n}" ${days.includes(n)?'checked':''}> ${DAYS[n]}</label>`).join('')}<button class="btn sm" type="button" data-act="alldays">Mon–Fri</button></div></div>
  <div class="grid2"><label class="fld" id="rf-oncewrap"><span>Date</span><input type="date" id="rf-date" value="${esc(v('date'))}"></label>
  <label class="fld" id="rf-fromwrap"><span>Starts from</span><input type="date" id="rf-from" value="${esc(v('from',todayIso()))}"></label></div>
  ${timeBlock('rf',r)}
  <div class="grid2"><label class="fld"><span>Child (optional)</span><select id="rf-child">${opt('children',v('childId'),'—')}</select></label>
  <label class="fld"><span>Grade (optional)</span><select id="rf-grade">${opt('grades',v('gradeId'),'—')}</select></label></div>
  ${subjTopic('rf',r)}
  ${pickBox('rf-text',S.resp.map(x=>x.text))}
  <label class="fld"><span>Responsibility · add more detail</span><textarea id="rf-text" rows="2" placeholder="Type freely, or add to what you chose above">${esc(v('text'))}</textarea></label>
  ${clashBox('rf')}<div class="actions"><button class="btn primary" data-act="saveresp">${ui.clash&&ui.clash.f==='rf'?'Save anyway':r?'Save changes':'Save responsibility'}</button>${r?'<button class="btn" data-act="cancelresp">Cancel</button>':''}</div></div>`;
}
function syncRecur(){const o=document.getElementById('rf-recur-o');if(!o)return;const once=o.checked;
  document.getElementById('rf-dayswrap').hidden=once;document.getElementById('rf-oncewrap').hidden=!once;document.getElementById('rf-fromwrap').hidden=once}
function respDesc(r){
  const when=r.recur==='once'?'Once: '+fmt(r.date):((r.days||[]).length===5?'Mon–Fri':(r.days||[]).map(d=>DAYS[d]).join(', '));
  return [when,timeLabel(r),r.childId&&'Child: '+nm('children',r.childId),nm('grades',r.gradeId),nm('curriculum',r.curriculumId),tName(r.topicId)].filter(Boolean).map(esc).join(' · ');
}
function vResp(){if(PILOTNOTE)return vRespP();
  let h=respForm();
  const bOf=id=>(byId('staff',id)||{}).branchId;
  const arch=S.resp.filter(r=>r.archived);
  const list=S.resp.filter(r=>!r.archived&&(!ui.respStaff||r.staffId===ui.respStaff)&&(!ui.respBranch||r.staffId==='*'||bOf(r.staffId)===ui.respBranch));
  h+=`<div class="row spread"><h2>All responsibilities <span class="count">${list.length}</span></h2><div class="actions"><select data-uiset="respBranch" style="width:auto;max-width:180px">${opt('branches',ui.respBranch,'All branches')}</select>
    <select data-uiset="respStaff" style="width:auto;max-width:180px"><option value="">Everyone</option><option value="*"${ui.respStaff==='*'?' selected':''}>Tasks for all staff</option>${sortByName('staff').filter(x=>!ui.respBranch||x.branchId===ui.respBranch).map(x=>`<option value="${x.id}"${x.id===ui.respStaff?' selected':''}>${esc(staffLabel(x))}</option>`).join('')}</select></div></div>`;
  if(!list.length&&!arch.length) return h+`<div class="card empty">No responsibilities yet. Add the first one above.</div>`;
  const groups={};list.forEach(r=>(groups[r.staffId]=groups[r.staffId]||[]).push(r));
  Object.keys(groups).sort((a,b)=>nm('staff',a).localeCompare(nm('staff',b))).forEach(sid=>{
    h+=`<div class="card"><h3>${esc(nm('staff',sid)||'Unassigned')} <span class="count">${groups[sid].length}</span></h3><div class="list">`+
    groups[sid].sort((a,b)=>oStart(a).localeCompare(oStart(b))).map(r=>`<div class="li"><div class="lt"><div>${esc(r.text)}</div><div class="muted small">${respDesc(r)}</div>${ui.reassign===r.id?`<div class="addnew" style="margin-top:6px"><select id="tf-ra">${opt('staff',r.staffId,'Choose staff',[['*','All staff']])}</select><button class="btn sm primary" data-act="rasave" data-id="${r.id}">Save</button><button class="btn sm" data-act="racancel">Cancel</button></div>`:''}</div>
    <div class="acts"><button class="btn sm" data-act="editresp" data-id="${r.id}">Edit</button><button class="btn sm" data-act="reassign" data-id="${r.id}">Re-assign</button><button class="btn sm danger" data-act="del" data-c="resp" data-id="${r.id}">${ui.confirmDel==='resp'+r.id?'Tap again':'Delete'}</button><button class="btn sm" data-act="arch" data-c="resp" data-id="${r.id}">Archive</button></div></div>`).join('')+`</div></div>`;
  });
  if(arch.length){h+=`<div><button class="btn sm" data-act="togarch">${ui.showArch?'Hide':'Show'} archived (${arch.length})</button></div>`;
    if(ui.showArch)h+=`<div class="card"><h3>Archived <span class="count">${arch.length}</span></h3><p class="muted small" style="margin:0">Archived tasks stop from the archive date. Past ticks and reports stay.</p><div class="list">${arch.map(r=>`<div class="li"><div class="lt"><div>${esc(r.text)}</div><div class="muted small">${esc(nm('staff',r.staffId))} · archived ${fmt(r.archivedAt)}</div></div>
    <div class="acts"><button class="btn sm" data-act="restore" data-c="resp" data-id="${r.id}">Restore</button><button class="btn sm danger" data-act="del" data-c="resp" data-id="${r.id}">${ui.confirmDel==='resp'+r.id?'Tap again':'Delete forever'}</button></div></div>`).join('')}</div></div>`}
  return h;
}

/* ---------- setup ---------- */
const SETUP=[
 {c:'branches',t:'Branches',f:[{k:'name',l:'Branch name',ph:'e.g. Mbombela'},...(PILOT?[{k:'theme',l:'App colour for this branch',opts:THEMES.map(t=>[t.id,t.name])}]:[])],show:x=>`${esc(x.name)} <span class="who bc${Math.max(0,sortByName('branches').findIndex(b=>b.id===x.id))%6}">Colour</span>`},
 {c:'staff',t:'Staff',f:[{k:'first',l:'Name'},{k:'last',l:'Surname'},{k:'branchId',l:'Branch',s:'branches'},{k:'role',l:'Role (optional)',ph:'e.g. Facilitator'},{k:'pin',l:'Password / PIN',def:'1234'},{k:'dob',l:'Birthday (optional)',type:'date'}],
   show:x=>`${esc(staffLabel(x))}<div class="muted small">${[nm('branches',x.branchId),x.role].filter(Boolean).map(esc).join(' · ')||'No branch'}</div>`},
 {c:'grades',t:'Grades',f:[{k:'name',l:'Grade',ph:'e.g. Grade R'}],show:x=>esc(x.name)},
 {c:'children',t:'Children',f:[{k:'name',l:'Child name and surname'},{k:'gradeId',l:'Grade',s:'grades'},{k:'branchId',l:'Branch',s:'branches'},{k:'dob',l:'Birthday',type:'date'},{k:'medical',l:'Medical or allergy alert (optional)',ph:'e.g. Peanut allergy, epilepsy'},{k:'p1',l:'Parent 1 name'},{k:'p1dob',l:'Parent 1 birthday',type:'date'},{k:'p2',l:'Parent 2 name'},{k:'p2dob',l:'Parent 2 birthday',type:'date'},{k:'curIds',l:'Curriculum for this child',multi:'curriculum'}],
   show:x=>`${esc(x.name)}${x.medical?' <span class="pill missed">Medical alert</span>':''}<div class="muted small">${[nm('grades',x.gradeId),nm('branches',x.branchId),...(x.curIds||[]).map(i=>nm('curriculum',i)),x.dob&&'Birthday '+fmt(x.dob).slice(4)].filter(Boolean).map(esc).join(' · ')}</div>`},
 ...(PILOT?[{c:'groups',t:'Groups (for class planning)',f:[{k:'name',l:'Group name',ph:'e.g. Group A'},{k:'branchId',l:'Branch',s:'branches'},{k:'childIds',l:'Children in this group',multi:'children'}],show:x=>`${esc(x.name)}<div class="muted small">${[nm('branches',x.branchId),(x.childIds||[]).map(i=>(nm('children',i)||'').split(' ')[0]).join(', ')||'No children yet'].filter(Boolean).map(esc).join(' · ')}</div>`}]:[]),
 {c:'curriculum',t:'Curriculum',f:[{k:'name',l:'Curriculum',ph:'e.g. Impaq'}],show:x=>`${esc(x.name)}<div class="muted small">${S.topics.filter(t=>t.subjectId===x.id).map(t=>esc(t.name)).join(', ')||'No subjects yet'}</div>`},
 {c:'topics',t:'Subjects',f:[{k:'subjectId',l:'Curriculum',s:'curriculum'},{k:'name',l:'Subject',ph:'e.g. Maths'}],show:x=>`${esc(x.name)}<div class="muted small">${esc(nm('curriculum',x.subjectId))}</div>`},
 {c:'periods',t:'Time periods',f:[{k:'name',l:'Name',ph:'e.g. Period 1'},{k:'start',l:'Start',type:'timesel'},{k:'end',l:'End',type:'timesel'}],show:x=>esc(periodLabel(x))},
 {c:'breaks',t:'Break times',f:[{k:'name',l:'Name',ph:'e.g. Tea break'},{k:'start',l:'Start',type:'timesel'},{k:'end',l:'End',type:'timesel'},{k:'branchId',l:'Branch (blank = all)',s:'branches'}],
   show:x=>`${esc(x.name||'Break')} · ${esc(x.start||'')}${x.end?'–'+esc(x.end):''}<div class="muted small">${esc(nm('branches',x.branchId)||'All branches')}</div>`},
 {c:'RESP',t:'Responsibility block'},
 {c:'tests',t:'Test reminders',f:[{k:'topicId',l:'Subject',s:'topics'},{k:'childId',l:'Child',s:'children'},{k:'date',l:'Date',type:'date'},...(PILOT?[{k:'time',l:'Time',type:'timesel'}]:[]),{k:'branchId',l:'Branch',s:'branches'},{k:'gradeId',l:'Grade',s:'grades'},{k:'curId',l:'Curriculum',s:'curriculum'},{k:'staffId',l:'Staff (blank = all at branch)',s:'staff'},{k:'lead',l:'Remind days before',type:'number',def:'3'}],
   show:x=>`${esc(x.title)} · <b>${fmt(x.date)}${x.time?' '+esc(x.time):''}</b><div class="muted small">${[nm('grades',x.gradeId),nm('curriculum',x.curId),x.staffId?nm('staff',x.staffId):'All staff'+(x.branchId?' at '+nm('branches',x.branchId):''),'remind '+(x.lead||3)+' days before'].filter(Boolean).map(esc).join(' · ')}</div>`},
 {c:'leave',t:'Staff leave',f:[{k:'staffId',l:'Staff',s:'staff'},{k:'from',l:'From',type:'date'},{k:'to',l:'To',type:'date'},{k:'note',l:'Note (optional)'},{k:'coverId',l:'Cover person (optional)',s:'staff'}],
   show:x=>`${esc(nm('staff',x.staffId))}<div class="muted small">${fmt(x.from)} – ${fmt(x.to||x.from)}${x.coverId?' · Cover: '+esc(nm('staff',x.coverId)):''}${x.note?' · '+esc(x.note):''}</div>`},
 {c:'terms',t:'School terms',f:[{k:'name',l:'Term',ph:'e.g. Term 4'},{k:'start',l:'Starts',type:'date'},{k:'end',l:'Ends',type:'date'}],show:x=>`${esc(x.name)}<div class="muted small">${fmt(x.start)} – ${fmt(x.end)} ${x.start?parse(x.start).getFullYear():''}</div>`},
 {c:'holidays',t:'Public holidays',f:[{k:'date',l:'Date',type:'date'},{k:'name',l:'Holiday',ph:'e.g. Day of Reconciliation'}],show:x=>`${fmt(x.date)} · ${esc(x.name)}`},
 {c:'ABS',t:'Absence records'},
 {c:'BACKUP',t:'Backup · export and import'},
 {c:'RESET',t:'Reset test data'},
 {c:'LOG',t:'Change log'},
 {c:'ROLES',t:'Access & roles'},
 {c:'SEC',t:'Security'}
];
if(PILOTNOTE){const ch=SETUP.find(s=>s.c==='children');if(ch){const at=k=>ch.f.findIndex(f=>f.k===k)+1;ch.f.splice(at('dob'),0,{k:'sex',l:'Boy or girl',opts:[['','—'],['girl','Girl'],['boy','Boy']]});ch.f.splice(at('p1'),0,{k:'p1cell',l:'Parent 1 cellphone',type:'tel',ph:'e.g. 082 123 4567'});ch.f.splice(at('p2'),0,{k:'p2cell',l:'Parent 2 cellphone',type:'tel',ph:'e.g. 082 123 4567'})}}
function secForm(sec){
  const ed=ui.editing[sec.c]?byId(sec.c,ui.editing[sec.c]):null;
  const fields=sec.f.map(f=>{const id=`sf-${sec.c}-${f.k}`,v=ed?(ed[f.k]??''):(f.def||'');
    if(f.multi){const arr=Array.isArray(v)?v:[];return `<div class="fld" style="grid-column:1/-1"><span>${f.l}</span><div class="chk">${sortByName(f.multi).map(x=>`<label><input type="checkbox" id="${id}-${x.id}"${arr.includes(x.id)?' checked':''}> ${esc(x.name)}</label>`).join('')||`<span class="muted small">Add ${f.multi==='children'?'children':'curriculum'} first</span>`}</div></div>`}
    if(f.opts){return `<label class="fld"><span>${f.l}</span><select id="${id}">${f.opts.map(([k,l])=>`<option value="${k}"${k===(v||f.opts[0][0])?' selected':''}>${esc(l)}</option>`).join('')}</select></label>`}
    const inp=f.type==='timesel'?`<select id="${id}">${timeOpts(v,'—')}</select>`:f.s?`<select id="${id}">${opt(f.s,v,'—')}</select>`:`<input type="${f.type||'text'}" id="${id}" value="${esc(v)}" placeholder="${esc(f.ph||'')}"${f.k==='pin'?' inputmode="numeric"':''}>`;
    return `<label class="fld"><span>${f.l}</span>${inp}</label>`}).join('');
  return `<div class="grid2">${fields}</div><div class="actions"><button class="btn primary" data-act="savesec" data-c="${sec.c}">${ed?'Save changes':'Add'}</button>${ed?`<button class="btn" data-act="cancelsec" data-c="${sec.c}">Cancel</button>`:''}${sec.c==='periods'&&!S.periods.length?'<button class="btn" data-act="stdperiods">Add standard periods</button>':''}${sec.c==='staff'&&window.fbAuth&&ui.isMgr?`<button class="btn" data-act="pwresetall">${ui.confirmDel==='pwall'?'Tap again to email everyone':'Email all staff a password reset'}</button>`:''}</div>`;
}
const RESET_GROUPS=[['Daily records',[['entries','Ticks and comments'],['plans','Planning'],['signoffs','Sign-offs'],['plocks','Planning locks'],['online','Online time'],['attendance','Attendance register'],['clock','Clock-ins'],['feedback','Messages and notes'],['replies','Message replies'],['announce','Announcements'],['requests','Resource requests'],['contacts','Parent contact log'],['log','Change log']]],
  ['Duties and calendar',[['resp','Responsibilities (duties)'],['tests','Test reminders'],['terms','School terms'],['breaks','Break times'],['leave','Staff leave'],['holidays','Public holidays']]],
  ['Lists',[['staff','Staff'],['children','Children'],['branches','Branches'],['grades','Grades'],['curriculum','Curriculum'],['topics','Subjects'],['periods','Time periods']]]];
const RESET_ALL=RESET_GROUPS.flatMap(g=>g[1]);
function rsRows(c){const w=ui.rsWho;if(!w)return S[c];const L=RESET_GROUPS[2][1].map(x=>x[0]);if(L.includes(c))return [];
  return S[c].filter(x=>{switch(c){case 'entries':{const r=byId('resp',x.rid)||{};return (x.sid||r.staffId)===w}
    case 'plans':case 'resp':case 'leave':case 'tests':case 'signoffs':case 'plocks':return x.staffId===w;
    case 'online':case 'clock':return x.sid===w;
    case 'feedback':return x.from===w||x.to===w;case 'replies':{const f=byId('feedback',x.fid)||{};return x.by===w||f.from===w||f.to===w}
    default:return false}})}
function archList(c){const a=S[c].filter(x=>x.archived);if(!a.length)return '';
  return `<details class="flt"><summary><span>Archived (${a.length})</span><span class="fsum">History kept <span class="chev">▾</span></span></summary><div class="list">${a.map(x=>`<div class="li"><div class="lt">${esc(c==='staff'?staffLabel(x):x.name)}<div class="muted small">Archived ${fmt(x.archivedAt)}</div></div><div class="acts"><button class="btn sm" data-act="restore" data-c="${c}" data-id="${x.id}">Restore</button><button class="btn sm danger" data-act="del" data-c="${c}" data-id="${x.id}">${ui.confirmDel===c+x.id?'Tap again':'Delete forever'}</button></div></div>`).join('')}</div></details>`}
function staffBtns(x){return (hasPerm('viewas')?`<button class="btn sm" data-act="viewas" data-s="${x.id}">View as</button>`:'')+(window.fbAuth&&ui.isMgr&&x.email?`<button class="btn sm" data-act="pwreset" data-e="${esc(x.email)}">Reset password</button>`:'')}
function vSetup(){
  let h=`<div class="row spread"><h2>Setup</h2><span class="muted small">v${VERSION}</span></div>`;
  const wrap=(sec,body,count)=>`<details class="sec" data-sec="${sec.c}"${ui.open.has(sec.c)?' open':''}><summary>${sec.t}${count!=null?`<span class="count" style="margin-left:auto;margin-right:10px">${count}</span>`:''}</summary><div class="secbody">${body}</div></details>`;
  (PILOTNOTE?[...SETUP].sort((a,b)=>String(a.t).replace(/<[^>]*>/g,'').localeCompare(String(b.t).replace(/<[^>]*>/g,''))):SETUP).forEach(sec=>{
    if(!ui.isMgr&&['staff','branches','RESET','BACKUP','SEC','ROLES','LOG'].includes(sec.c))return;
    if(sec.c==='RESP'){h+=wrap(sec,respForm().replace('class="card" id="respform"','id="respform" style="display:flex;flex-direction:column;gap:10px"')+'<button class="btn" data-act="tab" data-t="resp">See all responsibilities</button>',S.resp.length);return}
    if(sec.c==='RESET'){
      h+=wrap(sec,`<p class="muted small" style="margin:0">Delete test entries before going live. Tick what to clear, enter the admin password, then tap Reset twice. This cannot be undone, so export a backup first.</p>
        ${''}<div class="grid2"><label class="fld"><span>Whose records</span><select data-uiset="rsWho"><option value="">All staff</option>${sortByName('staff').map(x=>`<option value="${x.id}"${x.id===ui.rsWho?' selected':''}>${esc(staffLabel(x))}</option>`).join('')}</select></label></div>
        ${RESET_GROUPS.map(([g,items])=>{const lists=g==='Lists',dis=lists&&ui.rsWho;return `<div class="fld"><span>${g}${dis?' · not available for one staff member':''}</span><div class="chk">${items.map(([c,l])=>`<label${dis?' style="opacity:.5"':''}><input type="checkbox" id="sf-rs-${c}"${dis?' disabled':''}> ${l} <span class="muted">(${rsRows(c).length})</span></label>`).join('')}</div></div>`}).join('')}
        <div class="grid2"><label class="fld"><span>Admin password</span><input type="password" id="sf-rs-pw" inputmode="numeric" autocomplete="off" placeholder="••••"></label></div>
        <div class="actions"><button class="btn" data-act="backup">Export backup first</button><button class="btn danger" data-act="resetgo">${ui.confirmDel==='reset'?`Tap again to delete ${ui.resetN} records`:'Reset selected'}</button></div>`);return}
    if(sec.c==='BACKUP'){
      const imp=ui.importData;
      h+=wrap(sec,`<p class="muted small" style="margin:0">Export saves every record to one backup file. Import restores a backup into this page or a new copy of it. Photos stay on the original page; the backup keeps their links.</p>
        <div class="actions"><button class="btn primary" data-act="backup">Export backup</button><label class="btn">Import backup<input class="vh" type="file" accept=".json,application/json" data-import="1"></label></div>
        ${imp?`<div class="banner"><b>Ready to restore</b><span class="small">Backup from ${fmtAt(imp.exported)} with ${COLLS.reduce((a,c)=>a+((imp.data[c]||[]).length),0)} records. Records with the same ID are overwritten. Nothing else is deleted.</span>
        <div class="actions"><button class="btn sm primary" data-act="importgo">Restore now</button><button class="btn sm" data-act="importcancel">Cancel</button></div></div>`:''}`);return}
    if(sec.c==='ABS'){const r=absRange(),rows=absRows(r);
      h+=wrap(sec,`<div class="grid3"><label class="fld"><span>Period</span><select data-uiset="absPeriod">${[['week','Week'],['month','Month'],['year','Year'],...S.terms.map(t=>['term:'+t.id,t.name])].map(([v,l])=>`<option value="${v}"${v===(ui.absPeriod||'week')?' selected':''}>${esc(l)}</option>`).join('')}</select></label>
        ${(ui.absPeriod||'week').startsWith('term:')?'':`<label class="fld"><span>Date in the period</span><input type="date" data-uiset="absRef" value="${ui.absRef||todayIso()}"></label>`}
        <label class="fld"><span>Branch</span><select data-uiset="absBranch">${opt('branches',ui.absBranch||'','All branches')}</select></label></div>
        <div class="muted small">${r.label} · ${rows.length} child${rows.length===1?'':'ren'} absent · ${rows.reduce((a,x)=>a+x.dates.length,0)} absent day${rows.reduce((a,x)=>a+x.dates.length,0)===1?'':'s'} in total</div>
        <div class="actions"><button class="btn primary" data-act="absprint">Print absence report</button><button class="btn" data-act="absxl">Export to Excel</button></div>`);return}
    if(sec.c==='ROLES'){const who=ui.roleStaff||'',st=byId('staff',who),cur=st?(st.perms||[]):[],holders=sortByName('staff').filter(x=>(x.perms||[]).length);
      h+=wrap(sec,`<p class="muted small" style="margin:0">Give someone, like a head mistress, some of the manager's functions. Choose the person, tick what they may do, then save. They see the new tabs next time they open the app.</p>
        <div class="grid2"><label class="fld"><span>Staff member</span><select data-uiset="roleStaff"><option value="">Choose a person</option>${sortByName('staff').map(x=>`<option value="${x.id}"${x.id===who?' selected':''}>${esc(staffLabel(x))}</option>`).join('')}</select></label></div>
        ${st?`<div class="chk" style="flex-direction:column;align-items:flex-start">${PERMS.map(([k,l])=>`<label><input type="checkbox" id="sf-pm-${k}"${cur.includes(k)?' checked':''}> ${esc(l)}</label>`).join('')}</div><div class="actions"><button class="btn primary" data-act="saveperms">Save access for ${esc(staffLabel(st))}</button></div>`:''}
        ${holders.length?`<div class="list">${holders.map(x=>`<div class="li"><div class="lt"><b>${esc(staffLabel(x))}</b><div class="muted small">${(x.perms||[]).map(k=>esc((PERMS.find(p=>p[0]===k)||[k,k])[1].split(':')[0])).join(' · ')}</div></div><div class="acts"><button class="btn sm" data-act="roleedit" data-s="${x.id}">Edit</button></div></div>`).join('')}</div>`:'<div class="muted small">Nobody has extra access yet.</div>'}`);return}
    if(sec.c==='LOG'){const lg=[...S.log].sort((a,b)=>(b.at||'').localeCompare(a.at||'')).slice(0,100);
      h+=wrap(sec,`<div class="actions"><button class="btn sm primary" data-act="logxl">Export to Excel</button></div>`+(lg.length?`<div class="list">${lg.map(l=>`<div class="li"><div class="lt">${esc(l.what)}<div class="muted small">${fmtAt(l.at)} · ${esc(l.who)}</div></div></div>`).join('')}</div>`:'<div class="muted small">No changes recorded yet.</div>'),S.log.length);return}
    if(sec.c==='SEC'){h+=wrap(sec,`<p class="muted small" style="margin:0">The admin password signs in as Manager and works for any staff name. Staff passwords are set per person under Staff. Default for both is 1234. This keeps staff in their own view; it is not bank-level security.</p>
      <div class="grid2"><label class="fld"><span>New admin password</span><input type="text" id="sf-pw-new" inputmode="numeric" placeholder="e.g. 4821"></label></div><div class="actions"><button class="btn primary" data-act="savepw">Change password</button></div>`);return}
    const rows=sortByName(sec.c);
    if(sec.c==='periods')rows.sort((a,b)=>(a.start||'').localeCompare(b.start||''));
    if(['tests','holidays'].includes(sec.c))rows.sort((a,b)=>(a.date||'').localeCompare(b.date||''));
    h+=wrap(sec,secForm(sec)+(rows.length?`<div class="list">${rows.map(x=>`<div class="li"><div class="lt">${sec.show(x)}</div><div class="acts"><button class="btn sm" data-act="editsec" data-c="${sec.c}" data-id="${x.id}">Edit</button>${sec.c==='staff'?staffBtns(x):''}${sec.c==='branches'&&ui.isMgr?`<button class="btn sm" data-act="qrshow" data-id="${x.id}">QR code</button>`:''}${['staff','children'].includes(sec.c)?`<button class="btn sm" data-act="arch" data-c="${sec.c}" data-id="${x.id}">Archive</button>`:`<button class="btn sm danger" data-act="del" data-c="${sec.c}" data-id="${x.id}">${ui.confirmDel===sec.c+x.id?'Tap again':'Delete'}</button>`}</div></div>`).join('')}</div>`:'<div class="muted small">Nothing added yet.</div>')+archList(sec.c),rows.length);
  });
  return h;
}

/* ---------- exports ---------- */
function exportRows(){
  const ds=weekDates(ui.ws);
  const chk=itemsFor(ds).map(({r,date,sid,st})=>{const e=entryMap[ekey(r,date,sid)]||{};const sb=byId('staff',sid)||{};
    return {Date:date,Day:DAYS[parse(date).getDay()],Time:timeLabel(r),Staff:staffLabel(sb),Branch:nm('branches',sb.branchId),Responsibility:r.text,Child:nm('children',r.childId),Grade:nm('grades',r.gradeId),
      Curriculum:nm('curriculum',r.curriculumId),Subject:tName(r.topicId),Status:st==='off'?offReason(sid,date):ST_LABEL[st],Comment:e.comment||'','Ticked by':e.done?nm('staff',e.by):'','Ticked at':e.done&&e.at?fmtAt(e.at):'',
      'Signed off':signed(sid,date)?'Yes':'',Photos:(e.photos||[]).length||''}});
  const pl=plansFor(ds).map(p=>({Date:p.date,Day:DAYS[parse(p.date).getDay()],Time:timeLabel(p),Staff:nm('staff',p.staffId),Planning:p.text,Child:nm('children',p.childId),Grade:nm('grades',p.gradeId),Curriculum:nm('curriculum',p.curriculumId),Subject:tName(p.topicId),Done:p.done?'Yes':'No'}));
  return {chk,pl};
}
async function save(filename,data){
  if(!dl){try{dl=await window.claude?.use?.('downloads')}catch(e){dl=null}}
  if(!dl){toast('Downloads are not available in this view.');return false}
  try{await dl.save({filename,data});return true}catch(e){if(e&&e.code!=='declined')toast('Could not save the file ('+(e.code||'error')+').');return false}
}
async function doExcel(){
  if(typeof XLSX==='undefined'){toast('Excel export could not load. Check your connection.');return}
  const {chk,pl}=exportRows(), wb=XLSX.utils.book_new();
  const sum=stats(weekDates(ui.ws)).map(x=>({Staff:staffLabel(x.s),Branch:nm('branches',x.s.branchId),Tasks:x.tot,Done:x.done,Missed:x.missed,Open:x.open,'Off tasks':x.off,Plans:x.plans,'Complete %':pct(x.done,x.tot)}));
  XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(chk.length?chk:[{Note:'No tasks for this week and filters'}]),'Checklist');
  XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(pl.length?pl:[{Note:'No planning for this week'}]),'Planning');
  XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(sum.length?sum:[{Note:'No staff'}]),'Summary');
  await save(`Aldeia-staff-week-${isoWeek(ui.ws)}-${iso(ui.ws)}.xlsx`,new Uint8Array(XLSX.write(wb,{type:'array',bookType:'xlsx'})));
}
async function doReport(){
  const ds=weekDates(ui.ws), {chk,pl}=exportRows(), who=ui.f.staff?nm('staff',ui.f.staff):'All staff';
  const tbl=(head,rows,w)=>`<table><colgroup>${w.map(x=>`<col style="width:${x}%">`).join('')}</colgroup><tr>${head.map(x=>`<th>${x}</th>`).join('')}</tr>${rows.join('')}</table>`;
  const det=x=>[x.Child,x.Grade,x.Curriculum,x.Subject].filter(Boolean).map(esc).join('<br>');
  let body='';
  ds.forEach(d=>{const rs=chk.filter(x=>x.Date===d);if(!rs.length)return;
    body+=`<h2>${fmt(d)}</h2>`+tbl(['Done','Time','Responsibility','Staff','Detail','Comment'],rs.map(x=>`<tr><td class="box">${x.Status==='Done'?'&#9745;':'&#9744;'}</td><td>${esc(x.Time)}</td><td>${esc(x.Responsibility)}<div class="st ${x.Status==='Missed'?'bad':''}">${esc(x.Status)}${x['Signed off']?' · signed off':''}</div></td><td>${esc(x.Staff)}</td><td>${det(x)}</td><td>${esc(x.Comment)}</td></tr>`),[6,13,25,12,24,20])});
  if(pl.length) body+=`<h2>Planning</h2>`+tbl(['Done','Day','Time','Planning','Staff','Detail'],pl.map(x=>`<tr><td class="box">${x.Done==='Yes'?'&#9745;':'&#9744;'}</td><td>${fmt(x.Date)}</td><td>${esc(x.Time)}</td><td>${esc(x.Planning)}</td><td>${esc(x.Staff)}</td><td>${det(x)}</td></tr>`),[6,10,11,24,12,37]);
  const done=chk.filter(x=>x.Status==='Done').length,miss=chk.filter(x=>x.Status==='Missed').length,tot=chk.filter(x=>!x.Status.startsWith('Holiday')&&x.Status!=='On leave').length;
  const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aldeia staff report week ${isoWeek(ui.ws)}</title><style>
body{font-family:-apple-system,"Segoe UI",Arial,sans-serif;color:#333;background:#e8e8e0;margin:0;padding:20px}.w{max-width:680px;margin:auto;background:#fafaf8;padding:24px;border:1px solid #b0b0a8}
h1{font-size:20px;margin:0 0 4px}h2{font-size:14px;text-transform:uppercase;letter-spacing:.05em;margin:22px 0 6px}.m{font-size:12px;color:#666}table{width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed}td,th{overflow-wrap:anywhere}
th{background:#c0c0b8;text-align:left;padding:6px 8px;border-top:1px solid #b0b0a8;border-bottom:1px solid #b0b0a8;border-right:1px solid #b0b0a8}th:last-child{border-right:0}
td{padding:6px 8px;border-bottom:1px solid #d5d5cd;border-right:1px solid #d5d5cd;vertical-align:top;background:#fafaf8}td:last-child{border-right:0}
.box{font-size:16px;text-align:center;width:34px}.st{font-size:11px;color:#666}.st.bad{color:#b23a2e;font-weight:600}.sig{display:flex;gap:30px;margin-top:36px;font-size:12px}.sig div{flex:1;border-top:1px solid #333;padding-top:4px}
.pb{margin:0 0 14px;padding:8px 14px;font:inherit;font-weight:600;background:#3f5f5a;color:#fff;border:0;border-radius:6px;cursor:pointer}
@media print{body{background:#fff;padding:0}.w{border:0;padding:0}.pb{display:none}th{-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style></head><body><div class="w"><button class="pb" onclick="window.print()">Print this report</button>
<h1>Aldeia Staff Report</h1><div class="m">${esc(who)} · Week ${isoWeek(ui.ws)} · ${fmt(ds[0])} – ${fmt(ds[4])} ${parse(ds[0]).getFullYear()}</div>
<div class="m">Done ${done} of ${tot} · Missed ${miss} · Generated ${fmtAt(new Date().toISOString())} · Aldeia Staff Desk v${VERSION}</div>
${body||'<p>No tasks for this week and filters.</p>'}<div class="sig"><div>Staff signature</div><div>Manager signature</div><div>Date</div></div></div></body></html>`;
  await save(`Aldeia-report-${who.replace(/\s+/g,'-')}-week-${isoWeek(ui.ws)}.html`,html);
}
async function doBackup(){
  const data={};COLLS.forEach(c=>data[c]=S[c].map(x=>({...x})));
  const ok=await save(`Aldeia-Staff-Desk-backup-${todayIso()}.json`,JSON.stringify({app:'aldeia-staff-desk',version:VERSION,exported:new Date().toISOString(),settings:S.settings,data}));
  if(ok){logAct('Exported a backup');toast('Backup saved');if(ui.isMgr&&db){const lb=new Date().toISOString();S.settings.lastBackup=lb;db.doc('settings/main').set({...S.settings,lastBackup:lb}).catch(()=>{})}}
}

/* ---------- photos ---------- */
async function compress(file){
  try{const img=await createImageBitmap(file);const sc=Math.min(1,1280/Math.max(img.width,img.height));const c=document.createElement('canvas');
    c.width=Math.round(img.width*sc);c.height=Math.round(img.height*sc);c.getContext('2d').drawImage(img,0,0,c.width,c.height);
    return await new Promise(r=>c.toBlob(b=>r(b||file),'image/jpeg',0.82))}catch(e){return file}
}
async function addPhoto(kind,key,file){
  if(!assets){toast('Photos are not available here.');return}
  toast('Uploading photo…');
  try{const res=await assets.upload(await compress(file)), ph={id:res.id,url:res.url,at:new Date().toISOString(),by:ui.mgr?'manager':ui.me};
    if(kind==='entry'){const [rid,date,sid]=key.split('|'),r=byId('resp',rid);if(!r)return;const id=ekey(r,date,sid);await setEntry(id,rid,date,sid,{photos:[...((entryMap[id]||{}).photos||[]),ph]})}
    else if(['leavereq','incidents','maint'].includes(kind)){const x=byId(kind,key);if(!x)return;const {id,...rest}=x;await put(kind,id,{...rest,photos:[...(x.photos||[]),ph],...(kind==='incidents'?{hist:[...(x.hist||[]),{at:ph.at,by:ph.by,what:'Photo added'}]}:{})})}
    else if(kind==='stu'){const r=byId('stutests',key)||{};await stSave(key,{photos:[...(r.photos||[]),ph]})}
    else{const p=byId('plans',key);if(!p)return;const {id,...rest}=p;await put('plans',id,{...rest,photos:[...(p.photos||[]),ph]})}
    toast('Photo added')}catch(e){toast(e&&e.code==='not_granted'?'Photo uploads need edit access to this page.':'Photo upload failed. Try again with a smaller photo.')}
}

/* ---------- actions ---------- */
const sod=(sid,d)=>sid+'_'+d;
async function signOff(sids,on){
  const dates=selDates();
  for(const sid of sids) for(const d of dates){const k=sod(sid,d);
    if(on){soMap[k]=1;await put('signoffs',k,{staffId:sid,date:d,by:'manager',at:new Date().toISOString()})}else{delete soMap[k];await remove('signoffs',k)}}
  logAct(`${on?'Signed off':'Reopened'} ${sids.length>1?sids.length+' staff':nm('staff',sids[0])} for ${dates.length>1?'week '+isoWeek(ui.ws):fmt(dates[0])}`);
  render();toast(on?'Signed off':'Reopened');
}
const acts={
  tab:b=>{ui.moreOpen=false;ui.tab=b.dataset.t;ui.stChat='';ui.incSec=null;ui.stOpen=null;ui.stCm=null;ui.ibChat='';ui.ibSel=null;if(ui.tab==='leave')markSeen('leave');ui.ps=null;ui.plBatch=null;ui.clash=null;if(ui.tab==='req')lsSet('rqseen_'+meKey(),new Date().toISOString());if(!ui.isMgr&&hasPerm(PERM_OF_TAB[ui.tab]))ui.f.staff='';if(ui.tab==='inbox')ui.ibPrev=lsGet(seenKey('inbox'))||'';ui.fbSel=new Set();ui.addOpen=false;ui.evEdit=null;ui.reassign=null;ui.openDays=new Set();ui.focusDay='';ui.clash=null;ui.clearOpen=false;ui.copyOpen=false;lsSet('tab',ui.tab);ui.confirmDel=null;ui.acct=false;render();window.scrollTo(0,0)},
  theme:()=>{const n=effTheme()==='dark'?'light':'dark';document.documentElement.dataset.theme=n;lsSet('theme',n);renderChrome()},
  who:()=>{if(!signedIn())return;ui.acct=!ui.acct;render();window.scrollTo(0,0)},
  logout:()=>{ui.me='';ui.mgr=false;ui.acct=false;lsSet('me',null);lsSet('mgr',null);ui.f.staff='';render()},
  login:()=>{const who=val('gate-who'),pw=val('gate-pw'),admin=String(S.settings.pw||'1234');
    if(!who){toast('Choose your name first.');return}
    if(who==='__mgr'){if(pw!==admin){toast('That password is not right.');return}ui.mgr=true;ui.me=''}
    else{const s=byId('staff',who);if(!s)return;
      if(pw===String(s.pin||'1234')){ui.me=who;ui.mgr=false}else if(pw===admin){ui.me=who;ui.mgr=true}else{toast('That password is not right.');return}
      lsSet('last',who)}
    lsSet('me',ui.me||null);lsSet('mgr',ui.mgr?'1':null);ui.f.staff=ui.me;ui.tab='home';ui.openDays=new Set();ui.dismissed=false;ui.nudgeHide=false;ui.ws=mondayOf(new Date());ui.day='all';render();
    {const n=overdueCount(),m=ui.mgr?unreadInbox()+unread():unread();toast('Signed in as '+(ui.me?nm('staff',ui.me):'Manager')+(m?` · ${m} new message${m>1?'s':''}`:'')+(n&&ui.me?` · ${n} missed task${n>1?'s':''}`:''))}},
  wk:b=>{ui.ws=addDays(ui.ws,7*Number(b.dataset.n));ui.day='all';ui.openDays=new Set();ui.focusDay='';render()},
  wk0:()=>{ui.ws=mondayOf(new Date());ui.day='all';ui.openDays=new Set();ui.focusDay='';render()},
  today:()=>{ui.ws=mondayOf(new Date());const ds=weekDates(ui.ws),t=todayIso();ui.day=ds.includes(t)?t:ds[0];ui.openDays=new Set(['c'+ui.day,'p'+ui.day]);render()},
  tickall:async b=>{const d=b.dataset.d,k='tickall'+d;if(ui.confirmDel!==k){ui.confirmDel=k;render();return}ui.confirmDel=null;
    const its=itemsFor([d]).filter(i=>i.st!=='done'&&i.st!=='off'&&!(signed(i.sid,d)&&!ui.mgr)),at=new Date().toISOString();
    for(const i of its){const id=ekey(i.r,d,i.sid),data={...(entryMap[id]||{}),rid:i.r.id,date:d,sid:i.sid,done:true,by:ui.me||'manager',at};delete data.id;entryMap[id]={...data,id};put('entries',id,data);syncPlans(i.r.id,d,i.sid,true)}
    render();toast(`Ticked ${its.length} task${its.length===1?'':'s'}`)},
  clearopen:()=>{ui.clearOpen=true;ui.copyOpen=false;render();document.getElementById('tf-clrpw')?.focus()},
  clearcancel:()=>{ui.clearOpen=false;render()},
  clearplans:async()=>{if(clearPast()){toast("Past weeks can't be cleared.");return}
    const pw=val('tf-clrpw'),admin=String(S.settings.pw||'1234'),mine=ui.me?String((byId('staff',ui.me)||{}).pin||'1234'):null;
    if(!(pw===admin||(mine&&pw===mine))){toast('That password is not right.');return}
    const d=focusDay(),t=clearTargets();for(const p of t)await remove('plans',p.id);
    logAct(`Cleared ${t.length} plans on ${fmt(d)}`);ui.clearOpen=false;ui.clear.add('tf-clrpw');render();toast(`Cleared ${t.length} plan${t.length===1?'':'s'} on ${fmt(d)}`)},
  copyday:()=>{ui.copyOpen=!ui.copyOpen;ui.clearOpen=false;render()},
  copydaygo:async()=>{const from=val('tf-cfrom'),to=val('tf-cto'),who=ui.mgr?(ui.f.staff||null):ui.me;
    if(!from||!to){toast('Pick both days.');return} if(from===to){toast('Pick two different days.');return}
    const src=S.plans.filter(p=>p.date===from&&(!who||p.staffId===who));
    if(!src.length){toast(`No planning on ${fmt(from)} to copy.`);return}
    let n=0;for(const p of src){if(S.plans.some(q=>q.date===to&&q.staffId===p.staffId&&q.text===p.text))continue;const {id,photos,...rest}=p;
      if(await put('plans',newId(),{...rest,date:to,done:false,photos:[],copiedFrom:id,updated:new Date().toISOString()}))n++}
    ui.copyOpen=false;ui.openDays.add('p'+to);render();toast(n?`Copied ${n} plan${n>1?'s':''} to ${fmt(to)}`:`${fmt(to)} already has these plans.`)},
  day:b=>{ui.fltOpen=false;ui.day=b.dataset.d;ui.openDays=new Set();if(ui.day!=='all'){ui.openDays.add('c'+ui.day);ui.openDays.add('p'+ui.day)}render()},
  dtog:b=>{ui.fltOpen=false;const k=b.dataset.k;if(ui.openDays.has(k))ui.openDays.delete(k);else{if(k.startsWith('ib-'))[...ui.openDays].forEach(x=>{if(x.startsWith('ib-'))ui.openDays.delete(x)});if(/^[cp]\d/.test(k))[...ui.openDays].forEach(x=>{if(x[0]===k[0]&&/^[cp]\d/.test(x))ui.openDays.delete(x)});ui.openDays.add(k);if(/^[cp]\d/.test(k))ui.focusDay=k.slice(1)}render()},
  dall:b=>{const p=b.dataset.p,o=b.dataset.o==='1';selDates().forEach(d=>o?ui.openDays.add(p+d):ui.openDays.delete(p+d));render()},
  tscroll:b=>{const t=document.getElementById('tabs');t.scrollBy({left:Number(b.dataset.n)*t.clientWidth*0.7,behavior:'smooth'})},
  savetest:async()=>{const sj=readSubj('tf'),d={title:(byId('topics',sj.topicId)||{}).name||'',topicId:sj.topicId,childId:val('tf-child'),date:val('tf-date'),gradeId:val('tf-grade'),curId:sj.curriculumId,lead:val('tf-lead')||'3',...(PILOT?{time:val('tf-ttime')}:{}),...(PILOTNOTE?{timeEnd:val('tf-tend')}:{}),branchId:ui.mgr?val('tf-branch'):myBranch(),staffId:ui.mgr?val('tf-staff'):'',by:ui.me||'manager'};
    fillFromChild(d,'curId');
    if(!d.topicId&&!(PILOTNOTE&&ui.editing.test)){toast('Choose the subject for the test.');return} if(!d.date){toast('Pick the test date.');return}
    if(PILOTNOTE&&(!d.time||!d.timeEnd)){toast('Choose when the test starts and ends.');return} if(PILOTNOTE&&d.timeEnd<=d.time){toast('The test must end after it starts.');return}
    const eid=PILOTNOTE&&ui.editing.test,old=eid&&byId('tests',eid);if(old){const {id:_i,...o}=old;if(!d.topicId){d.title=o.title||'';d.topicId=o.topicId||''}Object.assign(d,{done:o.done||false,doneBy:o.doneBy||'',doneAt:o.doneAt||'',by:o.by||d.by})}
    if(await put('tests',eid||newId(),d)){logAct(`${eid?'Edited':'Added'} test "${d.title}" on ${fmt(d.date)}`);ui.editing.test=null;ui.clear.add('tf-');ui.testOpen=false;ui.openDays.add('p'+d.date);render();toast('Test saved')}},
  savebreak:async()=>{const d={name:val('tf-bname')||'Break',start:val('tf-bstart'),end:val('tf-bend'),branchId:ui.mgr?val('tf-bbranch'):myBranch(),by:ui.me||'manager'};
    if(!d.start){toast('Pick the start time.');return}
    if(await put('breaks',newId(),d)){logAct(`Added break time ${d.name} ${d.start}`);ui.clear.add('tf-');ui.brkOpen=false;render();toast('Break saved')}},
  clearf:()=>{Object.keys(ui.f).forEach(k=>ui.f[k]='');render()},
  dismiss:()=>{ui.dismissed=true;render()},
  addtog:()=>{if(ui.editing.plan){ui.editing.plan=null;ui.clear.add('pf-');ui.addOpen=false}else ui.addOpen=!ui.addOpen;ui.clash=null;render()},
  reassign:b=>{ui.reassign=ui.reassign===b.dataset.id?null:b.dataset.id;ui.clear.add('tf-ra');render()},
  racancel:()=>{ui.reassign=null;render()},
  rasave:async b=>{const r=byId('resp',b.dataset.id),to=val('tf-ra');if(!r||!to){toast('Choose who it goes to.');return}const {id,...rest}=r;
    if(await put('resp',id,{...rest,staffId:to,updated:new Date().toISOString()})){logAct(`Re-assigned "${r.text}" from ${nm('staff',r.staffId)} to ${nm('staff',to)}`);ui.reassign=null;render();toast('Re-assigned to '+nm('staff',to))}},
  evedit:b=>{ui.evEdit={k:b.dataset.ek,id:b.dataset.eid,d:b.dataset.ed,s:b.dataset.es};ui.clash=null;ui.clear.add('tf-e');render();document.getElementById('evbox')?.scrollIntoView({behavior:'smooth',block:'start'})},
  evcancel:()=>{ui.evEdit=null;ui.clash=null;render()},
  evsave:async()=>{const E=ui.evEdit;if(!E)return;const o=evObj(E);if(!o)return;const {id,...rest}=o,now=new Date().toISOString();
    const day=val('tf-eday')||E.d,start=val('tf-estart'),end=val('tf-eend'),sid=(ui.mgr?val('tf-estaff'):'')||o.staffId;
    if(start&&end&&end<=start){toast('The end time must be after the start time.');return}
    if(E.k==='brk'){if(!start){toast('Pick a start time.');return}
      if(await put('breaks',id,{...rest,start,end})){logAct(`Moved break ${o.name||''} to ${start}`);ui.evEdit=null;render();toast('Break moved')}return}
    const oldS=oStart(o)==='99'?'':oStart(o),timeChanged=start!==oldS||end!==oEnd(o);
    const cid=val('tf-echild'),gid=val('tf-egrade'),kidChanged=cid!==(o.childId||'')||gid!==(o.gradeId||'');
    const tp={...(timeChanged?{start,end,session:'',periodId:''}:{}),childId:cid,gradeId:gid};
    const tSid=sid==='*'?(E.s||'*'):sid;
    if(checkClash('ev',{text:o.text,staffId:sid,start,end},sid==='*'?liveStaff().map(x=>x.id):[sid],[day],id))return;
    let ok=false;
    if(E.k==='plan') ok=await put('plans',id,{...rest,...tp,date:day,staffId:sid,updated:now});
    else if(o.recur==='once') ok=await put('resp',id,{...rest,...tp,date:day,staffId:sid,updated:now});
    else if(document.getElementById('tf-esc-all')?.checked){
      const wd=parse(E.d).getDay(),nd=parse(day).getDay(),days=[...new Set((o.days||[]).filter(x=>x!==wd).concat(nd))].sort();
      ok=await put('resp',id,{...rest,...tp,days,staffId:sid,updated:now});
    }else{
      if(day===E.d&&!timeChanged&&!kidChanged&&sid===o.staffId){ui.evEdit=null;render();return}
      const skipKey=o.staffId==='*'&&E.s?E.d+'|'+E.s:E.d;
      ok=await put('resp',id,{...rest,skip:[...(o.skip||[]),skipKey],updated:now});
      const newStaff=o.staffId==='*'?(sid==='*'?(E.s||'*'):sid):sid;
      if(ok) ok=await put('resp',newId(),{...rest,...tp,recur:'once',days:[],date:day,from:'',skip:[],staffId:newStaff,movedFrom:id,created:now,updated:now});
    }
    if(ok){logAct(`Moved "${o.text}" to ${fmt(day)} ${start||'any time'}${sid!==o.staffId?' for '+nm('staff',sid):''}`);ui.evEdit=null;ui.clash=null;render();toast('Saved')}},
  unlockplan:async b=>{const sid=b.dataset.s,d=b.dataset.d,k=sid+'_'+d;S.plocks=S.plocks.filter(x=>x.id!==k);await remove('plocks',k);
    for(const f of S.feedback.filter(f=>f.kind==='unlock'&&f.scope==='plan'&&f.from===sid&&f.date===d&&!f.closed)){const {id,...rest}=f;await put('feedback',id,{...rest,closed:true})}
    logAct(`Unlocked planning on ${fmt(d)} for ${nm('staff',sid)}`);render();toast('Planning unlocked')},
  requnlock:async b=>{const d=b.dataset.d,sc=b.dataset.scope||'';if(await put('feedback',newId(),{to:'manager',from:ui.me,kind:'unlock',scope:sc,date:d,text:sc==='week'?`Please unlock my week ${isoWeek(parse(d))} planning so I can change it.`:sc==='plan'?`Please unlock my planning for ${fmt(d)}.`:`Please unlock ${fmt(d)} so I can update my ticks.`,at:new Date().toISOString()})){render();toast('Unlock request sent to your manager')}},
  unlockday:async b=>{const sid=b.dataset.s,d=b.dataset.d,k=sid+'_'+d;delete soMap[k];await remove('signoffs',k);
    for(const f of S.feedback.filter(f=>f.kind==='unlock'&&f.scope!=='plan'&&f.from===sid&&f.date===d&&!f.closed)){const {id,...rest}=f;await put('feedback',id,{...rest,closed:true})}
    logAct(`Unlocked ${fmt(d)} for ${nm('staff',sid)}`);render();toast('Day unlocked')},
  fbapprove:async b=>{const f=byId('feedback',b.dataset.id);if(!f)return;const {id,...rest}=f;
    if(await put('feedback',id,{...rest,approvedFor:{...(f.approvedFor||{}),[b.dataset.s]:new Date().toISOString()}})){logAct(`Approved feedback completed by ${nm('staff',b.dataset.s)}`);toast('Approved')}},
  fbreopen:async b=>{const f=byId('feedback',b.dataset.id);if(!f)return;const {id,...rest}=f,d_={...(f.doneBy||{})};delete d_[b.dataset.s];
    if(await put('feedback',id,{...rest,doneBy:d_})){toast('Sent back as not completed')}},
  resetgo:async()=>{const picks=RESET_ALL.filter(([c])=>{const el=document.getElementById('sf-rs-'+c);return el&&el.checked&&!el.disabled}).map(([c])=>c);
    if(!picks.length){toast('Tick what you want to reset.');return}
    if(val('sf-rs-pw')!==String(S.settings.pw||'1234')){toast('Enter the admin password to reset.');return}
    const n=picks.reduce((a,c)=>a+rsRows(c).length,0);
    if(ui.confirmDel!=='reset'){ui.confirmDel='reset';ui.resetN=n;render();return}ui.confirmDel=null;
    toast(`Deleting ${n} records…`);for(const c of picks)for(const x of [...rsRows(c)])await remove(c,x.id);
    if(picks.includes('signoffs'))soMap={};
    logAct(`Reset ${picks.map(c=>RESET_ALL.find(x=>x[0]===c)[1]).join(', ')}${ui.rsWho?' for '+nm('staff',ui.rsWho):' for all staff'} (${n} records)`);ui.clear.add('sf-rs-');render();toast(`Reset done · ${n} records deleted`)},
  logxl:async()=>{if(typeof XLSX==='undefined'){toast('Excel export could not load. Check your connection.');return}
    const rows=[...S.log].sort((a,b)=>(b.at||'').localeCompare(a.at||'')).map(l=>({Date:(l.at||'').slice(0,10),Time:(l.at?new Date(l.at):null)?pad(new Date(l.at).getHours())+':'+pad(new Date(l.at).getMinutes()):'',Who:l.who||'',Change:l.what||''}));
    const wb=XLSX.utils.book_new(),ws=XLSX.utils.json_to_sheet(rows.length?rows:[{Note:'No changes recorded yet'}]);ws['!cols']=[{wch:11},{wch:7},{wch:22},{wch:70}];
    XLSX.utils.book_append_sheet(wb,ws,'Change log');await save(`Aldeia-change-log-${todayIso()}.xlsx`,new Uint8Array(XLSX.write(wb,{type:'array',bookType:'xlsx'})))},
  fbselclear:()=>{ui.fbSel=new Set();render()},
  fbdel:async()=>{const pw=val('fb-delpw'),admin=String(S.settings.pw||'1234'),mine=ui.me?String((byId('staff',ui.me)||{}).pin||'1234'):null;
    if(!(pw===admin||(mine&&pw===mine))){toast('That PIN is not right.');return}
    const ids=[...ui.fbSel].filter(id=>{const f=byId('feedback',id);return f&&!f.deleted&&isMine(f)});const at=new Date().toISOString();
    for(const id of ids){const {id:_i,...rest}=byId('feedback',id);await put('feedback',id,{...rest,deleted:true,deletedAt:at,deletedBy:ui.mgr?'manager':ui.me})}
    logAct(`Deleted ${ids.length} feedback message${ids.length===1?'':'s'}`);ui.fbSel=new Set();ui.clear.add('fb-delpw');render();toast(`Deleted ${ids.length} message${ids.length===1?'':'s'}`)},
  clashlist:()=>{ui.clashOpen=!ui.clashOpen;render()},
  ydaytog:()=>{ui.ydayClosed=!ui.ydayClosed;render()},
  photoview:b=>openPhoto(b.dataset.src),
  photopick:b=>pickPhoto(b.dataset.kind,b.dataset.k),
  photoclose:()=>{const lb=document.getElementById('lightbox');if(lb)lb.hidden=true},
  photosave:async b=>{try{const r=await fetch(b.dataset.src);if(!r.ok)throw 0;const bl=await r.blob();const ext=(bl.type.split('/')[1]||'jpg').replace('jpeg','jpg');await save(`Aldeia-photo-${todayIso()}.${['jpg','png','webp','gif'].includes(ext)?ext:'jpg'}`,bl)}catch(e){toast('Could not save this photo.')}},
  saveperms:async()=>{const st=byId('staff',ui.roleStaff);if(!st)return;const perms=PERMS.filter(([k])=>document.getElementById('sf-pm-'+k)?.checked).map(([k])=>k);const {id,...rest}=st;
    if(await put('staff',id,{...rest,perms})){logAct(`Set access for ${staffLabel(st)}: ${perms.join(', ')||'none'}`);ui.clear.add('sf-pm-');render();toast('Access saved for '+staffLabel(st))}},
  roleedit:b=>{ui.roleStaff=b.dataset.s;ui.clear.add('sf-pm-');render()},
  viewas:b=>{const sid=b.dataset.s;if(!byId('staff',sid))return;ui.viewing={me:ui.me,isMgr:ui.isMgr,tab:ui.tab,fstaff:ui.f.staff};ui.me=sid;ui.isMgr=false;ui.f.staff=sid;ui.tab='home';ui.openDays=new Set();ui.ydayDone=true;render();window.scrollTo(0,0);toast('Viewing as '+nm('staff',sid))},
  viewexit:()=>{const v=ui.viewing;if(!v)return;ui.me=v.me;ui.isMgr=v.isMgr;ui.f.staff=v.fstaff;ui.tab=v.tab;ui.viewing=null;ui.openDays=new Set();render();window.scrollTo(0,0)},
  pwreset:async b=>{try{await window.fbAuth.sendPasswordResetEmail(b.dataset.e);toast('Password reset email sent to '+b.dataset.e,4000);logAct('Sent password reset to '+b.dataset.e)}catch(e){toast('Could not send the reset email.')}},
  pwresetall:async()=>{if(ui.confirmDel!=='pwall'){ui.confirmDel='pwall';render();return}ui.confirmDel=null;const ems=liveStaff().map(x=>(x.email||'').trim()).filter(Boolean);let n=0;
    for(const e of ems){try{await window.fbAuth.sendPasswordResetEmail(e);n++}catch(x){}}logAct(`Sent password reset to ${n} staff`);render();toast(`Password reset email sent to ${n} staff`,4000)},
  medview:b=>{const c=byId('children',b.dataset.id);if(c)toast(`${c.name}: ${c.medical}`,7000)},
  att:async b=>{const d=b.dataset.d,cid=b.dataset.c,v=b.dataset.v==='1',id=d+'_'+cid,cur=byId('attendance',id);
    if(cur&&!!cur.present===v){S.attendance=S.attendance.filter(x=>x.id!==id);render();await remove('attendance',id);return}
    const data={date:d,childId:cid,present:v,by:ui.me||'manager',at:new Date().toISOString()};S.attendance=[...S.attendance.filter(x=>x.id!==id),{id,...data}];render();await put('attendance',id,data)},
  attall:async b=>{const d=b.dataset.d;for(const c of regKids()){const id=d+'_'+c.id;if(byId('attendance',id))continue;const data={date:d,childId:c.id,present:true,by:ui.me||'manager',at:new Date().toISOString()};S.attendance.push({id,...data});put('attendance',id,data)}render();toast('Everyone not yet marked is now present')},
  ttprint:()=>printTimetable(),
  onlinexl:()=>onlineExcel(),
  ydayack:b=>{lsSet('ydayack_'+meKey(),todayIso());const m=document.getElementById('ydm');if(m)m.remove();if(b.dataset.go==='1'){ui.tab='check';ui.ws=mondayOf(new Date());ui.day='all';ui.ydayClosed=false;render();window.scrollTo(0,0)}},
  absprint:()=>absPrint(), absxl:()=>absExcel(), psprint:()=>parentSummary(false), pscopy:()=>parentSummary(true), mrprint:()=>monthlyReport(), qrshow:b=>qrShow(b.dataset.id),
  install:async()=>{const p=window.__installPrompt;if(!p)return;p.prompt();try{await p.userChoice}catch(e){}window.__installPrompt=null;render()},
  moretog:()=>{ui.moreOpen=!ui.moreOpen;renderChrome()},
  hday:b=>{let d=parse(homeDay());do{d=addDays(d,Number(b.dataset.n))}while(d.getDay()===0||d.getDay()===6);ui.homeDay=iso(d);ui.homeOpen=null;render()},
  htoday:()=>{ui.homeDay=null;ui.homeOpen=null;render()},
  hopen:b=>{const k=b.dataset.k;ui.homeOpen=ui.homeOpenEff===k?'__none':k;render()},
  hdone:b=>{const [rid,date,sid]=b.dataset.k.split('|'),r=byId('resp',rid);if(!r)return;const id=ekey(r,date,sid),cur=!!(entryMap[id]||{}).done;setEntry(id,rid,date,sid,{done:!cur});if(!cur){ui.homeOpen=null;toast('Done')}if(PILOTNOTE)render()},
  hpdone:b=>{const p=byId('plans',b.dataset.id);if(!p)return;const {id,...rest}=p,v=!p.done;p.done=v;put('plans',id,{...rest,done:v});if(v){checkPlanDone(p.staffId,p.date);ui.homeOpen=null;toast('Done')}render()},
  pcopen:b=>{ui.openC.add('p:'+b.dataset.id);render();document.getElementById('pc-'+b.dataset.id)?.focus()},
  pcclose:b=>{ui.openC.delete('p:'+b.dataset.id);render()},
  pcsave:async b=>{const p=byId('plans',b.dataset.id);if(!p)return;const t=val('pc-'+b.dataset.id),{id,...rest}=p;ui.openC.delete('p:'+id);p.comment=t;await put('plans',id,{...rest,comment:t});
    if(!ui.mgr&&t)put('feedback','pc_'+id,{to:'manager',from:ui.me,text:`${p.text} (${fmt(p.date)}): ${t}`,at:new Date().toISOString(),ref:'plan:'+id});render();toast('Comment saved')},
  hmissed:()=>{ui.tab='check';ui.ws=mondayOf(new Date());ui.day='all';ui.ydayClosed=false;render();window.scrollTo(0,0)},
  annpost:async()=>{const t=val('tf-an-title'),x=val('tf-an-text');if(!t){toast('Give the announcement a title.');return}
    if(await put('announce',newId(),{title:t,text:x,branchId:val('tf-an-br'),at:new Date().toISOString(),by:ui.me||'manager',reads:{}})){logAct('Posted announcement: '+t);ui.clear.add('tf-an');render();toast('Announcement posted')}},
  annread:async b=>{const a=byId('announce',b.dataset.id);if(!a||!ui.me)return;const {id,...rest}=a;a.reads={...(a.reads||{}),[ui.me]:new Date().toISOString()};render();await put('announce',id,{...rest,reads:a.reads});toast('Marked as read')},
  reqsave:async()=>{const item=val('tf-rq-item');if(!item){toast('Type what you need.');return}
    const d={item,qty:val('tf-rq-qty')||'1',needBy:val('tf-rq-by'),note:val('tf-rq-note'),branchId:myBranch()||ui.f.branch||'',by:ui.me||'manager',at:new Date().toISOString(),status:'requested'};
    if(await put('requests',newId(),d)){ui.clear.add('tf-rq');render();toast('Request sent to your manager')}},
  reqset:async b=>{const r=byId('requests',b.dataset.id);if(!r)return;const {id,...rest}=r,st=b.dataset.s;r.status=st;render();
    await put('requests',id,{...rest,status:st,statusAt:new Date().toISOString(),statusBy:'manager'});logAct(`Resource request "${r.item}" set to ${st}`);toast('Marked '+st)},
  ctsave:async()=>{const cid=ui.kid,sum=val('tf-ct-sum');if(!cid)return;if(!sum){toast('Write a short summary of the contact.');return}
    const d={childId:cid,date:val('tf-ct-date')||todayIso(),type:val('tf-ct-type')||'Call',with:val('tf-ct-with'),summary:sum,followUp:val('tf-ct-fu'),fuDone:false,by:ui.me||'manager',at:new Date().toISOString()};
    if(await put('contacts',newId(),d)){if(!ui.isMgr&&ui.me)put('feedback',newId(),{to:'manager',from:ui.me,kind:'contact',text:`Parent contact logged · ${nm('children',cid)} · ${d.type}${d.with?' with '+d.with:''}: ${sum}${d.followUp?' (follow up '+fmt(d.followUp)+')':''}`,at:d.at});ui.clear.add('tf-ct');render();toast('Contact logged'+(ui.isMgr?'':' · your manager has been told'))}},
  ctdone:async b=>{const c=byId('contacts',b.dataset.id);if(!c)return;const {id,...rest}=c;c.fuDone=true;render();await put('contacts',id,{...rest,fuDone:true,fuDoneAt:new Date().toISOString()});toast('Follow-up done')},
  plday:b=>{ui.plDay=b.dataset.d;render()},
  pltoday:b=>{acts.today(b);ui.plDay=todayIso();render()},
  plwho:b=>{ui.plWho=b.dataset.v;render()},
  psopen:b=>{psInit(b.dataset.d||plDaySel(),b.dataset.slot||'');render()},
  psclose:()=>{ui.ps=null;ui.clash=null;render()},
  psday:b=>{psGrab();ui.ps.date=b.dataset.v;ui.clash=null;render()},
  psslot:b=>{psGrab();const s=ui.ps,v=b.dataset.v;s.slot=s.slot===v?'':v;const p=byId('periods',v);if(p){s.start=p.start||'';s.end=p.end||''}ui.clash=null;render()},
  pswho:b=>{psGrab();const s=ui.ps;s.who=s.who===b.dataset.v?'':b.dataset.v;if(s.who)s.kids=[];render()},
  pskid:b=>{psGrab();const s=ui.ps,cur=psKids(),id=b.dataset.v;s.who='';s.kids=cur.includes(id)?cur.filter(x=>x!==id):[...cur,id];render()},
  pstopic:b=>{psGrab();const s=ui.ps,t=byId('topics',b.dataset.v);if(!t||s.topicId===t.id){s.topicId='';s.curriculumId=''}else{s.topicId=t.id;s.curriculumId=t.subjectId||''}render()},
  pstext:b=>{psGrab();ui.ps.text=b.dataset.v;const el=document.getElementById('tf-ps-text');if(el)el.value=b.dataset.v;render()},
  psgroup:async()=>{psGrab();const s=ui.ps,name=(s.gname||'').trim();if(!name){toast('Type a name for the group.');return}
    const kids=psKids(),id=newId(),g={name,branchId:plBranch(),childIds:kids};
    if(await put('groups',id,g)){if(!byId('groups',id))S.groups.push({id,...g});s.who='g:'+id;s.kids=[];s.gname='';ui.clear.add('tf-ps-gname');logAct('Created group '+name);render();toast('Group "'+name+'" saved')}},
  pssave:async()=>{psGrab();const s=ui.ps;if(!s)return;const staffId=ui.isMgr?s.staff:ui.me;
    if(!staffId){toast('Choose the staff member.');return}
    if(!s.slot){toast('Choose a time slot.');return}
    if(s.slot==='own'&&!s.start){toast('Choose the start time.');return}
    const kids=psKids();if(!kids.length){toast('Choose who it is for.');return}
    if(!s.text&&!s.topicId){toast('Choose or type the activity.');return}
    const per=s.slot!=='own'?byId('periods',s.slot):null;
    const d={staffId,date:s.date,session:'',periodId:per?per.id:'',start:per?per.start||'':s.start,end:per?per.end||'':s.end,text:(s.text||'').trim()||tName(s.topicId),
      childIds:kids,childId:kids.length===1?kids[0]:'',groupId:s.who.startsWith('g:')?s.who.slice(2):'',wholeClass:s.who==='class',gradeId:'',curriculumId:s.curriculumId,topicId:s.topicId,
      done:false,photos:[],by:ui.me||'manager',updated:new Date().toISOString()};
    if(PILOTNOTE&&s.isTest&&(!d.start||!d.end)){toast('A test needs a start and an end time.');return}
    if(checkClash('ps',d,[staffId],[d.date]))return;
    const pid=newId();if(s.rep)d.series=pid;
    if(await put('plans',pid,d)){if(s.isTest)await put('tests',newId(),{title:tName(d.topicId)||d.text,topicId:d.topicId,childId:kids.length===1?kids[0]:'',date:d.date,time:d.start||'',timeEnd:d.end||'',gradeId:'',curId:d.curriculumId||'',lead:'3',branchId:ui.isMgr?plBranch():myBranch(),staffId,by:ui.me||'manager'});let n=0;if(s.rep){const until=repUntilDefault();for(let k=1;k<=52;k++){const nd=iso(addDays(parse(d.date),7*k));if(nd>until)break;await put('plans',newId(),{...d,date:nd});n++}}
      ui.ps=null;ui.clash=null;ui.plDay=d.date;ui.clear.add('tf-ps-');render();toast(n?`Saved and repeated for ${n} more week${n===1?'':'s'}`:'Activity saved')}},
  pbopen:b=>{ui.plBatch=b.dataset.d;ui.pb={src:'last'};ui.ps=null;ui.clear.add('tf-pb-');render();window.scrollTo(0,0)},
  pbclose:()=>{ui.plBatch=null;ui.ps=null;render()},
  pbsrc:b=>{ui.pb.src=b.dataset.v;ui.clear.add('tf-pb-');render()},
  pbsave:async()=>{const d=ui.plBatch,b=ui.pb;if(!d||!b)return;const ids=b.rows||[],rep=!!document.getElementById('tf-pb-rep')?.checked,until=repUntilDefault(),kids=classKids();let n=0,sk=0;
    for(let i=0;i<ids.length;i++){if(!document.getElementById('tf-pb-c-'+i)?.checked)continue;const p=byId('plans',ids[i]);if(!p)continue;const w=val('tf-pb-w-'+i);
      const {id,photos,done,series,...rest}=p;const nd={...rest,date:d,done:false,photos:[],copiedFrom:id,updated:new Date().toISOString()};
      if(w==='class'){nd.wholeClass=true;nd.groupId='';nd.childIds=kids.map(c=>c.id)}
      else if(w.startsWith('g:')){nd.wholeClass=false;nd.groupId=w.slice(2);nd.childIds=grpKids(nd.groupId)}
      else if(w.startsWith('c:')){nd.wholeClass=false;nd.groupId='';nd.childIds=[w.slice(2)]}
      nd.childId=(nd.childIds||[]).length===1?nd.childIds[0]:(nd.childIds&&nd.childIds.length?'':(nd.childId||''));
      if(S.plans.some(q=>q.date===d&&q.staffId===nd.staffId&&q.text===nd.text&&oStart(q)===oStart(nd))){sk++;continue}
      const pid=newId();if(rep)nd.series=pid;
      if(await put('plans',pid,nd)){n++;if(rep)for(let k=1;k<=52;k++){const dd=iso(addDays(parse(d),7*k));if(dd>until)break;await put('plans',newId(),{...nd,date:dd})}}}
    if(n)logAct(`Planned ${n} activities for ${fmt(d)} in one go`);
    ui.plBatch=null;ui.plDay=d;ui.clear.add('tf-pb-');render();toast(n?`${n} activit${n>1?'ies':'y'} saved for ${fmt(d)}${sk?` · ${sk} already there`:''}`:(sk?'Those are already planned.':'Nothing ticked to save.'))},
  ibtab:b=>{ui.ibTab=b.dataset.v;render()},
  ibfilt:b=>{ui.ibFilt=b.dataset.v;render()},
  ibopen:b=>{ui.ibChat=b.dataset.s;ui.ibSel=null;ui.confirmDel=null;render();window.scrollTo(0,document.body.scrollHeight)},
  ibback:()=>{ui.ibChat='';ui.ibSel=null;ui.confirmDel=null;render()},
  ibsend:async b=>{const sid=b.dataset.s,text=val('tf-ibc');if(!text){toast('Type a message first.');return}
    if(await put('feedback',newId(),{to:sid,text,from:'manager',at:new Date().toISOString()})){logAct('Sent message to '+nm('staff',sid));ui.clear.add('tf-ibc');lsSet(ibSeenK(sid),new Date().toISOString());render();window.scrollTo(0,document.body.scrollHeight)}},
  pltest:b=>{ui.tab='plan';ui.ws=mondayOf(parse(b.dataset.d));ui.plDay=b.dataset.d;render();window.scrollTo(0,0)},
  plnext:()=>{ui.tab='plan';ui.ws=addDays(mondayOf(new Date()),7);ui.plDay='';render();window.scrollTo(0,0)},
  plweek:b=>{ui.tab='plan';ui.ws=parse(b.dataset.ws);ui.plDay='';render();window.scrollTo(0,0)},
  ibgo:b=>{ui.tab='inbox';ui.ibTab=b.dataset.v;ui.ibChat='';render();window.scrollTo(0,0)},
  ibplan:b=>{ui.tab='plan';ui.f.staff=b.dataset.s;ui.ws=parse(b.dataset.ws);ui.plDay='';render();window.scrollTo(0,0)},
  papsend:async()=>{const sid=ui.me,ws=iso(ui.ws);if(!sid)return;const id=papId(sid,ws),d={staffId:sid,ws,status:'submitted',at:new Date().toISOString(),note:''};
    S.papprove=[...S.papprove.filter(x=>x.id!==id),{id,...d}];render();if(await put('papprove',id,d)){logAct(`Submitted week ${isoWeek(ui.ws)} planning for approval`);toast('Sent to your manager for approval')}},
  papok:async b=>{const r=byId('papprove',b.dataset.id);if(!r)return;const {id,...rest}=r;r.status='approved';r.decidedAt=new Date().toISOString();render();
    await put('papprove',id,{...rest,status:'approved',decidedAt:r.decidedAt});logAct(`Approved week ${isoWeek(parse(r.ws))} planning for ${nm('staff',r.staffId)}`);toast('Planning approved')},
  papchg:async b=>{const r=byId('papprove',b.dataset.id);if(!r)return;const note=val('tf-pch-'+r.id);if(!note){toast('Type what should change.');return}const {id,...rest}=r,at=new Date().toISOString();
    r.status='changes';r.note=note;r.decidedAt=at;render();await put('papprove',id,{...rest,status:'changes',note,decidedAt:at});
    await put('feedback',newId(),{to:r.staffId,from:'manager',text:`Changes needed to week ${isoWeek(parse(r.ws))} planning: ${note}`,at});logAct(`Asked ${nm('staff',r.staffId)} for planning changes`);toast('Sent back with your note')},
  moodset:async b=>{const d=b.dataset.d,c=b.dataset.c,v=Number(b.dataset.v),id=d+'_'+c,cur=byId('mood',id);
    if(cur&&cur.mood===v){S.mood=S.mood.filter(x=>x.id!==id);render();await remove('mood',id);return}
    const data={date:d,childId:c,mood:v,by:ui.me||'manager',at:new Date().toISOString()};S.mood=[...S.mood.filter(x=>x.id!==id),{id,...data}];render();await put('mood',id,data)},
  lvsend:async()=>{const type=val('tf-lv-type')||LV_TYPES[0],from=val('tf-lv-from'),to=val('tf-lv-to')||from,note=val('tf-lv-note');
    if(!from){toast('Choose the first day.');return}if(to<from){toast('The last day is before the first day.');return}
    const at=new Date().toISOString();if(await put('leavereq',newId(),{staffId:ui.me,type,from,to,note,status:'pending',at,photos:[]})){put('feedback',newId(),{to:'manager',from:ui.me,kind:'leave',text:`${type} · ${fmt(from)}${to!==from?' – '+fmt(to):''} (${workDays(from,to)} work day${workDays(from,to)===1?'':'s'})${note?' · '+note:''}`,at});ui.clear.add('tf-lv-');render();toast('Leave request sent to your manager')}},
  lvok:async b=>{const r=byId('leavereq',b.dataset.id);if(!r)return;const cov=val('tf-lv-cov-'+r.id),mn=val('tf-lv-mn-'+r.id),at=new Date().toISOString(),{id,...rest}=r;
    await put('leave','lr_'+id,{staffId:r.staffId,from:r.from,to:r.to||r.from,note:r.type+(r.note?': '+r.note:''),coverId:cov});
    if(await put('leavereq',id,{...rest,status:'approved',decidedAt:at,coverId:cov,mgrNote:mn})){put('feedback',newId(),{to:r.staffId,from:'manager',text:`Your ${r.type.toLowerCase()} (${fmt(r.from)}${r.to&&r.to!==r.from?' – '+fmt(r.to):''}) is approved.${cov?' '+nm('staff',cov)+' will cover.':''}${mn?' '+mn:''}`,at});logAct(`Approved ${r.type.toLowerCase()} for ${nm('staff',r.staffId)} (${fmt(r.from)})`);toast('Leave approved'+(cov?' · '+nm('staff',cov)+' covers':''))}},
  lvno:async b=>{const r=byId('leavereq',b.dataset.id);if(!r)return;const mn=val('tf-lv-mn-'+r.id),{id,...rest}=r;
    if(await put('leavereq',id,{...rest,status:'declined',decidedAt:new Date().toISOString(),mgrNote:mn})){put('feedback',newId(),{to:r.staffId,from:'manager',text:`Your ${r.type.toLowerCase()} (${fmt(r.from)}${r.to&&r.to!==r.from?' – '+fmt(r.to):''}) was declined.${mn?' '+mn:''}`,at:new Date().toISOString()});logAct(`Declined leave for ${nm('staff',r.staffId)}`);toast('Leave declined')}},
  insave:async()=>{const childId=val('tf-in-child'),what=val('tf-in-what');if(!childId){toast('Choose the child.');return}if(!what){toast('Describe what happened.');return}
    const par=val('tf-in-par'),at=new Date().toISOString();
    if(await put('incidents',newId(),{childId,date:val('tf-in-date')||todayIso(),time:val('tf-in-time'),where:val('tf-in-where'),what,injury:val('tf-in-inj')||INJ[0],aid:val('tf-in-aid'),parent:par,parentAt:par?at:'',witness:val('tf-in-wit'),by:ui.me||'manager',at,status:'open',photos:[],hist:[{at,by:ui.me||'manager',what:'Report created'+(par?' · parent informed ('+par+')':'')}]})){logAct('Incident report for '+nm('children',childId));ui.clear.add('tf-in-');render();toast('Incident report saved'+(par?'':' · remember to tell the parent'))}},
  inpar:async b=>{const x=byId('incidents',b.dataset.id);if(!x)return;const {id,...rest}=x;const how=val('tf-in-p-'+id)||'Phone call';await put('incidents',id,{...rest,parent:how,parentAt:new Date().toISOString(),hist:incHist(x,'Parent informed · '+how)});toast('Marked: parent informed')},
  inclose:async b=>{const x=byId('incidents',b.dataset.id);if(!x)return;const {id,...rest}=x;const mn=val('tf-in-mn-'+id);await put('incidents',id,{...rest,status:'closed',mgrNote:mn,closedAt:new Date().toISOString(),hist:incHist(x,'Reviewed by manager'+(mn?' · '+mn:''))});logAct('Reviewed incident report for '+nm('children',x.childId));toast('Marked as reviewed')},
  inprint:b=>incPrint(b.dataset.id),
  mtsave:async()=>{const item=val('tf-mt-item');if(!item){toast('Type what needs fixing.');return}
    if(await put('maint',newId(),{branchId:ui.isMgr?(ui.f.branch||''):myBranch(),item,where:val('tf-mt-where'),priority:val('tf-mt-pri')||'Normal',status:'reported',by:ui.me||'manager',at:new Date().toISOString(),photos:[]})){ui.clear.add('tf-mt-');render();toast('Reported')}},
  mtset:async b=>{const x=byId('maint',b.dataset.id);if(!x)return;const {id,...rest}=x,st=b.dataset.s;await put('maint',id,{...rest,status:st,...(st==='fixed'?{fixedAt:new Date().toISOString()}:{})});logAct(`Maintenance "${x.item}" marked ${st}`);toast(st==='fixed'?'Marked as fixed':'Marked as busy')},
  ntfon:()=>{if(!('Notification' in window))return;Notification.requestPermission().then(p=>{lsSet('ntfask','1');toast(p==='granted'?'Notifications are on for this phone':'Notifications are blocked. You can allow them in your browser settings.');render()})},
  ntfno:()=>{lsSet('ntfask','1');render()},
  pswa:()=>parentSummary('wa'),
  ibselon:()=>{ui.ibSel=new Set();render()},
  ibselx:()=>{ui.ibSel=null;ui.confirmDel=null;render()},
  ibsel:b=>{const k=b.dataset.k;if(!ui.ibSel)return;ui.ibSel.has(k)?ui.ibSel.delete(k):ui.ibSel.add(k);ui.confirmDel=null;render()},
  ibseldel:async b=>{const sid=b.dataset.s;if(!ui.ibSel||!ui.ibSel.size)return;if(ui.confirmDel!=='ibsel'+sid){ui.confirmDel='ibsel'+sid;render();return}
    const cur=ibHidden(sid),d={clearedAt:cur.clearedAt||'',hidden:[...new Set([...(cur.hidden||[]),...ui.ibSel])]},n=ui.ibSel.size;
    S.ibhide=[...S.ibhide.filter(x=>x.id!==sid),{id:sid,...d}];ui.ibSel=null;ui.confirmDel=null;render();await put('ibhide',sid,d);logAct(`Deleted ${n} message${n>1?'s':''} from the chat with ${nm('staff',sid)}`);toast(`${n} message${n>1?'s':''} deleted`)},
  ibclear:async b=>{const sid=b.dataset.s;if(ui.confirmDel!=='ibchat'+sid){ui.confirmDel='ibchat'+sid;render();return}
    const all=ibEvents(sid),lastAt=all.reduce((m,e)=>e.at>m?e.at:m,''),nowI=new Date().toISOString(),d={clearedAt:lastAt>nowI?lastAt:nowI,hidden:[]};S.ibhide=[...S.ibhide.filter(x=>x.id!==sid),{id:sid,...d}];ui.confirmDel=null;ui.ibChat='';render();await put('ibhide',sid,d);logAct('Deleted the chat with '+nm('staff',sid));toast('Chat deleted')},
  ntcread:b=>{const k=b.dataset.nk,r=ntcRead();if(!r.includes(k)){r.push(k);lsSet('ntcread_'+meKey(),JSON.stringify(r.slice(-300)))}render();ntcModalFill()},
  ntcunread:(b,e)=>{e&&e.stopPropagation();const k=b.dataset.nk;ntcSave(ntcRead().filter(x=>x!==k));render();ntcModalFill()},
  ntcsnzx:(b,e)=>{e&&e.stopPropagation();const sz=ntcSnz();delete sz[b.dataset.nk];lsSet('ntcsnz_'+meKey(),JSON.stringify(sz));render();ntcModalFill()},
  ntmclose:b=>{lsSet('ntcpop_'+meKey(),todayIso());if(b.dataset.all){const r=ntcRead();noticeItems().forEach(x=>{if(!r.includes(x.k))r.push(x.k)});ntcSave(r)}document.getElementById('ntm')?.remove();ui.homeOpen='__none';render();setTimeout(ydayModal,0)},
  stopen:b=>{ui.stChat=b.dataset.s;render();window.scrollTo(0,document.body.scrollHeight)},
  stback:()=>{ui.stChat='';render()},
  stnew:()=>{const v=val('tf-stnew');if(!v){toast('Choose who to message.');return}ui.stChat=v;render()},
  stsend:async b=>{const to=b.dataset.s,text=val('tf-stc');if(!text){toast('Type a message first.');return}
    if(await put('feedback',newId(),{to,from:ui.me,text,at:new Date().toISOString()})){ui.clear.add('tf-stc');lsSet(stSeenK(to),new Date().toISOString());render();window.scrollTo(0,document.body.scrollHeight)}},
  ntcall:()=>{const r=ntcRead();noticeItems().forEach(x=>{if(!r.includes(x.k))r.push(x.k)});lsSet('ntcread_'+meKey(),JSON.stringify(r.slice(-300)));render()},
  moodxl:b=>moodXL(b.dataset.c||''),
  phdel:async b=>{const c=b.dataset.c,id=b.dataset.id,i=Number(b.dataset.i),k='ph'+c+id+i;if(ui.confirmDel!==k){ui.confirmDel=k;render();return}ui.confirmDel=null;
    const x=byId(c,id);if(!x){render();return}const {id:_i,...rest}=x,photos=(x.photos||[]).filter((p,j)=>j!==i);x.photos=photos;render();
    if(await put(c,id,{...rest,photos})){logAct('Deleted a photo ('+(c==='plans'?'plan: '+x.text:'task')+')');toast('Photo deleted')}},
  inrange:()=>incRange(),
  rqsec:b=>{ui.rqSec=b.dataset.v;render()},
  rqgo:b=>{ui.tab='req';ui.rqSec=b.dataset.v;ui.moreOpen=false;render();window.scrollTo(0,0)},
  rowmenu:b=>{ui.rowMenu=ui.rowMenu===b.dataset.k?null:b.dataset.k;ui.confirmDel=null;render()},
  rowmore:b=>{(ui.rowFull=ui.rowFull||new Set()).add(b.dataset.k);ui.rowMenu=null;render()},
  rowless:b=>{if(ui.rowFull)ui.rowFull.delete(b.dataset.k);render()},
  chkmore:()=>{ui.chkMore=!ui.chkMore;render()},
  chkflt:()=>{ui.chkFlt=!ui.chkFlt;render()},
  hidenudge:()=>{ui.nudgeHide=true;render()},
  shownudge:()=>{ui.tab='check';ui.ws=mondayOf(new Date());ui.day='all';ui.openDays=new Set(['carry']);render();document.querySelector('[data-k="carry"]')?.scrollIntoView({behavior:'smooth',block:'start'})},
  refresh:()=>{toast('Refreshing…');setTimeout(()=>location.reload(),150)},
  hdayset:b=>{ui.homeDay=b.dataset.d;ui.homeOpen=null;render()},
  respsec:b=>{const v=b.dataset.v,cur=ui.editing.resp?'new':(ui.respSec||'list');if(cur==='new'&&ui.editing.resp){ui.editing.resp=null;ui.clear.add('rf-')}ui.respSec=cur===v?'none':v;ui.rowMenu=null;render()},
  respadd:b=>{ui.editing.resp=null;ui.respSec='new';ui.clear.add('rf-');render();const st=document.getElementById('rf-staff');if(st)st.value=b.dataset.s;[1,2,3,4,5].forEach(n=>{const c=document.getElementById('rf-d'+n);if(c)c.checked=String(n)===b.dataset.n});document.getElementById('respform')?.scrollIntoView({behavior:'smooth',block:'start'})},
  testdone:b=>{const t=byId('tests',b.dataset.id);if(!t)return;const {id,...r}=t,v=!t.done;Object.assign(t,{done:v,doneBy:v?(ui.me||'manager'):'',doneAt:v?new Date().toISOString():''});put('tests',id,{...r,done:v,doneBy:t.doneBy,doneAt:t.doneAt});logAct(`${v?'Marked':'Unmarked'} test "${t.title}" done`);render()},
  edittest:b=>{const t=byId('tests',b.dataset.id);if(!t)return;ui.editing.test=t.id;ui.clear.add('tf-');ui.tab='plan';ui.ws=mondayOf(parse(t.date));ui.plDay=t.date;ui.testOpen=true;render();document.getElementById('testbox')?.scrollIntoView({behavior:'smooth',block:'start'})},
  testcancel:()=>{ui.editing.test=null;ui.clear.add('tf-');ui.testOpen=false;render()},
  regprint:()=>regPrint(),
  planfull:b=>{ui.planFull=b.dataset.v==='1';ui.rowMenu=null;render()},
  unlockweek:async b=>{const sid=b.dataset.s,ws=b.dataset.d,r=byId('papprove',papId(sid,ws));const at=new Date().toISOString();
    if(r){const {id,...rest}=r;r.status='changes';r.note='Unlocked so you can make changes. Submit again when ready.';r.decidedAt=at;await put('papprove',id,{...rest,status:'changes',note:r.note,decidedAt:at})}
    for(const f of S.feedback.filter(f=>f.kind==='unlock'&&f.scope==='week'&&f.from===sid&&f.date===ws&&!f.closed)){const {id,...rest}=f;f.closed=true;await put('feedback',id,{...rest,closed:true})}
    logAct(`Unlocked week ${isoWeek(parse(ws))} planning for ${nm('staff',sid)}`);render();toast('Week unlocked')},
  bdposter:()=>bdPoster(),
  incsec:b=>{ui.incSec=ui.incSec===b.dataset.v?null:b.dataset.v;render()},
  bdmin:b=>{const k='bdmin_'+b.dataset.c+'_'+b.dataset.d+'_'+meKey();lsGet(k)?lsSet(k,''):lsSet(k,'1');render()},
  bdmsg:b=>{ui.bdMsg=ui.bdMsg===b.dataset.c?null:b.dataset.c;render()},
  bdcopy:b=>{const c=byId('children',b.dataset.c);if(!c)return;const t=bdMsg(c);(navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(()=>toast('Message copied'),()=>{const r=document.createRange(),el=document.getElementById('bdm-'+c.id);if(el){r.selectNodeContents(el);const sl=getSelection();sl.removeAllRanges();sl.addRange(r);try{document.execCommand('copy');toast('Message copied')}catch(e){toast('Select the text to copy it')}}})},
  stf:b=>{ui.stF=b.dataset.v;render()},
  stopenk:b=>{ui.stOpen=ui.stOpen===b.dataset.c?null:b.dataset.c;ui.stCm=null;render()},
  stuw:b=>{const t=byId('tests',b.dataset.t),c=byId('children',b.dataset.c);if(!t||!c)return;const s=stState(t,c),now=new Date().toISOString(),me=ui.me||'manager',k=t.id+'_'+c.id;
    if(t.childId||(!s.r.written&&t.done)){acts.testdone({dataset:{id:t.id}});if(s.w)stSave(k,{written:false,hq:false});return}
    stSave(k,s.w?{written:false,wBy:'',wAt:'',hq:false}:{written:true,wBy:me,wAt:now})},
  stuhq:b=>{const t=byId('tests',b.dataset.t),c=byId('children',b.dataset.c);if(!t||!c)return;const s=stState(t,c);if(!s.w){toast('Tick "Test written" first.');return}
    stSave(t.id+'_'+c.id,s.hq?{hq:false,hqBy:'',hqAt:''}:{hq:true,hqBy:ui.me||'manager',hqAt:new Date().toISOString()})},
  stcm:b=>{ui.stCm=b.dataset.k;render();setTimeout(()=>document.getElementById('tf-stcm')?.focus(),0)},
  stcmx:()=>{ui.stCm=null;render()},
  stcmsave:b=>{const v=(document.getElementById('tf-stcm')||{}).value||'';ui.stCm=null;stSave(b.dataset.k,{comment:v.trim(),cBy:ui.me||'manager',cAt:new Date().toISOString()})},
  search:()=>{ui.tab=ui.tab==='search'?'check':'search';render();window.scrollTo(0,0);document.getElementById('q')?.focus()},
  goto:b=>{const k=b.dataset.k,v=b.dataset.v,d=b.dataset.d;ui.openDays=new Set();ui.focusDay='';
    if(d){ui.ws=mondayOf(parse(d));ui.day=d;}
    if(k==='plan'){ui.tab='plan';ui.openDays.add('p'+d)}
    else if(k==='task'){ui.tab=d?'check':(ui.mgr?'resp':'check');if(d)ui.openDays.add('c'+d)}
    else if(k==='child'){ui.tab='kids';ui.kid=v}
    else if(k==='cur'){ui.tab='kids';ui.kid='';ui.covGrade=''}
    else if(k==='staff'){ui.tab='over';ui.f.staff=v;ui.day='all'}
    else if(k==='fb'){ui.tab='fb'}
    render();window.scrollTo(0,0)},
  arch:async b=>{const c=b.dataset.c,x=byId(c,b.dataset.id);if(!x)return;const {id,...rest}=x;
    if(await put(c,id,{...rest,archived:true,archivedAt:todayIso()})){logAct(`Archived ${c==='resp'?'responsibility "'+x.text+'"':(c==='staff'?staffLabel(x):x.name)}`);toast('Archived. History is kept.')}},
  restore:async b=>{const c=b.dataset.c,x=byId(c,b.dataset.id);if(!x)return;const {id,archived,archivedAt,...rest}=x;
    if(await put(c,id,rest)){logAct(`Restored ${c==='resp'?'responsibility "'+x.text+'"':(c==='staff'?staffLabel(x):x.name)}`);toast('Restored')}},
  togarch:()=>{ui.showArch=!ui.showArch;render()},
  report:()=>doReport(), excel:()=>doExcel(), backup:()=>doBackup(),
  copen:b=>{ui.openC.add(b.dataset.k);render();const t=panel.querySelector(`[data-comment="${b.dataset.k}"]`);if(t){t.focus();t.setSelectionRange(t.value.length,t.value.length)}},
  cclose:b=>{ui.openC.delete(b.dataset.k);render()},
  csave:b=>{const k=b.dataset.k,t=panel.querySelector(`[data-comment="${k}"]`),m=panel.querySelector(`[data-cmgr="${k}"]`),txt=t?t.value.trim():'';ui.openC.delete(k);
    if(!ui.mgr&&txt){const [rid,date]=k.split('|'),r=byId('resp',rid);put('feedback','cm_'+k.replace(/[^A-Za-z0-9_-]/g,'_'),{to:'manager',from:ui.me,text:`${r?r.text:'Task'} (${fmt(date)}): ${txt}`,at:new Date().toISOString(),ref:k});toast('Sent to manager')}
    saveComment(k,txt)},
  alldays:()=>{[1,2,3,4,5].forEach(n=>document.getElementById('rf-d'+n).checked=true)},
  addnew:async b=>{const p=b.dataset.p,wrap=document.getElementById('xn-'+p+'-wrap'),name=val('xn-'+p);if(!name){toast('Type a name first.');return}
    const id=newId(),sel=document.getElementById(p+'-cur'),tp=document.getElementById(p+'-topic');
    if(wrap.dataset.mode==='subject'){S.curriculum.push({id,name});sel.innerHTML=subjOpts(id);sel.value=id;tp.innerHTML=topicOpts(id,'','—',true);put('curriculum',id,{name});logAct('Added curriculum '+name)}
    else{const sid=sel.value;S.topics.push({id,name,subjectId:sid});tp.innerHTML=topicOpts(sid,id,'—',true);tp.value=id;put('topics',id,{name,subjectId:sid});logAct(`Added subject ${name} to ${nm('curriculum',sid)}`)}
    wrap.hidden=true;document.getElementById('xn-'+p).value='';toast('Added '+name)},
  addcancel:b=>{const w=document.getElementById('xn-'+b.dataset.p+'-wrap');w.hidden=true},
  editresp:b=>{ui.editing.resp=b.dataset.id;ui.clear.add('rf-');if(ui.tab!=='resp'&&ui.tab!=='setup')ui.tab='resp';render();document.getElementById('respform')?.scrollIntoView({behavior:'smooth',block:'start'})},
  cancelresp:()=>{ui.clash=null;ui.editing.resp=null;ui.clear.add('rf-');render()},
  saveresp:async()=>{
    const once=document.getElementById('rf-recur-o').checked, days=[1,2,3,4,5].filter(n=>document.getElementById('rf-d'+n).checked);
    const d={text:val('rf-text'),staffId:val('rf-staff'),...readTime('rf'),recur:once?'once':'weekly',days:once?[]:days,date:once?val('rf-date'):'',from:once?'':(val('rf-from')||todayIso()),
      childId:val('rf-child'),gradeId:val('rf-grade'),...readSubj('rf'),updated:new Date().toISOString()};
    fillFromChild(d,'curriculumId');
    if(!d.staffId){toast('Choose a staff member.');return} if(!d.text){toast('Choose or type the responsibility.');return}
    if(!once&&!days.length){toast('Pick at least one day, Mon–Fri.');return} if(once&&!d.date){toast('Pick the date for this once-off task.');return}
    if(once){const wd=parse(d.date).getDay();if(wd===0||wd===6){toast('Pick a weekday, Mon–Fri.');return}}
    {const nx=[];for(let i=0;nx.length<5&&i<14;i++){const x=iso(addDays(new Date(),i));if(applies(d,x))nx.push(x)}
     if(checkClash('rf',d,staffFor(d),nx,ui.editing.resp))return}
    const id=ui.editing.resp||newId(), old=byId('resp',id);
    if(await put('resp',id,{...d,created:old?.created||new Date().toISOString()})){ui.clash=null;logAct(`${old?'Edited':'Added'} responsibility "${d.text}" for ${nm('staff',d.staffId)}`);ui.editing.resp=null;ui.clear.add('rf-');render();toast('Responsibility saved')}
  },
  editsec:b=>{ui.editing[b.dataset.c]=b.dataset.id;ui.clear.add('sf-'+b.dataset.c+'-');render()},
  cancelsec:b=>{ui.editing[b.dataset.c]=null;ui.clear.add('sf-'+b.dataset.c+'-');render()},
  savesec:async b=>{
    const sec=SETUP.find(s=>s.c===b.dataset.c), d={};
    sec.f.forEach(f=>d[f.k]=f.multi?S[f.multi].filter(x=>document.getElementById(`sf-${sec.c}-${f.k}-${x.id}`)?.checked).map(x=>x.id):val(`sf-${sec.c}-${f.k}`));
    if(!d[sec.f[0].k]){toast(sec.f[0].l+' is needed.');return}
    if(sec.c==='staff'&&!d.pin) d.pin='1234';
    if(sec.c==='tests'&&!d.date){toast('Pick the test date.');return}
    if(sec.c==='topics'&&!d.name){toast('Type the subject name.');return}
    if(sec.c==='tests'){const tp=byId('topics',d.topicId)||{};d.title=tp.name||'';d.curId=d.curId||tp.subjectId||''}
    if(sec.c==='breaks'&&!d.start){toast('Pick the start time.');return}
    if(sec.c==='leave'&&!d.from){toast('Pick the first day of leave.');return}
    if(sec.c==='holidays'&&!d.name){toast('Name the holiday.');return}
    const id=ui.editing[sec.c]||newId(), old=byId(sec.c,id);
    if(await put(sec.c,id,d)){logAct(`${old?'Edited':'Added'} ${sec.t.toLowerCase().replace(/s$/,'')}: ${sec.c==='staff'?staffLabel(d):(d.name||d.title||nm('staff',d.staffId)||d.date)}`);ui.editing[sec.c]=null;ui.clear.add('sf-'+sec.c+'-');render();toast('Saved')}
  },
  stdperiods:async()=>{for(const [name,start,end] of [['Arrival','07:00','08:00'],['Period 1','08:00','09:00'],['Period 2','09:00','10:00'],['Break','10:00','10:30'],['Period 3','10:30','11:30'],['Period 4','11:30','12:30'],['Lunch','12:30','13:00'],['Period 5','13:00','14:00'],['Aftercare','14:00','17:00']]) await put('periods',newId(),{name,start,end});
    logAct('Added standard time periods');toast('Standard periods added')},
  savepw:async()=>{const pw=val('sf-pw-new');if(pw.length<4){toast('Use at least 4 characters.');return}
    if(db){try{await db.doc('settings/main').set({...S.settings,pw});S.settings.pw=pw;logAct('Changed the admin password');ui.clear.add('sf-pw');render();toast('Password changed')}catch(e){toast('Could not save the password.')}}},
  del:async b=>{const c=b.dataset.c,id=b.dataset.id,k=c+id;if(ui.confirmDel!==k){ui.confirmDel=k;render();return}ui.confirmDel=null;
    const x=byId(c,id);await remove(c,id);if(c!=='plans')logAct(`Deleted ${c==='resp'?'responsibility "'+(x&&x.text)+'"':c+': '+(x?(c==='staff'?staffLabel(x):x.name||x.title||x.text||x.date||''):'')}`);toast('Deleted')},
  editplan:b=>{ui.addOpen=true;ui.editing.plan=b.dataset.id;ui.clear.add('pf-');render();window.scrollTo({top:0,behavior:'smooth'})},
  cancelplan:()=>{ui.clash=null;ui.editing.plan=null;ui.clear.add('pf-');render()},
  saveplan:async()=>{
    const ed=ui.editing.plan?byId('plans',ui.editing.plan):null, staffId=ui.mgr?val('pf-staff'):ui.me;
    const d={staffId,text:val('pf-text'),date:val('pf-date'),...readTime('pf'),childId:val('pf-child'),gradeId:val('pf-grade'),...readSubj('pf'),done:ed?!!ed.done:false,photos:ed?(ed.photos||[]):[],by:ed?ed.by:(ui.me||'manager'),updated:new Date().toISOString()};
    fillFromChild(d,'curriculumId');
    if(!d.staffId){toast('Choose the staff member.');return} if(!d.text){toast('Choose or type what is planned.');return}
    if(checkClash('pf',d,d.staffId==='*'?liveStaff().map(x=>x.id):[d.staffId],[d.date],ed&&ed.id))return;
    const pid=ed?ed.id:newId(),rep=!ed&&val('pf-rep')==='w',until=val('pf-until');if(rep)d.series=pid;
    if(await put('plans',pid,d)){let n=0;if(rep&&until){for(let k=1;k<=52;k++){const nd=iso(addDays(parse(d.date),7*k));if(nd>until)break;await put('plans',newId(),{...d,date:nd,done:false,photos:[]});n++}}
      ui.clash=null;ui.editing.plan=null;ui.clear.add('pf-');render();toast(n?`Planning saved and repeated for ${n} more week${n===1?'':'s'}`:'Planning saved')}
  },
  copyweek:async()=>{const prev=weekDates(addDays(ui.ws,-7)),cur=weekDates(ui.ws),who=ui.mgr?(ui.f.staff||null):ui.me;
    const src=S.plans.filter(p=>prev.includes(p.date)&&(!who||p.staffId===who));
    if(!src.length){toast('No planning last week to copy.');return}
    let n=0;for(const p of src){const nd=cur[prev.indexOf(p.date)];if(S.plans.some(q=>q.date===nd&&q.staffId===p.staffId&&q.text===p.text))continue;
      const {id,photos,...rest}=p;if(await put('plans',newId(),{...rest,date:nd,done:false,photos:[],copiedFrom:id,updated:new Date().toISOString()}))n++}
    toast(n?`Copied ${n} plan${n>1?'s':''} into week ${isoWeek(ui.ws)}`:'Last week is already copied.')},
  sign:b=>signOff([b.dataset.s],true), unsign:b=>signOff([b.dataset.s],false),
  signall:()=>signOff(stats(selDates()).map(x=>x.s.id),true),
  fbsend:async()=>{const to=val('fb-to'),text=val('fb-text');if(!to){toast('Choose who it is for.');return}if(!text){toast('Type the feedback first.');return}
    if(await put('feedback',newId(),{to,text,from:'manager',at:new Date().toISOString()})){logAct('Sent feedback to '+nm('staff',to));ui.clear.add('fb-t');render();toast('Feedback sent')}},
  fbnote:async()=>{const text=val('fb-note'),to=val('fb-noteto')||'manager';if(!text){toast('Type your message first.');return}
    if(await put('feedback',newId(),{to,from:ui.me,text,at:new Date().toISOString()})){ui.clear.add('fb-note');render();toast('Message sent to '+(to==='manager'?'your manager':nm('staff',to)))}},
  fbreply:async b=>{const fid=b.dataset.id,text=val('fb-r-'+fid);if(!text){toast('Type your reply first.');return}
    if(await put('replies',newId(),{fid,text,by:ui.mgr?'manager':ui.me,at:new Date().toISOString()})){ui.clear.add('fb-r-'+fid);render();toast('Reply sent')}},
  importgo:async()=>{const imp=ui.importData;if(!imp)return;ui.importData=null;let n=0;toast('Restoring…');
    for(const c of COLLS) for(const x of (imp.data[c]||[])){const {id,...rest}=x;if(id&&await put(c,id,rest))n++}
    if(imp.settings&&imp.settings.pw&&db){try{await db.doc('settings/main').set(imp.settings)}catch(e){}}
    logAct(`Imported a backup (${n} records)`);render();toast(`Restored ${n} records`)},
  importcancel:()=>{ui.importData=null;render()}
};
function saveComment(key,text){
  if(!signedIn())return;const [rid,date,sid]=key.split('|'),r=byId('resp',rid);if(!r)return;const id=ekey(r,date,sid);
  if(((entryMap[id]||{}).comment||'')===text){render();return}
  setEntry(id,rid,date,sid,{comment:text,cby:ui.me||'manager'});toast('Comment saved');
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-act]');if(!b||b.tagName==='FORM')return;if(b.dataset.ntcgo&&document.getElementById('ntm')){document.getElementById('ntm').remove();ui.ntcDone=false}if(wkGuard(b)){e.preventDefault();e.stopPropagation();return}if(ui.rowMenu&&!['rowmenu','del'].includes(b.dataset.act))ui.rowMenu=null;if(ui.chkMore&&b.dataset.act!=='chkmore')ui.chkMore=false;if(ui.confirmDel&&!['del','resetgo','tickall','pwresetall','ibclear','ibseldel','ibsel','phdel'].includes(b.dataset.act))ui.confirmDel=null;acts[b.dataset.act]?.(b,e)});
document.addEventListener('submit',e=>{e.preventDefault();acts[e.target.dataset.act]?.(e.target)});
document.addEventListener('change',e=>{const t=e.target;if(t.dataset&&t.dataset.snz){const m=Number(t.value);if(!m)return;const k=t.dataset.snz,sz=ntcSnz();sz[k]=new Date(Date.now()+m*60000).toISOString();lsSet('ntcsnz_'+meKey(),JSON.stringify(sz));const r=ntcRead();if(!r.includes(k)){r.push(k);ntcSave(r)}toast('I will remind you '+(SNZ.find(x=>x[0]===m)||[0,''])[1]);render();ntcModalFill();return}
  if(t.dataset.filter!==undefined){ui.f[t.dataset.filter]=t.value;if(t.dataset.filter==='cur')ui.f.topic='';
    if(t.dataset.filter==='child'){const c=byId('children',t.value);ui.f.grade=c?c.gradeId||'':'';ui.f.cur=c&&(c.curIds||[]).length?c.curIds[0]:'';ui.f.topic=''}
    render();return}
  if(t.dataset.uiset){ui[t.dataset.uiset]=t.value;render();return}
  if(t.dataset.tick){const [rid,date,sid]=t.dataset.tick.split('|'),r=byId('resp',rid);if(!r)return;setEntry(ekey(r,date,sid),rid,date,sid,{done:t.checked});return}
  if(t.dataset.comment){saveComment(t.dataset.comment,t.value.trim());ui.openC.delete(t.dataset.comment);return}
  if(t.dataset.ptick){const p=byId('plans',t.dataset.ptick);if(!p)return;const {id,...rest}=p;p.done=t.checked;put('plans',id,{...rest,done:t.checked});checkPlanDone(p.staffId,p.date);render();return}
  if(t.dataset.photo&&t.files&&t.files[0]){addPhoto('entry',t.dataset.photo,t.files[0]);return}
  if(t.dataset.pphoto&&t.files&&t.files[0]){addPhoto('plan',t.dataset.pphoto,t.files[0]);return}
  if(t.dataset.import&&t.files&&t.files[0]){const fr=new FileReader();fr.onload=()=>{try{const o=JSON.parse(fr.result);if(o.app!=='aldeia-staff-desk'||!o.data)throw 0;ui.importData=o;ui.open.add('BACKUP');render()}catch(x){toast('That file is not an Aldeia Staff Desk backup.')}};fr.readAsText(t.files[0]);t.value='';return}
  if(t.name==='rf-recur'){syncRecur();return}
  if(t.id==='tf-echild'){const c=byId('children',t.value),g=document.getElementById('tf-egrade');if(c&&g&&c.gradeId)g.value=c.gradeId;return}
  if(t.dataset.fbdone){const f=byId('feedback',t.dataset.fbdone);if(!f)return;const {id,...rest}=f,db_={...(f.doneBy||{})};if(t.checked)db_[ui.me]=new Date().toISOString();else delete db_[ui.me];
    put('feedback',id,{...rest,doneBy:db_});toast(t.checked?'Marked completed. Your manager will approve it.':'Unmarked');return}
  if(t.id==='pf-child'||t.id==='rf-child'||t.id==='tf-child'){linkChild(t.id.slice(0,2),true);return}
  if(t.dataset.fbto){ui.fbTo=t.value;ui.fbSel=new Set();render();return}
  if(t.dataset.fbsel){t.checked?ui.fbSel.add(t.dataset.fbsel):ui.fbSel.delete(t.dataset.fbsel);render();return}
  if(t.dataset.pick){const tg=document.getElementById(t.dataset.pick);if(tg&&t.value){tg.value=t.value+' ';tg.focus();tg.setSelectionRange(tg.value.length,tg.value.length)}t.value='';return}
  if(t.dataset.sess){const p=t.dataset.sess,src=SLOTS[t.value]||byId('periods',t.value);if(src){const st=document.getElementById(p+'-start');st.value=src.start||'';syncEnd(st);document.getElementById(p+'-end').value=src.end||''}return}
  if(t.tagName==='SELECT'&&/start$/.test(t.id)){syncEnd(t);return}
  if(t.dataset.subj){const p=t.dataset.subj,tp=document.getElementById(p+'-topic'),w=document.getElementById('xn-'+p+'-wrap');
    if(t.value==='__new'){t.value=t.dataset.prev||'';w.dataset.mode='subject';w.hidden=false;const i=document.getElementById('xn-'+p);i.placeholder='New curriculum, e.g. Impaq';i.focus();return}
    t.dataset.prev=t.value;tp.innerHTML=topicOpts(t.value,'','—',true);return}
  if(t.dataset.topic){const p=t.dataset.topic,w=document.getElementById('xn-'+p+'-wrap');
    if(t.value==='__new'){t.value='';if(!val(p+'-cur')){toast('Choose the curriculum first.');return}w.dataset.mode='topic';w.hidden=false;const i=document.getElementById('xn-'+p);i.placeholder='New subject for '+nm('curriculum',val(p+'-cur'))+', e.g. Maths';i.focus()}return}
});
document.addEventListener('toggle',e=>{const d=e.target;if(d.id==='fltbox')ui.fltOpen=d.open;if(d.id==='testbox')ui.testOpen=d.open;if(d.id==='rpbox')ui.rpOpen=d.open;if(d.id==='brkbox')ui.brkOpen=d.open;if(d.dataset&&d.dataset.sec){if(d.open){ui.open=new Set([d.dataset.sec]);panel.querySelectorAll('details.sec[open]').forEach(x=>{if(x!==d)x.open=false})}else ui.open.delete(d.dataset.sec)}},true);

/* ---------- theme ---------- */
function effTheme(){const t=document.documentElement.dataset.theme;if(t)return t;return matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'}
(()=>{const t=lsGet('theme');if(t)document.documentElement.dataset.theme=t})();

/* ---------- boot ---------- */
render();
document.getElementById('tabs').addEventListener('scroll',()=>syncTabs(false),{passive:true});
window.addEventListener('resize',()=>syncTabs(false));
(async()=>{
  const timer=setTimeout(()=>{if(!loaded){dbState='error';loaded=true;render()}},10000);
  try{db=await window.claude?.use?.('db')}catch(e){db=null}
  if(!db){clearTimeout(timer);dbState='none';loaded=true;render();return}
  const got=new Set();
  COLLS.forEach(c=>db.collection(c).onSnapshot(snap=>{
    S[c]=snap.docs.map(d=>({id:d.id,...d.data()}));
    if(c==='entries'){entryMap={};S.entries.forEach(e=>entryMap[e.id]=e)}
    if(c==='signoffs'){soMap={};S.signoffs.forEach(s=>soMap[s.id]=1)}
    got.add(c);if(got.size>=COLLS.length&&!loaded){loaded=true;clearTimeout(timer);dbState='ok'}
    if(loaded)scheduleRender();
  },()=>{clearTimeout(timer);dbState='error';loaded=true;scheduleRender()}));
  db.doc('settings/main').onSnapshot(s=>{S.settings=s.exists?(s.data()||{}):{}},()=>{});
  setInterval(()=>{if(!db||!loaded||!ui.me||ui.viewing||document.visibilityState!=='visible')return;const d=todayIso(),id=ui.me+'_'+d,cur=byId('online',id)||{},now=new Date().toISOString();
    const data={sid:ui.me,date:d,minutes:(cur.minutes||0)+1,first:cur.first||now,last:now};S.online=[...S.online.filter(x=>x.id!==id),{id,...data}];db.collection('online').doc(id).set(data).catch(()=>{})},60000);
  try{assets=await window.claude?.use?.('assets')}catch(e){assets=null}
  photoOk=!!assets; if(photoOk) scheduleRender();
})();
